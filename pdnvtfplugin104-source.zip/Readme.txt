===================================
===================================
 VTF FORMAT PLUG-IN BY: RYAN GREGG
===================================
===================================

===========================
Plug-in/Author Information:
===========================

  Title:
  VTF Format Plug-In for Pain.NET

  Date:
  April 1, 2008

  Author:
  Ryan Gregg

  Build:
  1.0.4

  Email:
  ryansgregg@hotmail.com

  Website:
  http://nemesis.thewavelength.net/

  Written In:
  C#

=============
Installation:
=============

  1) Close Paint.NET.
  2) Extract VTFLib.dll to your ..\Paint.NET\FileTypes\ folder.
  3) Extract VtfFileType.dll to your ..\Paint.NET\FileTypes\ folder.
  4) Run Paint.NET.

======
Notes:
======

  - This is a basic plug-in and is not designed to replace other tools such as VTFEdit.
  - The plug-in only supports single-frame and multiple-frame .vtf files.
  - If a multi-face .vtf file is loaded, only the first face is used.
  - .vtf information such as image format, flags and thumbnail data is not recalled when the
    .vtf is saved again.
  - The DXT file formats are lossy, if you save your .vtfs in this format you should also save
    a backup copy so you can access the original image data.

==========
Changelog:
==========

  v1.0.4
  - Added support for version 7.4 of the VTF format.
  - Upgraded to VTFLib v1.2.7.

  v1.0.3
  - Added support for version 7.3 of the VTF format.
  - Added version option.
  - Upgraded to VTFLib v1.2.6.

  v1.0.2
  - Image data allocation for animated files no longer done on the stack.

  v1.0.1
  - Fixed flags not saving at all.
  - Improved automatic flag selection.

  v1.0.0
  - Original build.