=========================================
=========================================
 BATCH COMPILER BY: RYAN "NEMESIS" GREGG
=========================================
=========================================

===========================
Program/Author Information:
===========================

---- General Program Information ----
Date                     : June 2nd 2003
Author                   : Ryan "NEMESIS" Gregg
Title                    : Batch Compiler
Build                    : 2.0.3.1
Email address            : ryansgregg@hotmail.com
Home page /  Website     : http://countermap.counter-strike.net/Nemesis

---- Program Construction Information ----
Programing Time          : About 9 hours.
Writen In                : Delphi 7

==================
Program Changelog:
==================

--- Batch Compiler v2.0.3.1 ---

  - Fixed bug where comma was beig used to indicate the decimal place.
  - Updated URL to 'online help'.

--- Batch Compiler v2.0.3 ---

  - Added ability to launch each stage individually.
  - Added ability to launch BCLV with <mapname>.log.
  - Fixed crash on settting options with no spec file loaded.

--- Batch Compiler v2.0.2 ---

  - Added ability to 'import' presets of one specification file to presets of another.
  - Added 'Path' type to BrowseBox for directory browsing.
  - Fixed bug where the executable checkboxes weren�t being reset when they should.
  - BrowseBoxes now insert quotes around their values when their values contain a space.
  - Updated specification files.

--- Batch Compiler Log Viewer v2.1.1 ---

  - Fixed minnor bugs to do with restoring settings.

--- Batch Compiler v2.0.1 ---

  - Any class's field's width can be specified (larger additional
    parameters box).
  - Can minimize to tray.
  - DOS file names converted to windows file names (eliminates
    multiplicity in recent file menu).
  - Tab's default values can be reset.
  - Empty field checking.
  - Remembers start-up position.
  - Minor bug fixes.
  - Specification file fixes.

--- Batch Compiler Log Viewer v2.1.0 ---

  - Toolbar added.
  - Popup menu added.
  - Recent file menu added.
  - Font dialog added.
  - Go To Line command added.
  - Remembers settings.
  - New icon.

==============================
Program Copyright-Permissions:
==============================

This program is Freeware.
