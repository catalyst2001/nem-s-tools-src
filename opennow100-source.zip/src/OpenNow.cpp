/*
 *	Open Now!
 *	Copyright (C) 2009  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "OpenNow.h"

int COpenNow::lpSortColumns[COpenNow::iMaxColumns] = { 0, 1, 2, 3 };
bool COpenNow::bSortDescending = false;

HICON COpenNow::LoadIcon(int iID, int iWidth, int iHeight)
{
	HINSTANCE hResourceInstance = _AtlModule.GetResourceInstance();
	if(hResourceInstance)
	{
		HRSRC hResource = FindResource(hResourceInstance, MAKEINTRESOURCE(iID), RT_GROUP_ICON);
		if(hResource)
		{
			HGLOBAL hLoadedResource = LoadResource(hResourceInstance, hResource);
			if(hLoadedResource)
			{
				LPVOID lpLockedResource = LockResource(hLoadedResource);
				if(lpLockedResource)
				{
					int iIconID = LookupIconIdFromDirectoryEx(static_cast<PBYTE>(lpLockedResource), TRUE, iWidth, iHeight, LR_DEFAULTCOLOR);
					HRSRC hIconResource = FindResource(hResourceInstance, MAKEINTRESOURCE(iIconID), MAKEINTRESOURCE(RT_ICON));
					if(hIconResource)
					{
						HGLOBAL hLoadedIconResource = LoadResource(hResourceInstance, hIconResource);
						if(hLoadedIconResource)
						{
							LPVOID lpLockedIconResource = LockResource(hLoadedIconResource);
							if(lpLockedIconResource)
							{
								DWORD dwSize = SizeofResource(hResourceInstance, hIconResource);
								return CreateIconFromResourceEx(static_cast<PBYTE>(lpLockedIconResource), dwSize, TRUE, 0x00030000, iWidth, iHeight, LR_DEFAULTCOLOR);
							}
						}
					}
				}
			}
		}
	}
	return NULL;
}

void COpenNow::CreateFileList()
{
	DestroyFileList();

	CComPtr<EnvDTE::_Solution> pSolution;
	if(SUCCEEDED(m_pDTE->get_Solution(&pSolution)) && pSolution)
	{
		SName< std::list<LPWSTR> > ProjectPath(ProjectPaths, NULL);

		CComPtr<EnvDTE::Projects> pProjects;
		if(SUCCEEDED(pSolution->get_Projects(&pProjects)) && pProjects)
		{
			LONG lCount = 0;
			if(SUCCEEDED(pProjects->get_Count(&lCount)))
			{
				for(LONG i = 1; i <= lCount; i++)
				{
					CComPtr<EnvDTE::Project> pProject;
					if(SUCCEEDED(pProjects->Item(CComVariant(i), &pProject)) && pProject)
					{
						CreateFileList(ProjectPath, pProject);
					}
				}
			}
		}
	}
}

void COpenNow::CreateFileList(SName< std::list<LPWSTR> >& ParentProjectPath, CComPtr<EnvDTE::Project> pProject)
{
	BSTR lpProjectName = NULL;
	if(SUCCEEDED(pProject->get_Name(&lpProjectName)) && lpProjectName)
	{
		CComPtr<EnvDTE::ProjectItems> pProjectItems;
		if(SUCCEEDED(pProject->get_ProjectItems(&pProjectItems)) && pProjectItems)
		{
			SName< std::vector<LPWSTR> > ProjectName(ProjectNames, lpProjectName);
			SName< std::list<LPWSTR> > ProjectPath(ParentProjectPath, lpProjectName);
			CreateFileList(ProjectName, ProjectPath, pProjectItems);
		}
	}
}

void COpenNow::CreateFileList(SName< std::vector<LPWSTR> >& ProjectName, SName< std::list<LPWSTR> >& ParentProjectPath, CComPtr<EnvDTE::ProjectItems> pParentProjectItems)
{
	LONG lCount = 0;
	if(SUCCEEDED(pParentProjectItems->get_Count(&lCount)))
	{
		for(LONG i = 1; i <= lCount; i++)
		{
			CComPtr<EnvDTE::ProjectItem> pProjectItem;
			if(SUCCEEDED(pParentProjectItems->Item(CComVariant(i), &pProjectItem)) && pProjectItem)
			{
				BSTR lpKind = NULL;
				if(SUCCEEDED(pProjectItem->get_Kind(&lpKind)) && lpKind)
				{
					WCHAR lpProjectItemKindPhysicalFile[MAX_PATH + 1];
					MultiByteToWideChar(CP_ACP, 0, EnvDTE::vsProjectItemKindPhysicalFile, -1, lpProjectItemKindPhysicalFile, MAX_PATH + 1);
					lpProjectItemKindPhysicalFile[MAX_PATH] = '\0';

					if(_wcsicmp(lpKind, lpProjectItemKindPhysicalFile) == 0)
					{
						BSTR lpFilePath = NULL;
						if(SUCCEEDED(pProjectItem->get_FileNames(0, &lpFilePath)) && lpFilePath)
						{
							LPWSTR lpFilePathCopy = new WCHAR[wcslen(lpFilePath) + 1];
							wcscpy(lpFilePathCopy, lpFilePath);
							Files.push_back(SFile(lpFilePathCopy, ProjectName.GetName(), ParentProjectPath.GetName()));
						}
					}
					else
					{
						CComPtr<EnvDTE::ProjectItems> pProjectItems;
						if(SUCCEEDED(pProjectItem->get_ProjectItems(&pProjectItems)) && pProjectItems)
						{
							BSTR lpFolderName = NULL;
							if(SUCCEEDED(pProjectItem->get_Name(&lpFolderName)) && lpFolderName)
							{
								SName< std::list<LPWSTR> > ProjectPath(ParentProjectPath, lpFolderName);
								CreateFileList(ProjectName, ProjectPath, pProjectItems);
							}
						}
						else
						{
							CComPtr<EnvDTE::Project> pProject;
							if(SUCCEEDED(pProjectItem->get_SubProject(&pProject)) && pProject)
							{
								CreateFileList(ParentProjectPath, pProject);
							}
						}
					}
				}
			}
		}
	}
}

void COpenNow::DestroyFileList()
{
	for(std::vector<LPWSTR>::iterator i = ProjectNames.begin(); i != ProjectNames.end(); ++i)
	{
		delete []*i;
	}
	ProjectNames.clear();

	for(std::list<LPWSTR>::iterator i = ProjectPaths.begin(); i != ProjectPaths.end(); ++i)
	{
		delete []*i;
	}
	ProjectPaths.clear();

	for(std::list<SFile>::iterator i = Files.begin(); i != Files.end(); ++i)
	{
		delete [](*i).lpFilePath;
	}
	Files.clear();

	FilteredFiles.clear();
}

int COpenNow::CompareProjects(const void *pProject1, const void *pProject2)
{
	return _wcsicmp(*static_cast<const LPCWSTR*>(pProject1), *static_cast<const LPCWSTR*>(pProject2));
}

void COpenNow::RefreshProjectList()
{
	if(ProjectNames.size() > 1)
	{
		qsort(&ProjectNames.front(), ProjectNames.size(), sizeof(LPWSTR), &COpenNow::CompareProjects);
	}

	HWND hProjects = GetDlgItem(IDC_PROJECTS);
	if(!hProjects)
	{
		return;
	}

	::SendMessage(hProjects, CB_RESETCONTENT, 0, 0);

	COMBOBOXEXITEM Item;
	memset(&Item, 0, sizeof(COMBOBOXEXITEM));
	Item.mask = CBEIF_TEXT;
	
	Item.pszText = L"<All Projects>";
	Item.cchTextMax = static_cast<int>(wcslen(Item.pszText));
	::SendMessage(hProjects, CBEM_INSERTITEM, 0, reinterpret_cast<LPARAM>(&Item));

	Item.pszText = LPSTR_TEXTCALLBACK;
	Item.cchTextMax = 0;
	for(std::vector<LPWSTR>::iterator i = ProjectNames.begin(); i != ProjectNames.end(); ++i)
	{
		Item.iItem++;
		::SendMessage(hProjects, CBEM_INSERTITEM, 0, reinterpret_cast<LPARAM>(&Item));
	}

	/*RECT ProjectsRect;
	::GetClientRect(hProjects, &ProjectsRect);
	RECT ProjectDropDownRect;
	::SendMessage(hProjects, CB_GETDROPPEDCONTROLRECT, 0, reinterpret_cast<LPARAM>(&ProjectDropDownRect));
	LPARAM iHeight = ::SendMessage(hProjects, CB_GETITEMHEIGHT, -1, 0);
	long iItems = std::min<long>(static_cast<long>(Item.iItem) + 1, 8);
	
	::MapWindowPoints(HWND_DESKTOP, *this, reinterpret_cast<LPPOINT>(&ProjectDropDownRect), 2);
	ProjectDropDownRect.bottom = ProjectDropDownRect.top + (ProjectsRect.bottom - ProjectsRect.top) + iHeight * iItems;
	::MoveWindow(hProjects, ProjectDropDownRect.left, ProjectDropDownRect.top, ProjectDropDownRect.right - ProjectDropDownRect.left, ProjectDropDownRect.bottom - ProjectDropDownRect.top, FALSE);

	ProjectsAnchor.Adjust(ProjectDropDownRect);*/

	::SendMessage(hProjects, CB_SETCURSEL, 0, 0);
}

int COpenNow::CompareFiles(const void *pFile1, const void *pFile2)
{
	int iResult = 0;

	for(int i = 0; i < iMaxColumns && iResult == 0; i++)
	{
		switch(COpenNow::lpSortColumns[i])
		{
		case 0:
			iResult = _wcsicmp(static_cast<const SFilteredFile*>(pFile1)->pFile->lpFilePath + static_cast<const SFilteredFile*>(pFile1)->pFile->uiFileName, static_cast<const SFilteredFile*>(pFile2)->pFile->lpFilePath + static_cast<const SFilteredFile*>(pFile2)->pFile->uiFileName);
			break;
		case 1:
			iResult = _wcsicmp(static_cast<const SFilteredFile*>(pFile1)->pFile->lpFilePath, static_cast<const SFilteredFile*>(pFile2)->pFile->lpFilePath);
			break;
		case 2:
			iResult = _wcsicmp(static_cast<const SFilteredFile*>(pFile1)->pFile->lpProjectName, static_cast<const SFilteredFile*>(pFile2)->pFile->lpProjectName);
			break;
		case 3:
			iResult = _wcsicmp(static_cast<const SFilteredFile*>(pFile1)->pFile->lpProjectPath, static_cast<const SFilteredFile*>(pFile2)->pFile->lpProjectPath);
			break;
		}
	}

	if(COpenNow::bSortDescending)
	{
		iResult = -iResult;
	}

	return iResult;
}

void COpenNow::SortFileList()
{
	if(FilteredFiles.size() > 1)
	{
		qsort(&FilteredFiles.front(), FilteredFiles.size(), sizeof(SFilteredFile), &COpenNow::CompareFiles);
	}
}

void COpenNow::RefreshFileList()
{
	HWND hFiles = GetDlgItem(IDC_FILES);
	if(!hFiles)
	{
		return;
	}

	LPCWSTR lpProjectName = NULL;
	HWND hProjects = GetDlgItem(IDC_PROJECTS);
	if(hProjects)
	{
		LRESULT iItem = ::SendMessage(hProjects, CB_GETCURSEL, 0, 0);
		if(iItem > 0 && static_cast<size_t>(iItem) <= ProjectNames.size())
		{
			lpProjectName = ProjectNames[iItem - 1];
		}
	}

	LPWSTR lpFilterStringTable = NULL;
	std::list<SFilter> Filters;
	CreateFilterList(lpFilterStringTable, Filters);

	FilteredFiles.clear();
	FilteredFiles.reserve(Files.size());

	unsigned int uiHasTerms = FILTER_TERM_NONE;
	for(std::list<SFilter>::iterator j = Filters.begin(); j != Filters.end(); ++j)
	{
		uiHasTerms |= (*j).GetFilterTerm();
	}

	int iBestMatch = -1;
	for(std::list<SFile>::iterator i = Files.begin(); i != Files.end(); ++i)
	{
		const SFile& File = *i;

		if(lpProjectName != NULL && File.lpProjectName != lpProjectName)
		{
			continue;
		}

		int iMatch = -1;
		unsigned int uiMatchTerms = uiHasTerms & FILTER_TERM_AND_MASK;
		for(std::list<SFilter>::iterator j = Filters.begin(); j != Filters.end(); ++j)
		{
			const SFilter& Filter = *j;

			int iTest = Filter.Match(File);
			unsigned int uiFilterTerm = Filter.GetFilterTerm();
			if(iTest >= 0)
			{
				if(iMatch < 0 || iTest < iMatch)
				{
					iMatch = iTest;
				}
				if(uiFilterTerm & FILTER_TERM_OR_MASK)
				{
					uiMatchTerms |= uiFilterTerm;
				}
			}
			else
			{
				if(uiFilterTerm & FILTER_TERM_AND_MASK)
				{
					uiMatchTerms &= ~uiFilterTerm;
				}
			}
		}
		if(((uiHasTerms & FILTER_TERM_OR_MASK) == 0 || (uiHasTerms & FILTER_TERM_OR_MASK & uiMatchTerms) != 0) &&
			((uiHasTerms & FILTER_TERM_AND_MASK) == 0 || (uiHasTerms & FILTER_TERM_AND_MASK) == (uiMatchTerms & FILTER_TERM_AND_MASK)))
		{
			if(iBestMatch < 0 || (iMatch >= 0 && iMatch < iBestMatch))
			{
				iBestMatch = iMatch;
			}
			FilteredFiles.push_back(SFilteredFile(&File, iMatch));
		}
	}

	DestroyFilterList(lpFilterStringTable, Filters);

	SortFileList();

	int iItem = 0;
	int iBestItem = -1;
	LVITEM Item;
	memset(&Item, 0, sizeof(LVITEM));
	Item.mask = LVIF_TEXT;
	Item.pszText = LPSTR_TEXTCALLBACK;
	int iCount = ListView_GetItemCount(hFiles);
	ListView_SetItemCountEx(hFiles, FilteredFiles.size(), 0);
	for(std::vector<SFilteredFile>::iterator i = FilteredFiles.begin(); i != FilteredFiles.end(); ++i)
	{
		const SFilteredFile& FilteredFile = *i;

		Item.iItem = iItem++;

		if(Item.iItem >= iCount)
		{
			Item.iSubItem = 0;
			ListView_SetItem(hFiles, &Item);

			Item.iSubItem = 1;
			ListView_SetItem(hFiles, &Item);

			Item.iSubItem = 2;
			ListView_SetItem(hFiles, &Item);

			Item.iSubItem = 3;
			ListView_SetItem(hFiles, &Item);
		}

		if(iBestItem == -1 || FilteredFile.iMatch < iBestMatch)
		{
			iBestItem = Item.iItem;
			iBestMatch = FilteredFile.iMatch;
		}
	}

	Select(iBestItem);

	const WCHAR* lpWindowCaption = L"Open File(s) in Solution";
	if(Files.size() > 0)
	{
		WCHAR lpWindowText[64];
		swprintf_s(lpWindowText, 64, L"%s (%u of %u)", lpWindowCaption, FilteredFiles.size(), Files.size());
		SetWindowText(lpWindowText);
	}
	else
	{
		SetWindowText(lpWindowCaption);
	}	
}

void COpenNow::ExploreSelectedFiles()
{
	HWND hFiles = GetDlgItem(IDC_FILES);
	if(!hFiles)
	{
		return;
	}

	typedef HRESULT (WINAPI *SHOpenFolderAndSelectItemsProc)(LPITEMIDLIST pidlFolder, UINT cidl, LPITEMIDLIST *apidl, DWORD dwFlags);

	static bool bInitializedShell32 = false;
	static SHOpenFolderAndSelectItemsProc pSHOpenFolderAndSelectItems = NULL;
	if(!bInitializedShell32)
	{
		bInitializedShell32 = true;

		HMODULE hShell32 = GetModuleHandle(L"shell32.dll");
		if(!hShell32)
		{
			return;
		}

		pSHOpenFolderAndSelectItems = reinterpret_cast<SHOpenFolderAndSelectItemsProc>(GetProcAddress(hShell32, "SHOpenFolderAndSelectItems"));
	}

	if(pSHOpenFolderAndSelectItems == NULL)
	{
		return;
	}

	CComPtr<IShellFolder> pDesktop;
	if(FAILED(SHGetDesktopFolder(&pDesktop)))
	{
		return;
	}

	std::list<SFolderAndSelectedFiles*> FoldersAndSelectedFiles;

	int iItem = -1;
	while((iItem = ListView_GetNextItem(hFiles, iItem, LVNI_SELECTED)) >= 0)
	{
		if(iItem < static_cast<int>(FilteredFiles.size()))
		{
			const SFilteredFile& FilteredFile = FilteredFiles[iItem];

			bool bFound = false;
			for(std::list<SFolderAndSelectedFiles*>::iterator i = FoldersAndSelectedFiles.begin(); i != FoldersAndSelectedFiles.end(); ++i)
			{
				SFolderAndSelectedFiles* pFolderAndSelectedFiles = *i;
				if(pFolderAndSelectedFiles->Contains(*FilteredFile.pFile))
				{
					pFolderAndSelectedFiles->SelectedFiles.push_back(FilteredFile.pFile);
					bFound = true;
					break;
				}
			}
			if(!bFound)
			{
				FoldersAndSelectedFiles.push_back(new SFolderAndSelectedFiles(*FilteredFile.pFile));
			}
		}
	}

	for(std::list<SFolderAndSelectedFiles*>::iterator i = FoldersAndSelectedFiles.begin(); i != FoldersAndSelectedFiles.end(); ++i)
	{
		SFolderAndSelectedFiles* pFolderAndSelectedFiles = *i;

		WCHAR iChar;
		LPWSTR lpFolder = const_cast<LPWSTR>(pFolderAndSelectedFiles->Folder.lpFilePath);
		iChar = lpFolder[pFolderAndSelectedFiles->Folder.uiFileName];
		lpFolder[pFolderAndSelectedFiles->Folder.uiFileName] = L'\0';

		LPITEMIDLIST pFolder = NULL;
		if(SUCCEEDED(pDesktop->ParseDisplayName(NULL, NULL, lpFolder, NULL, &pFolder, NULL)))
		{
			lpFolder[pFolderAndSelectedFiles->Folder.uiFileName] = iChar;

			UINT uiCount = 0;
			LPITEMIDLIST* lpFiles = new LPITEMIDLIST[pFolderAndSelectedFiles->SelectedFiles.size()];
			memset(lpFiles, 0, sizeof(LPITEMIDLIST) * pFolderAndSelectedFiles->SelectedFiles.size());
			for(std::list<const SFile*>::iterator j = pFolderAndSelectedFiles->SelectedFiles.begin(); j != pFolderAndSelectedFiles->SelectedFiles.end(); ++j)
			{
				if(SUCCEEDED(pDesktop->ParseDisplayName(NULL, NULL, (*j)->lpFilePath, NULL, &lpFiles[uiCount], NULL)))
				{
					uiCount++;
				}
			}

			if(uiCount > 0)
			{
				pSHOpenFolderAndSelectItems(pFolder, uiCount, lpFiles, 0);
			}

			for(UINT j = 0; j < uiCount; j++)
			{
				CoTaskMemFree(lpFiles[j]);
			}

			CoTaskMemFree(pFolder);
		}

		lpFolder[pFolderAndSelectedFiles->Folder.uiFileName] = iChar;

		delete pFolderAndSelectedFiles;
	}
}

void COpenNow::Select(int iItem)
{
	CWindow Files = GetDlgItem(IDC_FILES);
	HWND hFiles = Files;
	if(!hFiles)
	{
		return;
	}

	ListView_SetItemState(hFiles, -1, 0, LVIS_SELECTED);
	if(iItem >= 0)
	{
		ListView_SetItemState(hFiles, iItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		RECT ItemRect;
		if(ListView_GetItemRect(hFiles, iItem, &ItemRect, LVIR_BOUNDS))
		{
			RECT FilesRect;
			if(Files.GetClientRect(&FilesRect))
			{
				// Center selection in window.
				ItemRect.top -= (FilesRect.bottom - FilesRect.top) / 2;
			}
			ListView_Scroll(hFiles, 0, ItemRect.top);
		}
	}
	else
	{
		ListView_Scroll(hFiles, 0, 0);
	}
}

bool COpenNow::OpenSelectedFiles()
{
	HWND hFiles = GetDlgItem(IDC_FILES);
	if(!hFiles)
	{
		return false;
	}

	bool bResult = false;

	const EViewKind eViewKind = Button_GetCheck(GetDlgItem(IDC_VIEWCODE)) ? VIEW_KIND_CODE : VIEW_KIND_PRIMARY;
	WCHAR lpViewKind[MAX_PATH + 1];
	switch(eViewKind)
	{
	case VIEW_KIND_CODE:
		MultiByteToWideChar(CP_ACP, 0, EnvDTE::vsViewKindCode, -1, lpViewKind, MAX_PATH + 1);
		break;
	case VIEW_KIND_DESIGNER:
		MultiByteToWideChar(CP_ACP, 0, EnvDTE::vsViewKindDesigner, -1, lpViewKind, MAX_PATH + 1);
		break;
	case VIEW_KIND_TEXTVIEW:
		MultiByteToWideChar(CP_ACP, 0, EnvDTE::vsViewKindTextView, -1, lpViewKind, MAX_PATH + 1);
		break;
	case VIEW_KIND_DEBUGGING:
		MultiByteToWideChar(CP_ACP, 0, EnvDTE::vsViewKindDebugging, -1, lpViewKind, MAX_PATH + 1);
		break;
	default:
		MultiByteToWideChar(CP_ACP, 0, EnvDTE::vsViewKindPrimary, -1, lpViewKind, MAX_PATH + 1);
		break;
	}
	lpViewKind[MAX_PATH] = '\0';

	BSTR lpViewKindBStr = SysAllocString(lpViewKind);
	if(lpViewKindBStr != NULL)
	{
		CComPtr<EnvDTE::ItemOperations> pItemOperations;
		if(SUCCEEDED(m_pDTE->get_ItemOperations(&pItemOperations)) && pItemOperations)
		{
			int iItem = -1;
			while((iItem = ListView_GetNextItem(hFiles, iItem, LVNI_SELECTED)) >= 0)
			{
				if(iItem < static_cast<int>(FilteredFiles.size()))
				{
					const SFilteredFile& FilteredFile = FilteredFiles[iItem];

					BSTR lpFilePathBStr = SysAllocString(FilteredFile.pFile->lpFilePath);
					if(lpFilePathBStr != NULL)
					{
						CComPtr<EnvDTE::Window> pWindow;
						pItemOperations->OpenFile(lpFilePathBStr, lpViewKindBStr, &pWindow);

						SysFreeString(lpFilePathBStr);
					}

					bResult = true;
				}
			}
		}

		SysFreeString(lpViewKindBStr);
	}

	return bResult;
}

void COpenNow::CreateFilterList(LPWSTR& lpFilterStringTable, std::list<SFilter>& Filters)
{
	DestroyFilterList(lpFilterStringTable, Filters);

	BSTR lpFilter = NULL;
	GetDlgItem(IDC_FILTER).GetWindowText(lpFilter);
	if(lpFilter)
	{
		lpFilterStringTable = new WCHAR[wcslen(lpFilter) + 1];
		wcscpy(lpFilterStringTable, lpFilter);

		LPWSTR lpFilter = NULL;
		ESearchField eSearchField = SEARCH_FIELD_FILE_NAME;
		ELogicOperator eLogicOperator = LOGIC_OPERATOR_NONE;
		bool bNot = false;
		bool bQuoted = false;

		bool bParse = true;
		for(LPWSTR pChar = lpFilterStringTable; bParse; pChar++)
		{
			bool bDone = false;
			switch(*pChar)
			{
			case L'\0':
				bParse = false;
				bDone = true;
				break;
			case L'&':
				if(lpFilter == NULL && eLogicOperator == LOGIC_OPERATOR_NONE && !bQuoted)
				{
					eLogicOperator = LOGIC_OPERATOR_AND;
					continue;
				}
				break;
			case L'|':
				if(lpFilter == NULL && eLogicOperator == LOGIC_OPERATOR_NONE && !bQuoted)
				{
					eLogicOperator = LOGIC_OPERATOR_OR;
					continue;
				}
				break;
			case L'-':
			case L'!':
				if(lpFilter == NULL && !bNot && !bQuoted)
				{
					bNot = true;
					continue;
				}
				break;
			case L'"':
				if(lpFilter == NULL && !bQuoted)
				{
					bQuoted = true;
					continue;
				}
				else if(bQuoted)
				{
					bDone = true;
				}
				break;
			case L'\\':
			case L'/':
				if(lpFilter == NULL && !bQuoted)
				{
					if(eSearchField == SEARCH_FIELD_FILE_NAME)
					{
						eSearchField = SEARCH_FIELD_FILE_PATH;
					}
					else if(eSearchField == SEARCH_FIELD_PROJECT_NAME)
					{
						eSearchField = SEARCH_FIELD_PROJECT_PATH;
					}
					continue;
				}
				break;
			case L':':
				if(lpFilter == NULL && !bQuoted)
				{
					if(eSearchField == SEARCH_FIELD_FILE_NAME)
					{
						eSearchField = SEARCH_FIELD_PROJECT_NAME;
					}
					else if(eSearchField == SEARCH_FIELD_FILE_PATH)
					{
						eSearchField = SEARCH_FIELD_PROJECT_PATH;
					}
					continue;
				}
				break;
			case L' ':
			case L'\t':
			case L'\r':
			case L'\n':
				if(!bQuoted)
				{
					bDone = true;
				}
				break;
			}
			if(bDone)
			{
				if(lpFilter != NULL && *lpFilter != L'\0')
				{
					if(eLogicOperator == LOGIC_OPERATOR_NONE)
					{
						eLogicOperator = LOGIC_OPERATOR_AND;
					}
					if(bNot)
					{
						eLogicOperator = static_cast<ELogicOperator>(eLogicOperator << 1);
					}
					*pChar = L'\0';
					Filters.push_back(SFilter(lpFilter, eSearchField, eLogicOperator));
				}
				lpFilter = NULL;
				eSearchField = SEARCH_FIELD_FILE_NAME;
				eLogicOperator = LOGIC_OPERATOR_NONE;
				bNot = false;
				bQuoted = false;
			}
			else if(lpFilter == NULL)
			{
				lpFilter = pChar;
			}
		}
	}
}

void COpenNow::DestroyFilterList(LPWSTR& lpFilterStringTable, std::list<SFilter>& Filters)
{
	delete []lpFilterStringTable;
	lpFilterStringTable = NULL;

	Filters.clear();
}

WCHAR COpenNow::SFilter::Normalize(WCHAR cChar, ESearchField eSearchField)
{
	cChar = tolower(cChar);
	if((eSearchField == SEARCH_FIELD_FILE_PATH || eSearchField == SEARCH_FIELD_PROJECT_PATH) && cChar == L'/')
	{
		cChar = L'\\';
	}
	return cChar;
}

int COpenNow::SFilter::Like(LPCWSTR lpSearch, LPCWSTR lpFilter, ESearchField eSearchField)
{
	LPCWSTR lpSearchStart = lpSearch;
	LPCWSTR lpSearchMatch = NULL;

	while(*lpFilter)
	{
		if(*lpFilter == L'*')
		{
			if(lpFilter[1] == L'*')
			{
				lpFilter++;
				continue;
			}
			else if(lpFilter[1] == L'\0')
			{
				return 0;
			}
			else
			{
				lpFilter++;
				while(*lpSearch)
				{
					int iResult = Like(lpSearch, lpFilter, eSearchField);
					if(iResult >= 0)
					{
						return lpSearchMatch ? static_cast<int>(lpSearchMatch - lpSearchStart) : static_cast<int>(lpSearch - lpSearchStart) + iResult;
					}
					lpSearch++;
				}

				return -1;
			}
		}
		else if(*lpFilter == L'?')
		{
			if(*lpSearch == L'\0')
			{
				return -1;
			}
			lpFilter++;
			lpSearch++;
		}
		else
		{
			if(*lpSearch == L'\0')
			{
				return -1;
			}
			else if(*lpFilter != Normalize(*lpSearch, eSearchField))
			{
				return -1;
			}
			if(lpSearchMatch == NULL)
			{
				lpSearchMatch = lpSearch;
			}
			lpFilter++;
			lpSearch++;
		}
	}

	if(*lpSearch == L'\0')
	{
		return lpSearchMatch ? static_cast<int>(lpSearchMatch - lpSearchStart) : 0;
	}
	return -1;
}

int COpenNow::SFilter::Match(const SFile& File) const
{
	LPCWSTR lpSearch;
	switch(eSearchField)
	{
	case SEARCH_FIELD_FILE_NAME:
		lpSearch = File.lpFilePath + File.uiFileName;
		break;
	case SEARCH_FIELD_FILE_PATH:
		lpSearch = File.lpFilePath;
		break;
	case SEARCH_FIELD_PROJECT_NAME:
		lpSearch = File.lpProjectName;
		break;
	case SEARCH_FIELD_PROJECT_PATH:
		lpSearch = File.lpProjectPath;
		break;
	default:
		return -1;
	}

	int iMatch = -1;

	size_t iFileLength = wcslen(lpSearch);
	size_t iFilterLength = wcslen(lpFilter);
	if(bWildcard)
	{
		iMatch = Like(lpSearch, lpFilter, eSearchField);
	}
	else if(iFilterLength <= iFileLength)
	{
		for(size_t i = 0; i <= iFileLength - iFilterLength; i++)
		{
			bool bSubMatch = true;
			for(size_t j = 0; j < iFilterLength; j++)
			{
				if(Normalize(lpSearch[i + j], eSearchField) != lpFilter[j])
				{
					bSubMatch = false;
					break;
				}
			}
			if(bSubMatch)
			{
				iMatch = static_cast<int>(i);
				break;
			}
		}
	}

	if(eLogicOperator & LOGIC_OPERATOR_NOT_MASK)
	{
		if(iMatch < 0)
		{
			iMatch = static_cast<int>(iFileLength - iFilterLength);
		}
		else
		{
			iMatch = -1;
		}
	}

	return iMatch;
}

LRESULT CALLBACK COpenNow::FilterProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	COpenNow::SWndProc* pWndProc = COpenNow::GetWndProc(hWnd);
	if(pWndProc)
	{
		if(uMsg == WM_KEYDOWN)
		{
			switch(wParam)
			{
			case VK_DOWN:
			case VK_UP:
			case VK_NEXT:
			case VK_PRIOR:
				SendMessage(pWndProc->OpenNow.GetDlgItem(IDC_FILES), uMsg, wParam, lParam);
				return 0;
			}
		}
		return CallWindowProc(pWndProc->pWndProc, hWnd, uMsg, wParam, lParam);
	}
	return 0;
}

std::list<COpenNow::SWndProc*> COpenNow::WndProcs;

COpenNow::SWndProc* COpenNow::GetWndProc(HWND hWnd)
{
	for(std::list<COpenNow::SWndProc*>::iterator i = COpenNow::WndProcs.begin(); i != COpenNow::WndProcs.end(); i++)
	{
		COpenNow::SWndProc* pWndProc = *i;
		if(pWndProc->hWnd == hWnd)
		{
			return pWndProc;
		}
	}
	return NULL;
}

void COpenNow::RegisterWndProc(COpenNow& OpenNow, HWND hWnd, WNDPROC pWndProc)
{
	COpenNow::WndProcs.push_back(new SWndProc(OpenNow, hWnd, pWndProc));
}

void COpenNow::UnregisterWndProc(COpenNow* pOpenNow)
{
	for(std::list<COpenNow::SWndProc*>::iterator i = COpenNow::WndProcs.begin(); i != COpenNow::WndProcs.end(); i++)
	{
		COpenNow::SWndProc* pWndProc = *i;
		if(&pWndProc->OpenNow == pOpenNow)
		{
			delete pWndProc;
			COpenNow::WndProcs.erase(i);
			return;
		}
	}
}
