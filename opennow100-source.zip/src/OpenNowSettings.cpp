/*
 *	Open Now!
 *	Copyright (C) 2009  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "OpenNow.h"

void COpenNowSettings::Store()
{
	int iDesktopWidth = GetSystemMetrics(SM_CXMAXTRACK);
	int iDesktopHeight = GetSystemMetrics(SM_CYMAXTRACK);

	RECT Rect;
	if(GetWindowRect(OpenNow, &Rect))
	{
		Location.x = Rect.left;
		Location.y = Rect.top;
		Size.cx = Rect.right - Rect.left;
		Size.cy = Rect.bottom - Rect.top;

		if(Location.x > iDesktopWidth)
		{
			Location.x = iDesktopWidth - OpenNow.GetInitialWidth();
		}
		if(Location.y > iDesktopHeight)
		{
			Location.y = iDesktopHeight - OpenNow.GetInitialHeight();
		}
		if(Size.cx > iDesktopWidth)
		{
			Size.cx = iDesktopWidth;
		}
		if(Size.cy > iDesktopHeight)
		{
			Size.cy = iDesktopHeight;
		}
	}

	CWindow Files = OpenNow.GetDlgItem(IDC_FILES);
	if(Files)
	{
		LVCOLUMN Column;
		memset(&Column, 0, sizeof(LVCOLUMN));
		Column.mask = LVCF_WIDTH;

		ListView_GetColumn(Files, 0, &Column);
		iFileNameWidth = std::min<int>(Column.cx, iDesktopWidth);

		ListView_GetColumn(Files, 1, &Column);
		iFilePathWidth = std::min<int>(Column.cx, iDesktopWidth);

		ListView_GetColumn(Files, 2, &Column);
		iProjectNameWidth = std::min<int>(Column.cx, iDesktopWidth);

		ListView_GetColumn(Files, 3, &Column);
		iProjectPathWidth = std::min<int>(Column.cx, iDesktopWidth);
	}

	delete []lpProject;
	lpProject = NULL;

	CWindow Projects = OpenNow.GetDlgItem(IDC_PROJECTS);
	if(Projects)
	{
		LRESULT iItem = ::SendMessage(Projects, CB_GETCURSEL, 0, 0);
		const std::vector<LPWSTR>& ProjectNames = OpenNow.GetProjectNames();
		if(iItem > 0 && static_cast<size_t>(iItem) <= ProjectNames.size())
		{
			iItem--;
			lpProject = new WCHAR[wcslen(ProjectNames[iItem]) + 1];
			wcscpy(lpProject, ProjectNames[iItem]);
		}
	}

	delete []lpFilter;
	lpFilter = NULL;

	CWindow Filter = OpenNow.GetDlgItem(IDC_FILTER);
	if(Filter)
	{
		BSTR lpText = NULL;
		Filter.GetWindowText(lpText);
		if(lpText)
		{
			lpFilter = new WCHAR[wcslen(lpText) + 1];
			wcscpy(lpFilter, lpText);
		}
	}

	CWindow ViewCode = OpenNow.GetDlgItem(IDC_VIEWCODE);
	if(ViewCode)
	{
		eViewKind = Button_GetCheck(ViewCode) ? VIEW_KIND_CODE : VIEW_KIND_PRIMARY;
	}
}

void COpenNowSettings::Restore()
{
	bRestoring = true;

	RECT Rect;
	Rect.left = Location.x;
	Rect.top = Location.y;
	Rect.right = Rect.left + Size.cx;
	Rect.bottom = Rect.top + Size.cy;
	OpenNow.MoveWindow(&Rect);

	CWindow Files = OpenNow.GetDlgItem(IDC_FILES);
	if(Files)
	{
		LVCOLUMN Column;
		memset(&Column, 0, sizeof(LVCOLUMN));
		Column.mask = LVCF_WIDTH;

		Column.cx = iFileNameWidth;
		ListView_SetColumn(Files, 0, &Column);

		Column.cx = iFilePathWidth;
		ListView_SetColumn(Files, 1, &Column);

		Column.cx = iProjectNameWidth;
		ListView_SetColumn(Files, 2, &Column);

		Column.cx = iProjectPathWidth;
		ListView_SetColumn(Files, 3, &Column);
	}

	if(lpProject)
	{
		CWindow Projects = OpenNow.GetDlgItem(IDC_PROJECTS);
		if(Projects)
		{
			const std::vector<LPWSTR>& ProjectNames = OpenNow.GetProjectNames();
			for(size_t i = 0; i < ProjectNames.size(); i++)
			{
				if(_wcsicmp(lpProject, ProjectNames[i]) == 0)
				{
					::SendMessage(Projects, CB_SETCURSEL, i + 1, 0);
					break;
				}
			}
		}
	}

	if(lpFilter)
	{
		CWindow Filter = OpenNow.GetDlgItem(IDC_FILTER);
		if(Filter)
		{
			Filter.SetWindowText(lpFilter);
			Filter.SendMessage(EM_SETSEL, 0, -1);
		}
	}

	CWindow ViewCode = OpenNow.GetDlgItem(IDC_VIEWCODE);
	if(ViewCode)
	{
		Button_SetCheck(ViewCode, eViewKind == VIEW_KIND_CODE);
	}

	bRestoring = false;
}

void COpenNowSettings::Read()
{
	DWORD uiSize;

	HKEY hOpenNow;
	if(RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Nem's Tools\\Open Now!", 0, KEY_READ, &hOpenNow) == ERROR_SUCCESS)
	{
		uiSize = sizeof(Location);
		RegQueryValueEx(hOpenNow, L"Location", NULL, NULL, reinterpret_cast<LPBYTE>(&Location), &uiSize);
		uiSize = sizeof(Size);
		RegQueryValueEx(hOpenNow, L"Size", NULL, NULL, reinterpret_cast<LPBYTE>(&Size), &uiSize);

		uiSize = sizeof(iFileNameWidth);
		RegQueryValueEx(hOpenNow, L"FileNameWidth", NULL, NULL, reinterpret_cast<LPBYTE>(&iFileNameWidth), &uiSize);
		uiSize = sizeof(iFilePathWidth);
		RegQueryValueEx(hOpenNow, L"FilePathWidth", NULL, NULL, reinterpret_cast<LPBYTE>(&iFilePathWidth), &uiSize);
		uiSize = sizeof(iProjectNameWidth);
		RegQueryValueEx(hOpenNow, L"ProjectNameWidth", NULL, NULL, reinterpret_cast<LPBYTE>(&iProjectNameWidth), &uiSize);
		uiSize = sizeof(iProjectPathWidth);
		RegQueryValueEx(hOpenNow, L"ProjectPathWidth", NULL, NULL, reinterpret_cast<LPBYTE>(&iProjectPathWidth), &uiSize);

		delete []lpProject;
		lpProject = NULL;

		uiSize = 0;
		if(RegQueryValueEx(hOpenNow, L"Project", NULL, NULL, NULL, &uiSize) == ERROR_SUCCESS && uiSize > 0)
		{
			lpProject = new WCHAR[uiSize / sizeof(WCHAR)];
			RegQueryValueEx(hOpenNow, L"Project", NULL, NULL, reinterpret_cast<LPBYTE>(lpProject), &uiSize);
			lpProject[uiSize / sizeof(WCHAR) - 1] = '\0';
		}

		delete []lpFilter;
		lpFilter = NULL;

		uiSize = 0;
		if(RegQueryValueEx(hOpenNow, L"Filter", NULL, NULL, NULL, &uiSize) == ERROR_SUCCESS && uiSize > 0)
		{
			lpFilter = new WCHAR[uiSize / sizeof(WCHAR)];
			RegQueryValueEx(hOpenNow, L"Filter", NULL, NULL, reinterpret_cast<LPBYTE>(lpFilter), &uiSize);
			lpFilter[uiSize / sizeof(WCHAR) - 1] = '\0';
		}

		uiSize = sizeof(eViewKind);
		RegQueryValueEx(hOpenNow, L"ViewKind", NULL, NULL, reinterpret_cast<LPBYTE>(&eViewKind), &uiSize);
	}
}

void COpenNowSettings::Write()
{
	HKEY hSoftware;
	if(RegOpenKeyEx(HKEY_CURRENT_USER, L"Software", 0, KEY_WRITE, &hSoftware) == ERROR_SUCCESS)
	{
		HKEY hOpenNow;
		if(RegCreateKeyEx(hSoftware, L"Nem's Tools\\Open Now!", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hOpenNow, NULL) == ERROR_SUCCESS)
		{
			RegSetValueEx(hOpenNow, L"Location", 0, REG_BINARY, reinterpret_cast<const LPBYTE>(&Location), sizeof(Location));
			RegSetValueEx(hOpenNow, L"Size", 0, REG_BINARY, reinterpret_cast<const LPBYTE>(&Size), sizeof(Size));

			RegSetValueEx(hOpenNow, L"FileNameWidth", 0, REG_DWORD, reinterpret_cast<const LPBYTE>(&iFileNameWidth), sizeof(iFileNameWidth));
			RegSetValueEx(hOpenNow, L"FilePathWidth", 0, REG_DWORD, reinterpret_cast<const LPBYTE>(&iFilePathWidth), sizeof(iFilePathWidth));
			RegSetValueEx(hOpenNow, L"ProjectNameWidth", 0, REG_DWORD, reinterpret_cast<const LPBYTE>(&iProjectNameWidth), sizeof(iProjectNameWidth));
			RegSetValueEx(hOpenNow, L"ProjectPathWidth", 0, REG_DWORD, reinterpret_cast<const LPBYTE>(&iProjectPathWidth), sizeof(iProjectPathWidth));

			RegSetValueEx(hOpenNow, L"Project", 0, REG_SZ, reinterpret_cast<const LPBYTE>(lpProject), lpProject ? sizeof(WCHAR) * static_cast<DWORD>(wcslen(lpProject) + 1) : 0);
			RegSetValueEx(hOpenNow, L"Filter", 0, REG_SZ, reinterpret_cast<const LPBYTE>(lpFilter), lpFilter ? sizeof(WCHAR) * static_cast<DWORD>(wcslen(lpFilter) + 1) : 0);

			RegSetValueEx(hOpenNow, L"ViewKind", 0, REG_DWORD, reinterpret_cast<const LPBYTE>(&eViewKind), sizeof(eViewKind));
		}
	}
}