/*
 *	Open Now!
 *	Copyright (C) 2009  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "OpenNowSettings.h"

class COpenNow : public CAxDialogImpl<COpenNow>
{
public:
	COpenNow(CComPtr<EnvDTE80::DTE2> pDTE) : bInitializing(true), Settings(*this), iInitialSize(0), m_pDTE(pDTE)
	{
		CreateFileList();
	}

	~COpenNow()
	{
		DestroyFileList();
	}

	enum { IDD = IDD_OPENNOW };

	static const int iMaxColumns = 4;
	static int lpSortColumns[iMaxColumns];
	static bool bSortDescending;

	BEGIN_MSG_MAP(COpenNow)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		COMMAND_HANDLER(IDC_EXPLORE, BN_CLICKED, OnClickedExplore)
		COMMAND_HANDLER(IDOK, BN_CLICKED, OnClickedOpen)
		COMMAND_HANDLER(IDCANCEL, BN_CLICKED, OnClickedCancel)
		COMMAND_HANDLER(IDC_FILTER, EN_CHANGE, OnChangeFilter)
		NOTIFY_HANDLER(IDC_FILES, LVN_GETDISPINFO, OnGetDispInfoFiles)
		NOTIFY_HANDLER(IDC_FILES, LVN_GETINFOTIP, OnGetInfoTipFiles)
		NOTIFY_HANDLER(IDC_FILES, LVN_COLUMNCLICK, OnColumnClickFiles)
		NOTIFY_HANDLER(IDC_FILES, NM_DBLCLK, OnDoubleClickFiles)
		NOTIFY_HANDLER(IDC_PROJECTS, CBEN_GETDISPINFO, OnGetDispInfoProjects)
		COMMAND_HANDLER(IDC_PROJECTS, CBN_SELCHANGE, OnSelChangedProjects)
		CHAIN_MSG_MAP(CAxDialogImpl<COpenNow>)
	END_MSG_MAP()

	static HICON LoadIcon(int iID, int iWidth, int iHeight);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		CAxDialogImpl<COpenNow>::OnInitDialog(uMsg, wParam, lParam, bHandled);

		HICON hIcon = LoadIcon(1, 32, 32);
		if(hIcon)
		{
			SetIcon(hIcon);
		}

		CWindow Files = GetDlgItem(IDC_FILES);
		{
			const DWORD dwExtendedStyle = LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT | LVS_EX_INFOTIP | LVS_EX_LABELTIP;
			ListView_SetExtendedListViewStyleEx(Files, dwExtendedStyle, dwExtendedStyle);

			LVCOLUMN Column;
			memset(&Column, 0, sizeof(LVCOLUMN));
			Column.mask = LVCF_TEXT | LVCF_WIDTH;

			Column.pszText = L"File Name";
			Column.cx = 150;
			ListView_InsertColumn(Files, 0, &Column);

			Column.pszText = L"File Path";
			Column.cx = 250;
			ListView_InsertColumn(Files, 1, &Column);

			Column.pszText = L"Project Name";
			Column.cx = 150;
			ListView_InsertColumn(Files, 2, &Column);

			Column.pszText = L"Project Path";
			Column.cx = 250;
			ListView_InsertColumn(Files, 3, &Column);
		}

		RECT ClientRect;
		if(GetClientRect(&ClientRect))
		{
			WORD uiInitialWidth = static_cast<WORD>(ClientRect.right - ClientRect.left);
			WORD uiInitialHeight = static_cast<WORD>(ClientRect.bottom - ClientRect.top);
			iInitialSize = MAKELONG(uiInitialWidth, uiInitialHeight);
		}

		CWindow Filter = GetDlgItem(IDC_FILTER);
		if(Filter)
		{
			Filter.SetFocus();

			WNDPROC pWndProc = reinterpret_cast<WNDPROC>(::SetWindowLongPtr(Filter, GWL_WNDPROC, reinterpret_cast<LONG_PTR>(COpenNow::FilterProc)));
			if(pWndProc)
			{
				RegisterWndProc(*this, Filter, pWndProc);
			}
		}

		OSVERSIONINFO OSVersionInfo;
		memset(&OSVersionInfo, 0, sizeof(OSVERSIONINFO));
		OSVersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
		if(!GetVersionEx(&OSVersionInfo) || OSVersionInfo.dwMajorVersion < 5 || (OSVersionInfo.dwMajorVersion == 5 && OSVersionInfo.dwMinorVersion < 1))
		{
			GetDlgItem(IDC_EXPLORE).ShowWindow(SW_HIDE);
		}

		FilesAnchor.Init(*this, Files, static_cast<EAnchor>(ANCHOR_TOP | ANCHOR_BOTTOM | ANCHOR_LEFT | ANCHOR_RIGHT));
		FilterAnchor.Init(*this, Filter, static_cast<EAnchor>(ANCHOR_BOTTOM | ANCHOR_LEFT | ANCHOR_RIGHT));
		ProjectsAnchor.Init(*this, GetDlgItem(IDC_PROJECTS), static_cast<EAnchor>(ANCHOR_TOP | ANCHOR_LEFT | ANCHOR_RIGHT));
		ViewCodeAnchor.Init(*this, GetDlgItem(IDC_VIEWCODE), static_cast<EAnchor>(ANCHOR_BOTTOM | ANCHOR_LEFT));
		ExploreAnchor.Init(*this, GetDlgItem(IDC_EXPLORE), static_cast<EAnchor>(ANCHOR_BOTTOM | ANCHOR_RIGHT));
		OpenAnchor.Init(*this, GetDlgItem(IDOK), static_cast<EAnchor>(ANCHOR_BOTTOM | ANCHOR_RIGHT));
		CancelAnchor.Init(*this, GetDlgItem(IDCANCEL), static_cast<EAnchor>(ANCHOR_BOTTOM | ANCHOR_RIGHT));

		RefreshProjectList();

		Settings.Store();
		Settings.Read();
		Settings.Restore();

		RefreshFileList();

		bInitializing = false;

		bHandled = TRUE;
		return 0;
	}

	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		CWindow Filter = GetDlgItem(IDC_FILTER);
		if(Filter)
		{
			COpenNow::SWndProc* pWndProc = COpenNow::GetWndProc(Filter);
			if(pWndProc)
			{
				::SetWindowLongPtr(Filter, GWL_WNDPROC, reinterpret_cast<LONG_PTR>(pWndProc->pWndProc));
			}
		}
		UnregisterWndProc(this);

		Settings.Store();
		Settings.Write();

		return CAxDialogImpl<COpenNow>::OnDestroy(uMsg, wParam, lParam, bHandled);
	}

	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		LONG iWidth = static_cast<LONG>(LOWORD(lParam));
		LONG iHeight = static_cast<LONG>(HIWORD(lParam));

		LONG iInitialWidth = GetInitialWidth();
		LONG iInitialHeight = GetInitialHeight();

		LONG iDeltaX = iWidth - iInitialWidth;
		LONG iDeltaY = iHeight - iInitialHeight;

		FilesAnchor.Update(iDeltaX, iDeltaY);
		FilterAnchor.Update(iDeltaX, iDeltaY);
		ProjectsAnchor.Update(iDeltaX, iDeltaY);
		ViewCodeAnchor.Update(iDeltaX, iDeltaY);
		ExploreAnchor.Update(iDeltaX, iDeltaY);
		OpenAnchor.Update(iDeltaX, iDeltaY);
		CancelAnchor.Update(iDeltaX, iDeltaY);
		Invalidate();

		bHandled = TRUE;
		return 0;
	}

	LRESULT OnClickedExplore(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		ExploreSelectedFiles();
		EndDialog(wID);
		return 0;
	}

	LRESULT OnClickedOpen(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		OpenSelectedFiles();
		EndDialog(wID);
		return 0;
	}

	LRESULT OnClickedCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		EndDialog(wID);
		return 0;
	}

	LRESULT OnChangeFilter(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if(!bInitializing && !Settings.Restoring())
		{
			RefreshFileList();
		}
		return 0;
	}

	LRESULT OnGetDispInfoFiles(int /*idCtrl*/, LPNMHDR pNHM, BOOL& /*bHandled*/)
	{
		LV_DISPINFO* pDispInfo = reinterpret_cast<LV_DISPINFO*>(pNHM);
		if(pDispInfo->item.mask & LVIF_TEXT && pDispInfo->item.cchTextMax > 0)
		{
			if(pDispInfo->item.iItem >= 0 && pDispInfo->item.iItem < (LPARAM)FilteredFiles.size())
			{
				const SFilteredFile& FilteredFile = FilteredFiles[pDispInfo->item.iItem];
				switch(pDispInfo->item.iSubItem)
				{
				case 0:
					wcsncpy(pDispInfo->item.pszText, FilteredFile.pFile->lpFilePath + FilteredFile.pFile->uiFileName, pDispInfo->item.cchTextMax);
					pDispInfo->item.pszText[pDispInfo->item.cchTextMax - 1] = L'\0';
					break;
				case 1:
					wcsncpy(pDispInfo->item.pszText, FilteredFile.pFile->lpFilePath, pDispInfo->item.cchTextMax);
					pDispInfo->item.pszText[pDispInfo->item.cchTextMax - 1] = L'\0';
					break;
				case 2:
					wcsncpy(pDispInfo->item.pszText, FilteredFile.pFile->lpProjectName, pDispInfo->item.cchTextMax);
					pDispInfo->item.pszText[pDispInfo->item.cchTextMax - 1] = L'\0';
					break;
				case 3:
					wcsncpy(pDispInfo->item.pszText, FilteredFile.pFile->lpProjectPath, pDispInfo->item.cchTextMax);
					pDispInfo->item.pszText[pDispInfo->item.cchTextMax - 1] = L'\0';
					break;
				}
			}
		}
		return 0;
	}

	LRESULT OnGetInfoTipFiles(int /*idCtrl*/, LPNMHDR pNHM, BOOL& /*bHandled*/)
	{
		LPNMLVGETINFOTIP pInfoTip = reinterpret_cast<LPNMLVGETINFOTIP>(pNHM);
		if(pInfoTip->cchTextMax > 0)
		{
			if(pInfoTip->iItem >= 0 && static_cast<size_t>(pInfoTip->iItem) < FilteredFiles.size())
			{
				const SFilteredFile& FilteredFile = FilteredFiles[pInfoTip->iItem];
				switch(pInfoTip->iSubItem)
				{
				case 0:
					wcsncpy(pInfoTip->pszText, FilteredFile.pFile->lpFilePath, pInfoTip->cchTextMax);
					pInfoTip->pszText[pInfoTip->cchTextMax - 1] = L'\0';
					break;
				case 2:
					wcsncpy(pInfoTip->pszText, FilteredFile.pFile->lpProjectPath, pInfoTip->cchTextMax);
					pInfoTip->pszText[pInfoTip->cchTextMax - 1] = L'\0';
					break;
				}
			}
		}
		return 0;
	}

	LRESULT OnColumnClickFiles(int /*idCtrl*/, LPNMHDR pNHM, BOOL& /*bHandled*/)
	{
		NM_LISTVIEW FAR* pColumnClick = reinterpret_cast<NM_LISTVIEW FAR*>(pNHM);

		for(int i = 0; i < iMaxColumns; i++)
		{
			if(lpSortColumns[i] == pColumnClick->iSubItem)
			{
				if(i == 0)
				{
					bSortDescending = !bSortDescending;
				}
				else
				{
					for(int j = 0; j < i; j++)
					{
						lpSortColumns[i - j] = lpSortColumns[i - j - 1];
					}
					lpSortColumns[0] = pColumnClick->iSubItem;
				}
				break;
			}
		}
		RefreshFileList();

		return 0;
	}

	LRESULT OnDoubleClickFiles(int /*idCtrl*/, LPNMHDR pNHM, BOOL& /*bHandled*/)
	{
		if(OpenSelectedFiles())
		{
			EndDialog(0);
		}

		return 0;
	}

	LRESULT OnGetDispInfoProjects(int /*idCtrl*/, LPNMHDR pNHM, BOOL& /*bHandled*/)
	{
		PNMCOMBOBOXEX pDispInfo = reinterpret_cast<PNMCOMBOBOXEX>(pNHM);
		if(pDispInfo->ceItem.mask & CBEIF_TEXT && pDispInfo->ceItem.cchTextMax > 0)
		{
			if(pDispInfo->ceItem.iItem > 0 && static_cast<size_t>(pDispInfo->ceItem.iItem) <= ProjectNames.size())
			{
				LPCWSTR lpProject = ProjectNames[pDispInfo->ceItem.iItem - 1];

				wcsncpy(pDispInfo->ceItem.pszText, lpProject, pDispInfo->ceItem.cchTextMax);
				pDispInfo->ceItem.pszText[pDispInfo->ceItem.cchTextMax - 1] = L'\0';
			}
		}
		return 0;
	}

	LRESULT OnSelChangedProjects(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if(!bInitializing && !Settings.Restoring())
		{
			RefreshFileList();
		}
		return 0;
	}

	LONG GetInitialWidth() const
	{
		return static_cast<LONG>(LOWORD(iInitialSize));
	}

	LONG GetInitialHeight() const
	{
		return static_cast<LONG>(HIWORD(iInitialSize));
	}

private:
	bool bInitializing;
	COpenNowSettings Settings;

	enum EAnchor
	{
		ANCHOR_NONE = 0x00,
		ANCHOR_TOP = 0x01,
		ANCHOR_BOTTOM = 0x02,
		ANCHOR_LEFT = 0x04,
		ANCHOR_RIGHT = 0x08
	};

	struct SAnchor 
	{
		inline SAnchor() : hWindow(0), eAnchor(ANCHOR_NONE)
		{
		}

		inline void Init(HWND hParent, HWND hWindow, EAnchor eAnchor)
		{
			this->hWindow = hWindow;
			this->eAnchor = eAnchor;

			::GetWindowRect(hWindow, &Rect);
			::MapWindowPoints(HWND_DESKTOP, hParent, reinterpret_cast<LPPOINT>(&Rect), 2);
		}

		void Adjust(RECT& Rect)
		{
			this->Rect.right = this->Rect.left + (Rect.right - Rect.left);
			this->Rect.bottom = this->Rect.top + (Rect.bottom - Rect.top);
		}

		void Update(LONG iDeltaX, LONG iDeltaY)
		{
			if(hWindow)
			{
				RECT NewRect = Rect;
				if((eAnchor & ANCHOR_TOP) == 0)
				{
					NewRect.top += iDeltaY;
				}
				if((eAnchor & ANCHOR_BOTTOM) != 0)
				{
					NewRect.bottom += iDeltaY;
				}
				if((eAnchor & ANCHOR_LEFT) == 0)
				{
					NewRect.left += iDeltaX;
				}
				if((eAnchor & ANCHOR_RIGHT) != 0)
				{
					NewRect.right += iDeltaX;
				}
				::MoveWindow(hWindow, NewRect.left, NewRect.top, NewRect.right - NewRect.left, NewRect.bottom - NewRect.top, TRUE);
			}
		}

	private:
		HWND hWindow;
		EAnchor eAnchor;
		RECT Rect;
	};

	LONG iInitialSize;
	SAnchor FilesAnchor;
	SAnchor FilterAnchor;
	SAnchor ProjectsAnchor;
	SAnchor ViewCodeAnchor;
	SAnchor ExploreAnchor;
	SAnchor OpenAnchor;
	SAnchor CancelAnchor;

	CComPtr<EnvDTE80::DTE2> m_pDTE;

	template<class T>
	struct SName
	{
	public:
		inline SName(T& Names, LPCWSTR lpName) : Names(Names), bUsed(false), lpName(NULL)
		{
			if(lpName != NULL)
			{
				this->lpName = new WCHAR[wcslen(lpName) + 1];
				wcscpy(this->lpName, lpName);
			}
		}

		inline SName(SName<T>& Parent, LPCWSTR lpName) : Names(Parent.Names), bUsed(false), lpName(NULL)
		{
			if(lpName != NULL)
			{
				if(Parent.lpName != NULL)
				{
					this->lpName = new WCHAR[wcslen(Parent.lpName) + 1 + wcslen(lpName) + 1];
					wcscpy(this->lpName, Parent.lpName);
					wcscat(this->lpName, L"\\");
					wcscat(this->lpName, lpName);
				}
				else
				{
					this->lpName = new WCHAR[wcslen(lpName) + 1];
					wcscpy(this->lpName, lpName);
				}
			}
			else
			{
				bUsed = true;
				lpName = Parent.lpName;
			}
		}

		inline ~SName()
		{
			if(!bUsed)
			{
				delete []lpName;
			}
		}

		inline bool GetUsed() const
		{
			return bUsed;
		}

		inline LPCWSTR GetName()
		{
			if(!bUsed && lpName)
			{
				bUsed = true;
				Names.push_back(lpName);
			}
			return lpName;
		}

	private:
		bool bUsed;
		T& Names;
		LPWSTR lpName;
	};

	void CreateFileList();
	void CreateFileList(SName< std::list<LPWSTR> >& ParentProjectPath, CComPtr<EnvDTE::Project> pProject);
	void CreateFileList(SName< std::vector<LPWSTR> >& ProjectName, SName< std::list<LPWSTR> >& ParentProjectPath, CComPtr<EnvDTE::ProjectItems> pParentProjectItems);
	void DestroyFileList();

	static int CompareProjects(const void *pProject1, const void *pProject2);
	void RefreshProjectList();

	static int CompareFiles(const void *pFile1, const void *pFile2);
	void SortFileList();
	void RefreshFileList();

	void ExploreSelectedFiles();

	void Select(int iItem);
	void ScrollTo(int iItem);
	bool OpenSelectedFiles();

	struct SFile
	{
		inline SFile(LPWSTR lpFilePath, LPCWSTR lpProjectName, LPCWSTR lpProjectPath) : lpFilePath(lpFilePath), uiFileName(0), lpProjectName(lpProjectName), lpProjectPath(lpProjectPath)
		{
			LPWSTR lpFileName = std::max<LPWSTR>(wcsrchr(lpFilePath, L'\\'), wcsrchr(lpFilePath, L'/'));
			if(lpFileName)
			{
				uiFileName = static_cast<unsigned short>(lpFileName - lpFilePath) + 1;
			}
		}

		inline SFile(LPWSTR lpFilePath, unsigned short uiFileName, LPCWSTR lpProjectName, LPCWSTR lpProjectPath) : lpFilePath(lpFilePath), uiFileName(uiFileName), lpProjectName(lpProjectName), lpProjectPath(lpProjectPath)
		{
		}

		inline SFile(const SFile& File) : lpFilePath(File.lpFilePath), uiFileName(File.uiFileName), lpProjectName(File.lpProjectName), lpProjectPath(File.lpProjectPath)
		{
		}

		inline SFile& operator=(const SFile& Other)
		{
			if(this != &Other)
			{
				lpFilePath = Other.lpFilePath;
				uiFileName = Other.uiFileName;
				lpProjectName = Other.lpProjectName;
				lpProjectPath = Other.lpProjectPath;
			}
			return *this;
		}

		LPWSTR lpFilePath;
		unsigned short uiFileName;
		LPCWSTR lpProjectName;
		LPCWSTR lpProjectPath;
	};

	struct SFilteredFile
	{
		inline SFilteredFile(const SFile* pFile, int iMatch) : pFile(pFile), iMatch(iMatch)
		{
		}

		const SFile* pFile;
		int iMatch;
	};

	std::vector<LPWSTR> ProjectNames;
	std::list<LPWSTR> ProjectPaths;
	std::list<SFile> Files;
	std::vector<SFilteredFile> FilteredFiles;

public:
	inline const std::vector<LPWSTR>& GetProjectNames() const
	{
		return ProjectNames;
	}

private:

	enum ESearchField
	{
		SEARCH_FIELD_FILE_NAME		= 0,
		SEARCH_FIELD_FILE_PATH		= 4,
		SEARCH_FIELD_PROJECT_NAME	= 8,
		SEARCH_FIELD_PROJECT_PATH	= 12
	};

	enum ELogicOperator
	{
		LOGIC_OPERATOR_NONE		= 0x00,
		LOGIC_OPERATOR_AND		= 0x01,
		LOGIC_OPERATOR_AND_NOT	= 0x02,
		LOGIC_OPERATOR_OR		= 0x04,
		LOGIC_OPERATOR_OR_NOT	= 0x08,
		LOGIC_OPERATOR_NOT_MASK	= LOGIC_OPERATOR_AND_NOT | LOGIC_OPERATOR_OR_NOT
	};

	enum EFilterTerm
	{
		FILTER_TERM_NONE					= 0x00,
		FILTER_TERM_FILE_NAME_AND			= LOGIC_OPERATOR_AND << SEARCH_FIELD_FILE_NAME,
		FILTER_TERM_FILE_NAME_AND_NOT		= LOGIC_OPERATOR_AND_NOT << SEARCH_FIELD_FILE_NAME,
		FILTER_TERM_FILE_NAME_OR			= LOGIC_OPERATOR_OR << SEARCH_FIELD_FILE_NAME,
		FILTER_TERM_FILE_NAME_OR_NOT		= LOGIC_OPERATOR_OR_NOT << SEARCH_FIELD_FILE_NAME,
		FILTER_TERM_FILE_PATH_AND			= LOGIC_OPERATOR_AND << SEARCH_FIELD_FILE_PATH,
		FILTER_TERM_FILE_PATH_AND_NOT		= LOGIC_OPERATOR_AND_NOT << SEARCH_FIELD_FILE_PATH,
		FILTER_TERM_FILE_PATH_OR			= LOGIC_OPERATOR_OR << SEARCH_FIELD_FILE_PATH,
		FILTER_TERM_FILE_PATH_OR_NOT		= LOGIC_OPERATOR_OR_NOT << SEARCH_FIELD_FILE_PATH,
		FILTER_TERM_PROJECT_NAME_AND		= LOGIC_OPERATOR_AND << SEARCH_FIELD_PROJECT_NAME,
		FILTER_TERM_PROJECT_NAME_AND_NOT	= LOGIC_OPERATOR_AND_NOT << SEARCH_FIELD_PROJECT_NAME,
		FILTER_TERM_PROJECT_NAME_OR			= LOGIC_OPERATOR_OR << SEARCH_FIELD_PROJECT_NAME,
		FILTER_TERM_PROJECT_NAME_OR_NOT		= LOGIC_OPERATOR_OR_NOT << SEARCH_FIELD_PROJECT_NAME,
		FILTER_TERM_PROJECT_PATH_AND		= LOGIC_OPERATOR_AND << SEARCH_FIELD_PROJECT_PATH,
		FILTER_TERM_PROJECT_PATH_AND_NOT	= LOGIC_OPERATOR_AND_NOT << SEARCH_FIELD_PROJECT_PATH,
		FILTER_TERM_PROJECT_PATH_OR			= LOGIC_OPERATOR_OR << SEARCH_FIELD_PROJECT_PATH,
		FILTER_TERM_PROJECT_PATH_OR_NOT		= LOGIC_OPERATOR_OR_NOT << SEARCH_FIELD_PROJECT_PATH,
		FILTER_TERM_AND_MASK				= FILTER_TERM_FILE_NAME_AND | FILTER_TERM_FILE_NAME_AND_NOT | FILTER_TERM_FILE_PATH_AND | FILTER_TERM_FILE_PATH_AND_NOT | FILTER_TERM_PROJECT_NAME_AND | FILTER_TERM_PROJECT_NAME_AND_NOT | FILTER_TERM_PROJECT_PATH_AND | FILTER_TERM_PROJECT_PATH_AND_NOT,
		FILTER_TERM_OR_MASK					= FILTER_TERM_FILE_NAME_OR | FILTER_TERM_FILE_NAME_OR_NOT | FILTER_TERM_FILE_PATH_OR | FILTER_TERM_FILE_PATH_OR_NOT | FILTER_TERM_PROJECT_NAME_OR | FILTER_TERM_PROJECT_NAME_OR_NOT | FILTER_TERM_PROJECT_PATH_OR | FILTER_TERM_PROJECT_PATH_OR_NOT
	};

	struct SFilter
	{
	public:
		inline SFilter(LPWSTR lpFilter, ESearchField eSearchField, ELogicOperator eLogicOperator) : lpFilter(lpFilter), eSearchField(eSearchField), eLogicOperator(eLogicOperator), bWildcard(false)
		{
			while(*lpFilter)
			{
				*lpFilter = Normalize(*lpFilter, eSearchField);
				if(*lpFilter == L'*' || *lpFilter == L'?')
				{
					bWildcard = true;
				}
				lpFilter++;
			}
		}

		inline SFilter(const SFilter& Filter) : lpFilter(Filter.lpFilter), eSearchField(Filter.eSearchField), eLogicOperator(Filter.eLogicOperator), bWildcard(Filter.bWildcard)
		{
		}

		inline EFilterTerm GetFilterTerm() const
		{
			return static_cast<EFilterTerm>(eLogicOperator << eSearchField);
		}

		static WCHAR Normalize(WCHAR cChar, ESearchField eSearchField);
		static int Like(LPCWSTR lpSearch, LPCWSTR lpFilter, ESearchField eSearchField);
		int Match(const SFile& File) const;

		LPWSTR lpFilter;
		ESearchField eSearchField;
		ELogicOperator eLogicOperator;

	private:
		bool bWildcard;
	};

	void CreateFilterList(LPWSTR& lpFilterStringTable, std::list<SFilter>& Filters);
	void DestroyFilterList(LPWSTR& lpFilterStringTable, std::list<SFilter>& Filters);

	static LRESULT CALLBACK FilterProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

	struct SFolderAndSelectedFiles
	{
	public:
		inline SFolderAndSelectedFiles(const SFile& Folder) : Folder(Folder)
		{
			SelectedFiles.push_back(&Folder);
		}

		inline bool Contains(const SFile& File) const
		{
			if(Folder.uiFileName == File.uiFileName)
			{
				for(unsigned short i = 0; i < Folder.uiFileName; i++)
				{
					if(SFilter::Normalize(Folder.lpFilePath[i], SEARCH_FIELD_FILE_PATH) != SFilter::Normalize(File.lpFilePath[i], SEARCH_FIELD_FILE_PATH))
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		const SFile& Folder;
		std::list<const SFile*> SelectedFiles;
	};

public:
	struct SWndProc
	{
		COpenNow& OpenNow;
		HWND hWnd;
		WNDPROC pWndProc;

		inline SWndProc(COpenNow& OpenNow, HWND hWnd, WNDPROC pWndProc) : OpenNow(OpenNow), hWnd(hWnd), pWndProc(pWndProc)
		{
		}

		inline SWndProc(SWndProc& WndProc) : OpenNow(WndProc.OpenNow), hWnd(WndProc.hWnd), pWndProc(WndProc.pWndProc)
		{
		}
	};

	static SWndProc* GetWndProc(HWND hWnd);

private:
	static std::list<SWndProc*> WndProcs;

	static void RegisterWndProc(COpenNow& OpenNow, HWND hWnd, WNDPROC pWndProc);
	static void UnregisterWndProc(COpenNow* pOpenNow);
};