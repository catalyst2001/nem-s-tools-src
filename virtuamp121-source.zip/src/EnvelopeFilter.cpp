/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "EnvelopeFilter.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CEnvelopeFilterInfo, CEnvelopeFilter, EnvelopeFilterInfo);

CEnvelopeFilter::CEnvelopeFilter(CEngine &Engine) : CUnit(CEnvelopeFilter::EnvelopeFilterInfo, Engine), pPower(0), pSensitivity(0), pDecay(0), pPeak(0), pMode(0), pBoost(0), pUp(0), pStomp(0), Buffer(512)
{

}

CEnvelopeFilter::~CEnvelopeFilter()
{
	this->Unload();
}

bool CEnvelopeFilter::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/envelope filter.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pSensitivity = new CKnob(*this, "Sensitivity", 0.0f, 16.0f, 8.0f);
	this->pSensitivity->SetPosition(CVector(9, 34));
	this->pSensitivity->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pSensitivity);

	this->pDecay = new CKnob(*this, "Decay", 0.0f, 2.0f, 1.0f);
	this->pDecay->SetPosition(CVector(43, 34));
	this->pDecay->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDecay);

	this->pPeak = new CKnob(*this, "Peak", 0.0f, 1.0f, 0.165f);
	this->pPeak->SetPosition(CVector(77, 34));
	this->pPeak->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pPeak);

	this->pMode = new CKnob(*this, "Mode", 0.0f, 2.0f, 1.0f, true, -25.0f, 25.0f);
	this->pMode->SetPosition(CVector(111, 34));
	this->pMode->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pMode);

	this->pBoost = new CToggle(*this, "Boost", false);
	this->pBoost->SetPosition(CVector(34, 20));
	this->pBoost->SetOnTexture(this->Engine.LoadTexture("units/toggle_small_on.png"));
	this->pBoost->SetOffTexture(this->Engine.LoadTexture("units/toggle_small_off.png"));
	this->Controls.push_back(this->pBoost);

	this->pUp = new CToggle(*this, "Up", false);
	this->pUp->SetPosition(CVector(102, 20));
	this->pUp->SetOnTexture(this->Engine.LoadTexture("units/toggle_small_on.png"));
	this->pUp->SetOffTexture(this->Engine.LoadTexture("units/toggle_small_off.png"));
	this->Controls.push_back(this->pUp);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	return true;
}

void CEnvelopeFilter::UnloadInternal()
{
	this->pPower = 0;
	this->pSensitivity = 0;
	this->pDecay = 0;
	this->pPeak = 0;
	this->pMode = 0;
	this->pBoost = 0;
	this->pUp = 0;
	this->pStomp = 0;

	this->Buffer.Clear();
}

void CEnvelopeFilter::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CEnvelopeFilter::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		this->Buffer.fEnvelopeLower = 0.0f;
		this->Buffer.fEnvelopeUpper = 0.0f;
		this->Buffer.Advance(false, uiSamples, lpData);
		return;
	}

	this->Buffer.bBoost = this->pBoost->GetOn();
	this->Buffer.fSensitivity = this->pSensitivity->GetValue();
	this->Buffer.fDecay = this->pDecay->GetValue();
	this->Buffer.fPeak = this->pPeak->GetValue();
	this->Buffer.eFilterMode = (CEnvelopeFilterBuffer::EFilterMode)(unsigned int)this->pMode->GetValue();
	this->Buffer.eFilterDirection = this->pUp->GetOn() ? CEnvelopeFilterBuffer::FILTER_DIRECTION_UP : CEnvelopeFilterBuffer::FILTER_DIRECTION_DOWN;

	this->Buffer.uiSamplesPerSecond = uiSamplesPerSecond;

	this->Buffer.Advance(true, uiSamples, lpData);
}

#define ENVELOPE_FILTER_RANGE 12.5f
#define ENVELOPE_FILTER_WIDTH 0.15f
#define ENVELOPE_FILTER_BAND_WIDTH 0.25f

void CEnvelopeFilter::CEnvelopeFilterBuffer::Filter(int iSegment, unsigned int uiBufferIndex)
{
	this->PrepareFFTBuffer(uiBufferIndex);

	unsigned int i;

	// Compute envelope for FFT block.
	float fEnvelopeStart = 0.5f * (this->fEnvelopeUpper - this->fEnvelopeLower);

	float fBoost = this->bBoost ? powf(10.0f, this->fSensitivity / 40.0f) : 1.0f;
	float fAttackVelocity = this->fSensitivity * this->fSensitivity / (float)this->uiSamplesPerSecond;
	float fDecayVelocity = this->fDecay * this->fDecay / (float)this->uiSamplesPerSecond;
	for(i = 0; i < this->uiSegmentSamples; i ++)
	{
		float fSample = this->lpFFTIn[0][i] * fBoost;

		if(fSample < this->fEnvelopeLower)
		{
			this->fEnvelopeLower -= fAttackVelocity;
			if(this->fEnvelopeLower < -1.0f)
				this->fEnvelopeLower = -1.0f;
		}
		else if(fSample > this->fEnvelopeLower)
		{
			this->fEnvelopeLower += fDecayVelocity;
			if(this->fEnvelopeLower > 1.0f)
				this->fEnvelopeLower = 1.0f;
		}

		if(fSample > this->fEnvelopeUpper)
		{
			this->fEnvelopeUpper += fAttackVelocity;
			if(this->fEnvelopeUpper > 1.0f)
				this->fEnvelopeUpper = 1.0f;
		}
		else if(fSample < this->fEnvelopeUpper)
		{
			this->fEnvelopeUpper -= fDecayVelocity;
			if(this->fEnvelopeUpper < -1.0f)
				this->fEnvelopeUpper = -1.0f;
		}

		if(this->fEnvelopeLower > this->fEnvelopeUpper)
		{
			if(i % 2 == 0)
			{
				this->fEnvelopeLower = this->fEnvelopeUpper;
			}
			else
			{
				this->fEnvelopeUpper = this->fEnvelopeLower;
			}
		}
	}

	// Envelope is the average of the begining and ending envelopes normalized from 0 to 1.
	float fEnvelope = 0.5f * (fEnvelopeStart + (0.5f * (this->fEnvelopeUpper - this->fEnvelopeLower)));
	if(this->eFilterDirection == FILTER_DIRECTION_UP)
	{
		fEnvelope = 1.0f - fEnvelope;
	}

	// Compute envelope extents normalized from 0 to 1.
	float fEnvelopeMin, fEnvelopeMax;
	switch(this->eFilterMode)
	{
		case FILTER_MODE_LOW_PASS:
			fEnvelopeMin = 0.0f;
			fEnvelopeMax = this->fPeak;
			break;
		case FILTER_MODE_HIGH_PASS:
			fEnvelopeMin = this->fPeak;
			fEnvelopeMax = 1.0f;
			break;
		case FILTER_MODE_BAND_PASS:
		{
			fEnvelopeMin = this->fPeak - ENVELOPE_FILTER_BAND_WIDTH;
			if(fEnvelopeMin < 0.0f)
				fEnvelopeMin = 0.0f;
			fEnvelopeMax = this->fPeak + ENVELOPE_FILTER_BAND_WIDTH;
			if(fEnvelopeMax > 1.0f)
				fEnvelopeMax = 1.0f;
			break;
		}
	}

	fEnvelope = fEnvelopeMin + (fEnvelopeMax - fEnvelopeMin) * fEnvelope;

	fEnvelopeMin = max(fEnvelopeMin, fEnvelope - ENVELOPE_FILTER_WIDTH);
	fEnvelopeMax = min(fEnvelopeMax, fEnvelope + ENVELOPE_FILTER_WIDTH);

	unsigned int uiSamplesOverTwo = this->uiSegmentSamples / 2;

	unsigned int uiBits = 0;
	while(((1 << uiBits) & uiSamplesOverTwo) == 0)
		uiBits++;
	float fBits = (float)uiBits;

	// Compute FFT indexes of filter extents and peak from envelope.
	unsigned int uiIndexMin = (unsigned int)floorf(powf(2.0f, fEnvelopeMin * fBits));
	unsigned int uiIndexPeak = (unsigned int)floorf(powf(2.0f, fEnvelope * fBits));
	unsigned int uiIndexMax = (unsigned int)floorf(powf(2.0f, fEnvelopeMax * fBits));

	// Construct filter as cosine(-Pi..Pi) over filter extents peaking at cosine(0).
	float fWeightMin = powf(10.0f, -ENVELOPE_FILTER_RANGE / 20.0f);
	for(i = 0; i < uiIndexMin; i++)
		this->lpWeights[i] = fWeightMin;

	float fI = 0.0f;
	float fNormalizer = VA_PI / (float)(uiIndexPeak - uiIndexMin);
	for(i = uiIndexMin; i < uiIndexPeak; i++)
		this->lpWeights[i] = powf(10.0f, ENVELOPE_FILTER_RANGE * cosf(fI++ * fNormalizer - VA_PI) / 20.0f);

	fI = 0.0f;
	fNormalizer = VA_PI / (float)(uiIndexMax - uiIndexPeak);
	for(i = uiIndexPeak; i < uiIndexMax; i++)
		this->lpWeights[i] = powf(10.0f, ENVELOPE_FILTER_RANGE * cosf(fI++ * fNormalizer) / 20.0f);

	for(i = uiIndexMax; i < uiSamplesOverTwo; i++)
		this->lpWeights[i] = fWeightMin;

	this->FilterFFTBuffer(iSegment);
}