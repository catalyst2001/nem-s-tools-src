/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "AutomaticWah.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CAutomaticWahInfo, CAutomaticWah, AutomaticWahInfo);

CAutomaticWah::CAutomaticWah(CEngine &Engine) : CUnit(CAutomaticWah::AutomaticWahInfo, Engine), pPower(0), pDepth(0), pShape(0), pRate(0), pPeak(0), pSubtle(0), pStomp(0), Buffer(512)
{

}

CAutomaticWah::~CAutomaticWah()
{
	this->Unload();
}

bool CAutomaticWah::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/automatic wah.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CKnob(*this, "Depth", 0.0f, 0.5f, 0.5f);
	this->pDepth->SetPosition(CVector(9, 34));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDepth);

	this->pShape = new CKnob(*this, "Shape", 0.25f, 1.75f, 1.0f);
	this->pShape->SetPosition(CVector(43, 34));
	this->pShape->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pShape);

	this->pRate = new CKnob(*this, "Rate", 0.05f, 2.05f, 0.55f);
	this->pRate->SetPosition(CVector(77, 34));
	this->pRate->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pRate);

	this->pPeak = new CKnob(*this, "Peak", 0.0f, 1.0f, 0.5f);
	this->pPeak->SetPosition(CVector(111, 34));
	this->pPeak->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pPeak);

	this->pSubtle = new CToggle(*this, "Subtle", false);
	this->pSubtle->SetPosition(CVector(34, 20));
	this->pSubtle->SetOnTexture(this->Engine.LoadTexture("units/toggle_small_on.png"));
	this->pSubtle->SetOffTexture(this->Engine.LoadTexture("units/toggle_small_off.png"));
	this->Controls.push_back(this->pSubtle);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	return true;
}

void CAutomaticWah::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	this->pShape = 0;
	this->pRate = 0;
	this->pPeak = 0;
	this->pSubtle = 0;
	this->pStomp = 0;

	this->Buffer.Clear();
}

void CAutomaticWah::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CAutomaticWah::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		this->Buffer.fPhase = 0.0f;
		this->Buffer.Advance(false, uiSamples, lpData);
		return;
	}

	this->Buffer.fDepth = this->pDepth->GetValue();
	this->Buffer.fShape = this->pShape->GetValue();
	this->Buffer.fRate = this->pRate->GetValue();
	this->Buffer.fPeak = this->pPeak->GetValue();
	this->Buffer.bSubtle = this->pSubtle->GetOn();

	this->Buffer.uiSamplesPerSecond = uiSamplesPerSecond;

	this->Buffer.Advance(true, uiSamples, lpData);
}

#define ENVELOPE_FILTER_NORMAL_RANGE 12.5f
#define ENVELOPE_FILTER_SUBTLE_RANGE 6.25f
#define ENVELOPE_FILTER_WIDTH 0.15f

void CAutomaticWah::CAutomaticWahBuffer::Filter(int iSegment, unsigned int uiBufferIndex)
{
	this->PrepareFFTBuffer(uiBufferIndex);

	float fRate = VA_2PI / ((float)uiSamplesPerSecond / this->fRate);

	// Compute filter extents normalized from 0 to 1.
	float fFilterMin = this->fPeak - this->fDepth;
	if(fFilterMin < 0.0f)
		fFilterMin = 0.0f;
	float fFilter = 0.5f * (1.0f + cosf(this->fPhase * fRate));
	if(fFilter < 0.0f)
		fFilter = -powf(-fFilter, this->fShape);
	else
		fFilter = powf(fFilter, this->fShape);
	float fFilterMax = this->fPeak + this->fDepth;
	if(fFilterMax > 1.0f)
		fFilterMax = 1.0f;

	this->fPhase += (float)this->uiSegmentSamples;
	this->fPhase = fmodf(this->fPhase, (float)this->uiSamplesPerSecond / this->fRate);

	fFilter = fFilterMin + (fFilterMax - fFilterMin) * fFilter;

	fFilterMin = max(fFilterMin, fFilter - ENVELOPE_FILTER_WIDTH);
	fFilterMax = min(fFilterMax, fFilter + ENVELOPE_FILTER_WIDTH);

	unsigned int uiSamplesOverTwo = this->uiSegmentSamples / 2;

	unsigned int uiBits = 0;
	while(((1 << uiBits) & uiSamplesOverTwo) == 0)
		uiBits++;
	float fBits = (float)uiBits;

	// Compute FFT indexes of filter extents and peak from LFO.
	unsigned int uiIndexMin = (unsigned int)floorf(powf(2.0f, fFilterMin * fBits));
	unsigned int uiIndexPeak = (unsigned int)floorf(powf(2.0f, fFilter * fBits));
	unsigned int uiIndexMax = (unsigned int)floorf(powf(2.0f, fFilterMax * fBits));

	// Construct filter as cosine(-Pi..Pi) over filter extents peaking at cosine(0).
	unsigned int i;
	float fRange = this->bSubtle ? ENVELOPE_FILTER_SUBTLE_RANGE : ENVELOPE_FILTER_NORMAL_RANGE;

	float fWeightMin = powf(10.0f, -fRange / 20.0f);
	for(i = 0; i < uiIndexMin; i++)
		this->lpWeights[i] = fWeightMin;

	float fI = 0.0f;
	float fNormalizer = VA_PI / (float)(uiIndexPeak - uiIndexMin);
	for(i = uiIndexMin; i < uiIndexPeak; i++)
		this->lpWeights[i] = powf(10.0f, fRange * cosf(fI++ * fNormalizer - VA_PI) / 20.0f);

	fI = 0.0f;
	fNormalizer = VA_PI / (float)(uiIndexMax - uiIndexPeak);
	for(i = uiIndexPeak; i < uiIndexMax; i++)
		this->lpWeights[i] = powf(10.0f, fRange * cosf(fI++ * fNormalizer) / 20.0f);

	for(i = uiIndexMax; i < uiSamplesOverTwo; i++)
		this->lpWeights[i] = fWeightMin;

	this->FilterFFTBuffer(iSegment);
}