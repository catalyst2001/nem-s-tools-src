/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Preamp.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CPreampInfo, CPreamp, PreampInfo);

CPreamp::CPreamp(CEngine &Engine) : CUnit(CPreamp::PreampInfo, Engine), pPower(0), pCenterDC(0), pGain(0), pStomp(0), Buffer()
{

}

CPreamp::~CPreamp()
{
	this->Unload();
}

bool CPreamp::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/preamp.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pCenterDC = new CToggle(*this, "Center DC", true);
	this->pCenterDC->SetPosition(CVector(28, 42));
	this->pCenterDC->SetOnTexture(this->Engine.LoadTexture("units/toggle_small_on.png"));
	this->pCenterDC->SetOffTexture(this->Engine.LoadTexture("units/toggle_small_off.png"));
	this->Controls.push_back(this->pCenterDC);

	this->pGain = new CKnob(*this, "Gain", -20.0f, 20.0f, 0.0f);
	this->pGain->SetPosition(CVector(60, 34));
	this->pGain->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pGain);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp", true);
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->fSampleOffset = 0.0f;

	return true;
}

void CPreamp::UnloadInternal()
{
	this->pPower = 0;
	this->pCenterDC = 0;
	this->pGain = 0;
	this->pStomp = 0;

	this->Buffer.Clear();
}

void CPreamp::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CPreamp::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	this->Buffer.SetSamples(uiSamplesPerSecond / 10);
	this->Buffer.Advance(uiSamples, lpData);

	if(!this->pStomp->GetPressed())
	{
		memset(lpData, 0, sizeof(float) * uiSamples);
		return;
	}

	unsigned int i;
	float fGain = powf(10.0f, this->pGain->GetValue() / 20.0f);

	if(this->pCenterDC->GetOn())
	{
		float fMin = *this->Buffer.GetBuffer(), fMax = *this->Buffer.GetBuffer();
		for(i = 1; i < this->Buffer(); i++)
		{
			if(this->Buffer[i] < fMin)
			{
				fMin = this->Buffer[i];
			}
			if(this->Buffer[i] > fMax)
			{
				fMax = this->Buffer[i];
			}
		}

		float fOffset = (fMax + fMin) * -0.5f;
		float fStep = 0.025f / (float)uiSamplesPerSecond;

		for(i = 0; i < uiSamples; i++)
		{
			if(this->fSampleOffset < fOffset)
			{
				this->fSampleOffset += fStep;
				if(this->fSampleOffset > fOffset)
				{
					this->fSampleOffset = fOffset;
				}
			}
			else if(this->fSampleOffset > fOffset)
			{
				this->fSampleOffset -= fStep;
				if(this->fSampleOffset < fOffset)
				{
					this->fSampleOffset = fOffset;
				}
			}
			lpData[i] = (lpData[i] + this->fSampleOffset) * fGain;
		}
	}
	else
	{
		this->fSampleOffset = 0.0f;

		for(i = 0; i < uiSamples; i++)
		{
			lpData[i] *= fGain;
		}
	}

	fNormalizer *= fGain;
}
