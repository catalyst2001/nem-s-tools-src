/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Fader.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CFaderInfo, CFader, FaderInfo);

CFader::CFader(CEngine &Engine) : CUnit(CFader::FaderInfo, Engine), pPower(0), pFadeInOut(0), pTime(0), pStomp(0)
{

}

CFader::~CFader()
{
	this->Unload();
}

bool CFader::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/fader.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pFadeInOut = new CToggle(*this, "Fade In", false);
	this->pFadeInOut->SetPosition(CVector(28, 42));
	this->pFadeInOut->SetOnTexture(this->Engine.LoadTexture("units/toggle_small_on.png"));
	this->pFadeInOut->SetOffTexture(this->Engine.LoadTexture("units/toggle_small_off.png"));
	this->Controls.push_back(this->pFadeInOut);

	this->pTime = new CKnob(*this, "Time", 0.0f, 4.0f, 2.0f);
	this->pTime->SetPosition(CVector(60, 34));
	this->pTime->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pTime);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->fFade = 0.0f;

	return true;
}

void CFader::UnloadInternal()
{
	this->pPower = 0;
	this->pFadeInOut = 0;
	this->pTime = 0;
	this->pStomp = 0;
}

void CFader::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CFader::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	float fFadeTime = (float)uiSamplesPerSecond * this->pTime->GetValue();
	float fOneOverFadeTime = 1.0f / fFadeTime;

	if(this->pFadeInOut->GetOn())
	{
		if(!this->pStomp->GetPressed())
		{
			this->fFade = 0.0f;
			memset(lpData, 0, sizeof(float) * uiSamples);
			return;
		}

		for(unsigned int i = 0; i < uiSamples; i++)
		{
			if(this->fFade >= fFadeTime)
			{
				this->fFade = fFadeTime;
				break;
			}

			lpData[i] *= fFade * fOneOverFadeTime;
			fFade += 1.0f;
		}
	}
	else
	{
		if(!this->pStomp->GetPressed())
		{
			this->fFade = fFadeTime;
			return;
		}

		unsigned int i;
		for(i = 0; i < uiSamples; i++)
		{
			if(this->fFade <= 0.0f)
			{
				break;
			}

			lpData[i] *= fFade * fOneOverFadeTime;
			fFade -= 1.0f;
		}

		memset(lpData + i, 0, sizeof(float) * (uiSamples - i));
	}
}
