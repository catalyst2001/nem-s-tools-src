/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "AudioDriver.h"
#include "Vector.h"

#define AUDIO_BUFFERS_MIN 2
#define AUDIO_BUFFERS_MAX 8
#define BUFFER_DENOMINATOR_MIN 1
#define BUFFER_DENOMINATOR_MAX 30

namespace VAmp
{
	enum ECableInterp
	{
		CABLE_INTERP_LINEAR = 0,
		CABLE_INTERP_BEZIER,
		CABLE_INTERP_COMPLEX_BEZIER,
		CABLE_INTERP_COUNT
	};

	class CConfiguration
	{
	private:
		CVector WindowPosition;
		CVector WindowSize;
		bool bWindowMaximized;

		Audio::EAudioDriver eAudioDriver;
		unsigned int uiAudioBuffers;
		unsigned int uiBufferDenominator;
		unsigned int uiBufferFPS;

		ECableInterp eCableInterp;

	public:
		CConfiguration();
		
		inline const CVector &GetWindowPosition() const
		{
			return this->WindowPosition;
		}

		inline void SetWindowPosition(const CVector &WindowPosition)
		{
			this->WindowPosition = WindowPosition;
		}

		inline const CVector &GetWindowSize() const
		{
			return this->WindowSize;
		}

		inline void SetWindowSize(const CVector &WindowSize)
		{
			this->WindowSize = WindowSize;
		}

		inline bool GetWindowMaximized() const
		{
			return this->bWindowMaximized;
		}

		inline void SetWindowMaximized(bool bWindowMaximized)
		{
			this->bWindowMaximized = bWindowMaximized;
		}

		inline Audio::EAudioDriver GetAudioDriver() const
		{
			return this->eAudioDriver;
		}

		inline void SetAudioDriver(Audio::EAudioDriver eAudioDriver)
		{
			this->eAudioDriver = eAudioDriver;
		}

		inline unsigned int GetAudioBuffers() const
		{
			return this->uiAudioBuffers;
		}

		inline unsigned int GetBufferDenominator() const
		{
			return this->uiBufferDenominator;
		}

		inline void SetBufferDenominator(unsigned int uiBufferDenominator)
		{
			this->uiBufferDenominator = uiBufferDenominator;
		}

		inline unsigned int GetBufferFPS() const
		{
			return this->uiBufferFPS;
		}

		inline void SetBufferFPS(unsigned int uiBufferFPS)
		{
			this->uiBufferFPS = uiBufferFPS;
		}

		inline ECableInterp GetCableInterp() const
		{
			return this->eCableInterp;
		}

		inline void SetCableInterp(ECableInterp eCableInterp)
		{
			this->eCableInterp = eCableInterp;
		}

		bool Save(const char *lpFileName);
		bool Open(const char *lpFileName);
	};

	extern CConfiguration Configuration;
}
