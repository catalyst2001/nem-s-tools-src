/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"

namespace VAmp
{
	enum EMessageType
	{
		MESSAGE_TYPE_INFO,
		MESSAGE_TYPE_ERROR,
		MESSAGE_TYPE_SYSTEM_ERROR,
#ifdef USE_DIRECTSOUND
		MESSAGE_TYPE_DIRECTSOUND_ERROR,
#endif
		MESSAGE_TYPE_COUNT
	};

	class CLog
	{
	private:
		FILE *pFile;
		char lpLastError[8192];

		CRITICAL_SECTION CriticalSection;

	public:
		CLog(const char *lpFileName);
		~CLog();

		inline const char *GetLastError() const
		{
			return this->lpLastError;
		}

		void Log(EMessageType eMessageType, const char *lpFormat, ...);
		void Log(EMessageType eMessageType, const char *lpFormat, va_list ArgumentList);
	};

	extern CLog Log;

	void LogMessage(const char *lpFormat, ...);
	void LogError(const char *lpFormat, ...);
	void LogSystemError(const char *lpFormat, ...);

#ifdef USE_DIRECTSOUND
	extern HRESULT LastDirectSoundError;
	void LogDirectSoundError(HRESULT Error, const char *lpFormat, ...);
#endif
}
