/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "SpeakerCabinet.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CSpeakerCabinetInfo, CSpeakerCabinet, SpeakerCabinetInfo);

CSpeakerCabinet::CSpeakerCabinet(CEngine &Engine) : CUnit(CSpeakerCabinet::SpeakerCabinetInfo, Engine), pPower(0), pVolume(0), pTone(0), pStomp(0)
{

}

CSpeakerCabinet::~CSpeakerCabinet()
{
	this->Unload();
}

bool CSpeakerCabinet::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/speaker cabinet.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pVolume = new CKnob(*this, "Volume", 0.0f, 2.0f, 1.0f);
	this->pVolume->SetPosition(CVector(36, 34));
	this->pVolume->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pVolume);

	this->pTone = new CKnob(*this, "Tone", 0.0f, 2.0f, 1.0f);
	this->pTone->SetPosition(CVector(84, 34));
	this->pTone->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pTone);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	this->pStomp = new CStomp(*this, "Stomp", true);
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	return true;
}

void CSpeakerCabinet::UnloadInternal()
{
	this->pPower = 0;
	this->pVolume = 0;
	this->pTone = 0;
	this->pStomp = 0;
}

void CSpeakerCabinet::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CSpeakerCabinet::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		memset(lpData, 0, sizeof(float) * uiSamples);
		return;
	}

	float fVolume = this->pVolume->GetValue();
	if(fVolume <= 1.0f)
	{
		// The first half of the dial normalizes the volume between 0 and 1 where 1 is the original signal strength.
		fVolume /= fNormalizer;
	}
	else if(fNormalizer <= 1.0f)
	{
		// The second half normalizes to 1 if the signal strength has been diminished.
		fVolume = 1.0f / fNormalizer;
	}
	else
	{
		// Otherwise, the second half normalizes between 1 and the amplified signal strength.
		fVolume = (2.0f - fVolume) * (fVolume / fNormalizer) + (fVolume - 1.0f);
	}

	for(unsigned int i = 0; i < uiSamples; i++)
	{
		lpData[i] *= fVolume;

		if(lpData[i] < -1.0f)
		{
			lpData[i] = -1.0f;
		}
		if(lpData[i] > 1.0f)
		{
			lpData[i] = 1.0f;
		}
	}
}
