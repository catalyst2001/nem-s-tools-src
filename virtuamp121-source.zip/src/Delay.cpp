/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Delay.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CDelayInfo, CDelay, DelayInfo);

CDelay::CDelay(CEngine &Engine) : CUnit(CDelay::DelayInfo, Engine), pPower(0), pDepth(0), pFeedback(0), pTime(0), pRepeat(0), pReverse(0), pLong(0), pStomp(0), Buffer()
{

}

CDelay::~CDelay()
{
	this->Unload();
}

bool CDelay::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/delay.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CKnob(*this, "Depth", 0.0f, 1.0f, 0.5f);
	this->pDepth->SetPosition(CVector(9, 34));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDepth);

	this->pFeedback = new CKnob(*this, "Feedback", 0.0f, 1.0f, 0.5f);
	this->pFeedback->SetPosition(CVector(43, 34));
	this->pFeedback->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pFeedback);

	this->pTime = new CKnob(*this, "Time", 0.0f, 4.0f, 2.0f);
	this->pTime->SetPosition(CVector(77, 34));
	this->pTime->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pTime);

	this->pRepeat = new CKnob(*this, "Repeat", 1.0f, 4.0f, 1.0f, true, -125.0f, 0.0f);
	this->pRepeat->SetPosition(CVector(111, 34));
	this->pRepeat->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pRepeat);

	this->pReverse = new CToggle(*this, "Reverse", false);
	this->pReverse->SetPosition(CVector(34, 20));
	this->pReverse->SetOnTexture(this->Engine.LoadTexture("units/toggle_small_on.png"));
	this->pReverse->SetOffTexture(this->Engine.LoadTexture("units/toggle_small_off.png"));
	this->Controls.push_back(this->pReverse);

	this->pLong = new CToggle(*this, "Long", false);
	this->pLong->SetPosition(CVector(102, 20));
	this->pLong->SetOnTexture(this->Engine.LoadTexture("units/toggle_small_on.png"));
	this->pLong->SetOffTexture(this->Engine.LoadTexture("units/toggle_small_off.png"));
	this->Controls.push_back(this->pLong);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->uiReverseSample = 0;
	this->uiReverseOffset = 0;

	return true;
}

void CDelay::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	this->pFeedback = 0;
	this->pTime = 0;
	this->pRepeat = 0;
	this->pReverse = 0;
	this->pLong = 0;
	this->pStomp = 0;

	this->Buffer.Clear();
}

void CDelay::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

#define REVERSE_FADE_TIME 0.01f

void CDelay::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	this->Buffer.SetSamples(uiSamplesPerSecond * (unsigned int)ceilf(this->pTime->GetMax()) * (unsigned int)ceilf(this->pRepeat->GetMax()) + uiSamples);
	this->Buffer.Advance(uiSamples, lpData);

	if(!this->pStomp->GetPressed())
	{
		this->uiReverseSample = 0;
		this->uiReverseOffset = 0;

		return;
	}

	float fDepth = this->pDepth->GetValue();
	float fOneMinusDepth = 1.0f - fDepth;
	float fFeedback = this->pFeedback->GetValue();
	float fTime = this->pTime->GetValue();
	unsigned int uiRepeat = (unsigned int)this->pRepeat->GetValue();
	if(!this->pLong->GetOn())
	{
		fTime /= 8.0f;
	}

	// A + B - A * B
	unsigned int uiTime = (unsigned int)((float)uiSamplesPerSecond * fTime);

	if(uiTime == 0)
	{
		return;
	}

	unsigned int i, j, uiNormalize = 0;
	for(i = 0; i < uiRepeat; i++)
	{
		uiNormalize += uiRepeat - i;
	}
	fDepth *= 1.0f / (float)uiNormalize;

	unsigned int uiBufferOffset;
	if(!this->pReverse->GetOn())
		uiBufferOffset = this->Buffer() - uiTime - uiSamples;
	else
		uiBufferOffset = this->Buffer() - this->uiReverseOffset - uiSamples;

	if(!this->pReverse->GetOn())
	{
		for(i = 0; i < uiSamples; i++)
		{
			float fRepeat = 0.0f;
			for(j = 0; j < uiRepeat; j++)
			{
				fRepeat += (float)(uiRepeat - j) * this->Buffer[uiBufferOffset - uiTime * j + i];
			}
			lpData[i] = fOneMinusDepth * lpData[i] + fDepth * fRepeat;
		}
	}
	else
	{
		unsigned int uiFadeSamples = (unsigned int)floorf((float)uiSamplesPerSecond * REVERSE_FADE_TIME);
		if(uiFadeSamples > uiTime / 2)
			uiFadeSamples = uiTime / 2;
		float fFadeDepth = fDepth / (float)uiFadeSamples;

		i = 0;
		while(i < uiSamples)
		{
			if(this->uiReverseSample >= uiTime)
			{
				this->uiReverseSample = 0;
				this->uiReverseOffset = 0;
				uiBufferOffset = this->Buffer() - uiSamples;
			}

			while(i < uiSamples && this->uiReverseSample < uiFadeSamples)
			{
				float fRepeat = 0.0f;
				for(j = 0; j < uiRepeat; j++)
				{
					fRepeat += (float)(uiRepeat - j) * this->Buffer[uiBufferOffset - uiTime * j - this->uiReverseSample];
				}

				lpData[i] = fOneMinusDepth * lpData[i] + (float)this->uiReverseSample * fFadeDepth * fRepeat;
				this->uiReverseSample++;
				i++;
			}

			while(i < uiSamples && this->uiReverseSample < uiTime - uiFadeSamples)
			{
				float fRepeat = 0.0f;
				for(j = 0; j < uiRepeat; j++)
				{
					fRepeat += (float)(uiRepeat - j) * this->Buffer[uiBufferOffset - uiTime * j - this->uiReverseSample];
				}

				lpData[i] = fOneMinusDepth * lpData[i] + fDepth * fRepeat;
				this->uiReverseSample++;
				i++;
			}

			while(i < uiSamples && this->uiReverseSample < uiTime)
			{
				float fRepeat = 0.0f;
				for(j = 0; j < uiRepeat; j++)
				{
					fRepeat += (float)(uiRepeat - j) * this->Buffer[uiBufferOffset - uiTime * j - this->uiReverseSample];
				}

				lpData[i] = fOneMinusDepth * lpData[i] + (float)(uiTime - this->uiReverseSample) * fFadeDepth * fRepeat;
				this->uiReverseSample++;
				i++;
			}
		}
		this->uiReverseOffset += uiSamples;
	}

	if(fFeedback != 0.0f)
	{
		float fOneMinusFeedback = 1.0f - fFeedback;
		for(unsigned int i = 0; i < uiSamples; i++)
		{
			unsigned int uiIndex = this->Buffer() - uiSamples + i;
			this->Buffer[uiIndex] = fOneMinusFeedback * this->Buffer[uiIndex] + fFeedback * lpData[i];
		}
	}
}
