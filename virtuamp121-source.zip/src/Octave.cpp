/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "FFT.h"
#include "Octave.h"

using namespace VAmp;
using namespace VAmp::Units;

namespace VAmp
{
	int lpOctaveSteps[] = { -24, -12, 0, 4, 12, 19, 24 };
}

LINK_UNIT(COctaveInfo, COctave, OctaveInfo);

COctave::COctave(CEngine &Engine) : CUnit(COctave::OctaveInfo, Engine), pPower(0), pDepth(0), pStomp(0), Buffer()
{
	for(unsigned int i = 0; i < OCTAVE_SLIDERS; i++)
	{
		lpOctaves[i] = 0;
	}
}

COctave::~COctave()
{
	this->Unload();
}

bool COctave::LoadInternal()
{
	unsigned int i;

	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/octave.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CVerticalSlider(*this, "Depth", 0.0f, 1.0f, 0.5f, 22.0f, -22.0f);
	this->pDepth->SetPosition(CVector(16, 48));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/slider.png"));
	this->Controls.push_back(this->pDepth);

	for(i = 0; i < OCTAVE_SLIDERS; i++)
	{
		char lpBand[64];
		sprintf(lpBand, "Octave %d", lpOctaveSteps[i]);
		this->lpOctaves[i] = new CVerticalSlider(*this, lpBand, 0.0f, 1.0f, 0.0f, 22.0f, -22.0f);
		this->lpOctaves[i]->SetPosition(CVector(32 + i * 16, 48));
		this->lpOctaves[i]->SetTexture(this->Engine.LoadTexture("units/slider.png"));
		this->Controls.push_back(this->lpOctaves[i]);
	}

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->uiNoteSample = 0;
	this->fNoteFrequency = 0.0f;
	this->fNoteVolume = 0.0f;
	for(i = 0; i < OCTAVE_FREQUENCY_HISTORY; i++)
	{
		this->fNoteFrequencyHistory[i] = 0.0f;
	}
	this->eSchmittTriggerState = SCHMITT_TRIGGER_STATE_UNSET;
	for(i = 0; i < OCTAVE_SLIDERS; i++)
	{
		this->lpX[i] = 0.0f;
	}

	return true;
}

void COctave::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	for(unsigned int i = 0; i < OCTAVE_SLIDERS; i++)
	{
		lpOctaves[i] = 0;
	}
	this->pStomp = 0;

	this->Buffer.Clear();
}

void COctave::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

#define OCTAVE_MIN_FREQUENCY 25
#define OCTAVE_RECALIBRATION_FREQUENCY 40
#define OCTAVE_TRIGGER_THRESHOLD 0.2f

// http://www.bassplayer.com/story.aspx?content_id=24674
// http://sp.cs.tut.fi/publications/theses/doctoral/Klapuri2004.pdf
void COctave::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	unsigned int i, j;

	this->Buffer.SetSamples(uiSamplesPerSecond / OCTAVE_MIN_FREQUENCY + uiSamples);
	this->Buffer.Advance(uiSamples, lpData);

	if(!this->pStomp->GetPressed())
	{
		this->uiNoteSample = 0;
		this->fNoteFrequency = 0.0f;
		this->fNoteVolume = 0.0f;
		for(i = 0; i < OCTAVE_FREQUENCY_HISTORY; i++)
		{
			this->fNoteFrequencyHistory[i] = 0.0f;
		}
		this->eSchmittTriggerState = SCHMITT_TRIGGER_STATE_UNSET;
		for(i = 0; i < OCTAVE_SLIDERS; i++)
		{
			this->lpX[i] = 0.0f;
		}
		return;
	}

	float fDepth = this->pDepth->GetValue();
	if(fDepth == 0.0f)
	{
		return;
	}
	float fOneMinusDepth = 1.0f - fDepth;

	unsigned int uiOctaves = 0;
	for(i = 0; i < OCTAVE_SLIDERS; i++)
	{
		if(this->lpOctaves[i]->GetValue() > 0.0f)
		{
			uiOctaves += 1;
		}
	}

	if(uiOctaves > 0)
	{
		float lpOctaveFrequencies[OCTAVE_SLIDERS];
		for(i = 0; i < OCTAVE_SLIDERS; i++)
		{
			lpOctaveFrequencies[i] = this->fNoteFrequency * powf(2.0f, lpOctaveSteps[i] / 12.0f);
		}

		fDepth /= (float)uiOctaves;

		unsigned int uiFrequencySamples = uiSamplesPerSecond / OCTAVE_MIN_FREQUENCY;
		unsigned int uiRecalibrationSamples = uiSamplesPerSecond / OCTAVE_RECALIBRATION_FREQUENCY;
		float fSampleFrequency = VA_2PI / (float)uiSamplesPerSecond;
		for(i = 0; i < uiSamples; i++)
		{
			// Periodicly recalculate fundamental frequency.
			if(this->eSchmittTriggerState == SCHMITT_TRIGGER_STATE_UNSET || this->uiNoteSample > uiRecalibrationSamples)
			{
				float *lpBuffer = this->Buffer.GetBuffer() + i;

				float fMin, fMax;
				fMin = fMax = *lpBuffer;
				for(j = 0; j < uiFrequencySamples; j++)
				{
					if(lpBuffer[j] < fMin)
						fMin = lpBuffer[j];
					if(lpBuffer[j] > fMax)
						fMax = lpBuffer[j];
				}

				// Adjust trigger threshold to waveform amplitude.
				float fTriggerUp = fMax - (fMax - fMin) * OCTAVE_TRIGGER_THRESHOLD;
				float fTriggerDown = fMin + (fMax - fMin) * OCTAVE_TRIGGER_THRESHOLD;

				// Simulate a Schmitt Trigger (used by various Octave pedals to generate the fundamental frequency).
				unsigned int uiStateChanges = 0;
				for(j = 0; j < uiFrequencySamples; j++)
				{
					switch(this->eSchmittTriggerState)
					{
					case SCHMITT_TRIGGER_STATE_UP:
						if(lpBuffer[j] < fTriggerDown)
						{
							this->eSchmittTriggerState = SCHMITT_TRIGGER_STATE_DOWN;
							uiStateChanges++;
						}
						break;
					case SCHMITT_TRIGGER_STATE_DOWN:
						if(lpBuffer[j] > fTriggerUp)
						{
							this->eSchmittTriggerState = SCHMITT_TRIGGER_STATE_UP;
							uiStateChanges++;
						}
						break;
					case SCHMITT_TRIGGER_STATE_UNSET:
						if(lpBuffer[j] < fTriggerDown)
						{
							this->eSchmittTriggerState = SCHMITT_TRIGGER_STATE_DOWN;
						}
						else
						{
							this->eSchmittTriggerState = SCHMITT_TRIGGER_STATE_UP;
						}
						break;
					}
				}

				//if(uiStateChanges % 2 == 1)
				//	uiStateChanges++;

				// Fundamental frequency is roughly twice the number of state changes.
				//uiStateChanges *= 2;

				// Fix obvious harmonics.
				while(uiStateChanges > 2000)
					uiStateChanges /= 2;

				// New note frequency averaged over short period of time.
				float fNoteFrequency = (float)uiStateChanges * ((float)uiSamplesPerSecond / (float)uiFrequencySamples);
				float fTemp = fNoteFrequency;
				for(j = 1; j < OCTAVE_FREQUENCY_HISTORY; j ++)
				{
					this->fNoteFrequencyHistory[j - 1] = this->fNoteFrequencyHistory[j];
					fNoteFrequency += this->fNoteFrequencyHistory[j];
				}
				this->fNoteFrequencyHistory[OCTAVE_FREQUENCY_HISTORY - 1] = fTemp;
				fNoteFrequency /= float(OCTAVE_FREQUENCY_HISTORY);

				// Adjust synthetic waveform phases to smooth note transitions.
				float fRatio = fNoteFrequency != 0.0f ? this->fNoteFrequency / fNoteFrequency : 0.0f;
				for(j = 0; j < OCTAVE_SLIDERS; j++)
				{
					this->lpX[j] *= fRatio;
				}

				this->fNoteFrequency = fNoteFrequency;
				this->fNoteVolume = (fMax - fMin) * 0.5f;

				for(j = 0; j < OCTAVE_SLIDERS; j++)
				{
					lpOctaveFrequencies[j] = this->fNoteFrequency * powf(2.0f, lpOctaveSteps[j] / 12.0f);
				}
			}

			// Sum synthetic notes.
			float fOctaveSum = 0.0f;
			for(j = 0; j < OCTAVE_SLIDERS; j++)
			{
				if(this->lpOctaves[j]->GetValue() > 0.0f)
				{
					fOctaveSum += sinf(fSampleFrequency * lpOctaveFrequencies[j] * this->lpX[j]++) * this->lpOctaves[j]->GetValue();
				}
			}
			// Blend wet and dry.
			lpData[i] = lpData[i] * fOneMinusDepth + fOctaveSum * fDepth * fNoteVolume;

			this->uiNoteSample++;
		}

		if(this->fNoteFrequency != 0.0f)
		{
			for(i = 0; i < OCTAVE_SLIDERS; i++)
			{
				this->lpX[i] = fmodf(this->lpX[i], (float)uiSamplesPerSecond / lpOctaveFrequencies[i]);
			}
		}
	}
	else
	{
		for(i = 0; i < uiSamples; i++)
		{
			lpData[i] *= fOneMinusDepth;
		}
	}
}
