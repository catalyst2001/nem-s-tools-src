/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Configuration.h"
#include "Engine.h"
#include "Log.h"
#include "WinMMAudio.h"

#pragma warning(disable:4312)

using namespace VAmp;
using namespace VAmp::Audio;

static void CALLBACK WaveInCallbackWrapper(HWAVEIN hWaveIn, UINT uiMessage, DWORD uiInstance, DWORD uiWParam, DWORD uiLParam)
{
	CWinMMAudio *pAudio = reinterpret_cast<CWinMMAudio *>(uiInstance);
	pAudio->WaveInCallback(uiMessage, uiWParam, uiLParam);
}

/*static void CALLBACK WaveOutCallbackWrapper(HWAVEOUT hWaveOut, UINT uiMessage, DWORD uiInstance, DWORD uiWParam, DWORD uiLParam)
{
	CWinMMAudio *pAudio = reinterpret_cast<CWinMMAudio *>(uiInstance);
	pAudio->WaveOutCallback(uiMessage, uiWParam, uiLParam);
}*/

CWinMMAudio::CWinMMAudio(HWND hWnd, CEngine *pEngine) : CAudioDriver(hWnd, pEngine), bPlaying(false), hWaveIn(NULL), lpWaveInHeaders(NULL), lpWaveInBuffers(NULL), hWaveOut(NULL), lpWaveOutHeaders(NULL), lpWaveOutBuffers(NULL)
{

}

CWinMMAudio::~CWinMMAudio()
{
	this->Stop();
}

EAudioDriver CWinMMAudio::GetType() const
{
	return AUDIO_DRIVER_WINDOWS_MULTIMEDIA;
}

bool CWinMMAudio::IsPlaying()
{
	return this->bPlaying;
}

bool CWinMMAudio::Play(unsigned int uiSamplesPerSecond)
{
	if(this->bPlaying)
	{
		return true;
	}

	LogMessage("Starting WindowsMultimedia driver...");

	this->bPlaying = true;

	memset(&this->WaveFormat, 0, sizeof(WAVEFORMATEX));
	this->WaveFormat.wFormatTag = WAVE_FORMAT_IEEE_FLOAT;
	this->WaveFormat.nChannels = 1;
	this->WaveFormat.nSamplesPerSec = uiSamplesPerSecond;
	this->WaveFormat.nAvgBytesPerSec = uiSamplesPerSecond * sizeof(float);
	this->WaveFormat.nBlockAlign = sizeof(float);
	this->WaveFormat.wBitsPerSample = 8 * sizeof(float);
	this->WaveFormat.cbSize = 0;

	this->uiAudioBuffers = Configuration.GetAudioBuffers();

	unsigned int i;
	unsigned int uiBufferSize = uiSamplesPerSecond / Configuration.GetBufferDenominator() / ((this->uiAudioBuffers + 1) / 2);
	unsigned int uiBufferByteSize = uiBufferSize * sizeof(float);

	this->lpWaveInHeaders = new WAVEHDR[this->uiAudioBuffers];
	memset(this->lpWaveInHeaders, 0, this->uiAudioBuffers * sizeof(WAVEHDR));
	this->lpWaveInBuffers = new float *[this->uiAudioBuffers];
	memset(this->lpWaveInBuffers, 0, this->uiAudioBuffers * sizeof(float *));

	this->lpWaveOutHeaders = new WAVEHDR[this->uiAudioBuffers];
	memset(this->lpWaveOutHeaders, 0, this->uiAudioBuffers * sizeof(WAVEHDR));
	this->lpWaveOutBuffers = new float *[this->uiAudioBuffers];
	memset(this->lpWaveOutBuffers, 0, this->uiAudioBuffers * sizeof(float *));

	for(i = 0; i < this->uiAudioBuffers; i++)
	{
		this->lpWaveInBuffers[i] = new float[uiBufferSize];
		memset(this->lpWaveInBuffers[i], 0, uiBufferSize * sizeof(float));

		this->lpWaveInHeaders[i].lpData = (LPSTR)this->lpWaveInBuffers[i];
		this->lpWaveInHeaders[i].dwBufferLength = uiBufferByteSize;

		this->lpWaveOutBuffers[i] = new float[uiBufferSize];
		memset(this->lpWaveInBuffers[i], 0, uiBufferSize * sizeof(float));

		this->lpWaveOutHeaders[i].lpData = (LPSTR)this->lpWaveOutBuffers[i];
		this->lpWaveOutHeaders[i].dwBufferLength = uiBufferByteSize;
	}

	this->uiReceivedBuffers = 0;
	this->uiReceivedSamples = 0;

	MMRESULT Result = waveInOpen(&this->hWaveIn, WAVE_MAPPER, &this->WaveFormat, (DWORD_PTR)WaveInCallbackWrapper, (DWORD_PTR)this, CALLBACK_FUNCTION);
	if(Result == MMSYSERR_NOERROR)
	{
		for(i = 0; i < this->uiAudioBuffers; i++)
		{
			waveInPrepareHeader(this->hWaveIn, &this->lpWaveInHeaders[i], sizeof(WAVEHDR));
			waveInAddBuffer(this->hWaveIn, &this->lpWaveInHeaders[i], sizeof(WAVEHDR));
		}
	}
	else
	{
		this->Stop();

		char lpBuffer[1024] = "Unknown waveInOpen error.";
		waveOutGetErrorText(Result, lpBuffer, sizeof(lpBuffer));
		LogError(lpBuffer);

		return false;
	}

	Result = waveOutOpen(&this->hWaveOut, WAVE_MAPPER, &this->WaveFormat, NULL, (DWORD_PTR)this, CALLBACK_NULL);
	//Result = waveOutOpen(&this->hWaveOut, WAVE_MAPPER, &this->WaveFormat, (DWORD_PTR)WaveOutCallbackWrapper, (DWORD_PTR)this, CALLBACK_FUNCTION);
	if(Result == MMSYSERR_NOERROR)
	{
		//waveOutSetVolume(NULL, 0xffffffff);
		//waveOutSetVolume(this->hWaveOut, 0xffffffff);

		for(i = 0; i < this->uiAudioBuffers; i++)
		{
			waveOutPrepareHeader(this->hWaveOut, &this->lpWaveOutHeaders[i], sizeof(WAVEHDR));
		}

		waveInStart(this->hWaveIn);
	}
	else
	{
		this->Stop();

		char lpBuffer[1024] = "Unknown waveOutOpen error.";
		waveOutGetErrorText(Result, lpBuffer, sizeof(lpBuffer));
		LogError(lpBuffer);

		return false;
	}

	LogMessage("WindowsMultimedia driver started.");

	return true;
}

void CWinMMAudio::Stop()
{
	if(this->bPlaying)
	{
		LogMessage("Stopping WindowsMultimedia driver...");

		this->bPlaying = false;

		unsigned int i;

		if(this->hWaveIn != NULL)
		{
			waveInStop(this->hWaveIn);
			waveInReset(this->hWaveIn);
			for(i = 0; i < this->uiAudioBuffers; i++)
			{
				waveInUnprepareHeader(this->hWaveIn, &this->lpWaveInHeaders[i], sizeof(WAVEHDR));
			}
			waveInClose(this->hWaveIn);
			this->hWaveIn = NULL;
		}

		if(this->hWaveOut != NULL)
		{
			waveOutReset(this->hWaveOut);
			for(i = 0; i < this->uiAudioBuffers; i++)
			{
				waveOutUnprepareHeader(this->hWaveOut, &this->lpWaveOutHeaders[i], sizeof(WAVEHDR));
			}
			waveOutClose(this->hWaveOut);
			this->hWaveOut = NULL;
		}

		delete []this->lpWaveInHeaders;
		this->lpWaveInHeaders = 0;

		if(this->lpWaveInBuffers != NULL)
		{
			for(i = 0; i < this->uiAudioBuffers; i++)
			{
				delete []this->lpWaveInBuffers[i];
			}

			delete []this->lpWaveInBuffers;
			this->lpWaveInBuffers = 0;
		}

		delete []this->lpWaveOutHeaders;
		this->lpWaveOutHeaders = 0;

		if(this->lpWaveOutBuffers != NULL)
		{
			for(i = 0; i < this->uiAudioBuffers; i++)
			{
				delete []this->lpWaveOutBuffers[i];
			}

			delete []this->lpWaveOutBuffers;
			this->lpWaveOutBuffers = 0;
		}

		LogMessage("WindowsMultimedia driver stopped.");
	}
}

void CWinMMAudio::WaveInCallback(UINT uiMessage, DWORD uiWParam, DWORD uiLParam)
{
	if(!this->bPlaying)
	{
		return;
	}

	unsigned int i;

	switch(uiMessage) 
	{
		case WIM_OPEN:
		{
			return;
		}
		case WIM_DATA:
		{
			unsigned int uiIndex = 0;
			for(i = 0; i < this->uiAudioBuffers; i++)
			{
				if(&this->lpWaveInHeaders[i] == reinterpret_cast<PWAVEHDR>(uiWParam))
				{
					uiIndex = i;
					break;
				}
			}

			unsigned int uiSamples = this->lpWaveInHeaders[uiIndex].dwBytesRecorded / sizeof(float);

			this->uiReceivedBuffers++;
			this->uiReceivedSamples += uiSamples;

			memcpy(this->lpWaveOutBuffers[uiIndex], this->lpWaveInBuffers[uiIndex], this->lpWaveInHeaders[uiIndex].dwBufferLength);

			waveInAddBuffer(this->hWaveIn, &this->lpWaveInHeaders[uiIndex], sizeof(WAVEHDR));

			if(this->pEngine != 0)
			{
				this->pEngine->Lock();
				this->pEngine->Process(this->lpWaveOutBuffers[uiIndex], this->WaveFormat.nSamplesPerSec, uiSamples);
				this->pEngine->Unlock();
			}

			if(this->uiReceivedBuffers == (this->uiAudioBuffers + 1) / 2)
			{
				for(i = 0; i < (this->uiAudioBuffers + 1) / 2; i++)
				{
					waveOutWrite(this->hWaveOut, &this->lpWaveOutHeaders[uiIndex], sizeof(WAVEHDR));
				}
			}
			else if(this->uiReceivedBuffers >= this->uiAudioBuffers)
			{
				waveOutWrite(this->hWaveOut, &this->lpWaveOutHeaders[uiIndex], sizeof(WAVEHDR));
			}

			if(this->pEngine->GetUnitRequiresRender() || this->uiReceivedSamples > this->WaveFormat.nSamplesPerSec / Configuration.GetBufferFPS())
			{
				if(this->pEngine != 0)
				{
					this->pEngine->Lock();
					this->pEngine->Render();
					this->pEngine->Unlock();
				}
				this->uiReceivedSamples %= this->WaveFormat.nSamplesPerSec / Configuration.GetBufferFPS();
			}

			return;
		}
		case WIM_CLOSE:
		{
			return;
		}
	}
}

/*void CWinMMAudio::WaveOutCallback(UINT uiMessage, DWORD uiWParam, DWORD uiLParam)
{
	if(!this->bPlaying)
	{
		return;
	}

	switch(uiMessage) 
	{
		case WOM_OPEN:
		{
			return;
		}
		case WOM_DONE:
		{
			return;
		}
		case WOM_CLOSE:
		{
			return;
		}
	}
}*/

#pragma warning(default:4312)
