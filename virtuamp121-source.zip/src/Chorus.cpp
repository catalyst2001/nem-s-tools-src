/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Chorus.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CChorusInfo, CChorus, ChorusInfo);

CChorus::CChorus(CEngine &Engine) : CUnit(CChorus::ChorusInfo, Engine), pPower(0), pDepth(0), pVoices(0), pWidth(0), pRate(0), pStomp(0), Buffer()
{

}

CChorus::~CChorus()
{
	this->Unload();
}

bool CChorus::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/chorus.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CKnob(*this, "Depth", 0.0f, 1.0f, 1.0f);
	this->pDepth->SetPosition(CVector(9, 34));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDepth);

	this->pVoices = new CKnob(*this, "Voices", 1.0f, 7.0f, 4.0f, true);
	this->pVoices->SetPosition(CVector(43, 34));
	this->pVoices->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pVoices);

	this->pWidth = new CKnob(*this, "Width", 0.0025f, 0.02f, 0.01125f);
	this->pWidth->SetPosition(CVector(77, 34));
	this->pWidth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pWidth);

	this->pRate = new CKnob(*this, "Rate", 0.05f, 1.0f, 0.21f);
	this->pRate->SetPosition(CVector(111, 34));
	this->pRate->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pRate);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->fPhase = 0.0f;

	return true;
}

void CChorus::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	this->pVoices = 0;
	this->pWidth = 0;
	this->pRate = 0;
	this->pStomp = 0;

	this->Buffer.Clear();
}

void CChorus::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

#define CHORUS_DELAY 0.015f

void CChorus::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	this->Buffer.SetSamples((unsigned int)ceilf((float)uiSamplesPerSecond * (CHORUS_DELAY + this->pWidth->GetMax())) + uiSamples);
	this->Buffer.Advance(uiSamples, lpData);

	if(!this->pStomp->GetPressed() || this->pDepth->GetValue() == 0.0f)
	{
		this->fPhase = 0.0f;
		return;
	}

	float fDepth = this->pDepth->GetValue();
	unsigned int uiVoices = (unsigned int)this->pVoices->GetValue();
	float fWidth = this->pWidth->GetValue() * (float)uiSamplesPerSecond;
	float fRate = VA_2PI / ((float)uiSamplesPerSecond / this->pRate->GetValue());

	// Equally space voice phases.
	float fPhaseOffset = ((float)uiSamplesPerSecond / this->pRate->GetValue()) / (float)uiVoices;

	// Normalize so at depth 0 we only hear dry and at depth 1 we hear dry and each voice equally.
	float fNormalize = 1.0f / (float)(1 + uiVoices);
	float fOneMinusDepth = (1.0f - fDepth) + fDepth * fNormalize;
	fDepth *= fNormalize;

	unsigned int uiBufferOffset = this->Buffer() - uiSamples - (unsigned int)(CHORUS_DELAY * (float)uiSamplesPerSecond);
	for(unsigned int i = 0; i < uiSamples; i++)
	{
		float fChorus = 0.0f;
		for(unsigned int j = 0; j < uiVoices; j++)
		{
			unsigned int uiOffset = (unsigned int)((cosf((fPhase + (float)j * fPhaseOffset) * fRate) + 1.0f) * 0.5f * fWidth);
			fChorus += this->Buffer[uiBufferOffset + i - uiOffset];
		}
		fPhase++;

		lpData[i] = fOneMinusDepth * lpData[i] + fDepth * fChorus;
	}

	this->fPhase = fmodf(this->fPhase, (float)uiSamplesPerSecond / this->pRate->GetValue());
}
