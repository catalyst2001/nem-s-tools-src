/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "FFT.h"
#include "FFTBuffer.h"

using namespace VAmp::DSP;

CFFTBuffer::CFFTBuffer(unsigned int uiSegmentSamples) : iSegment(-1), uiSegmentSamples(uiSegmentSamples), uiSegmentIndex(0), uiBufferIndex(0)
{
	assert(DSP::IsPowerOfTwo(uiSegmentSamples));

	this->lpWeights = new float[this->uiSegmentSamples / 2];
	memset(this->lpWeights, 0, sizeof(float) * (this->uiSegmentSamples / 2));

	unsigned int i;
	for(i = 0; i < 2; i ++)
	{
		this->lpSegments[i] = new float[this->uiSegmentSamples];

		this->lpFFTIn[i] = new float[this->uiSegmentSamples];
		this->lpFFTOut[i] = new float[this->uiSegmentSamples];
	}

	this->lpWindow = new float[this->uiSegmentSamples];
	for(i = 0; i < this->uiSegmentSamples; i++)
	{
		this->lpWindow[i] = 1.0f;
	}
	DSP::ComputeWindow(DSP::WINDOW_HANNING, this->uiSegmentSamples, this->lpWindow);

	this->lpBuffer = new float[(3 * this->uiSegmentSamples) / 2];
	memset(this->lpBuffer, 0, sizeof(float) * ((3 * this->uiSegmentSamples) / 2));
}

CFFTBuffer::~CFFTBuffer()
{
	delete []this->lpWeights;

	for(unsigned int i = 0; i < 2; i ++)
	{
		delete []this->lpSegments[i];

		delete []this->lpFFTIn[i];
		delete []this->lpFFTOut[i];
	}

	delete []this->lpWindow;

	delete []this->lpBuffer;
}

void CFFTBuffer::Clear()
{
	this->iSegment = -1;

	this->uiBufferIndex = 0;
	memset(this->lpBuffer, 0, sizeof(float) * ((3 * this->uiSegmentSamples) / 2));
}

void CFFTBuffer::Advance(bool bApplyFilter, unsigned int uiSamples, float *lpSamples)
{
	unsigned int uiBufferSamples = (3 * this->uiSegmentSamples) / 2;

	if(bApplyFilter)
	{
		unsigned int uiSegmentSamplesOverTwo = this->uiSegmentSamples / 2;
		if(this->iSegment == -1)
		{
			// The first time the filter is applied we need to calculate the initial
			// overlapped segments.
			this->iSegment = 0;
			this->uiSegmentIndex = 0;
			this->Filter(1, this->uiBufferIndex);
			this->Filter(0, (this->uiBufferIndex + uiSegmentSamplesOverTwo) % uiBufferSamples);
		}

		int iLastSegment = (this->iSegment + 1) % 2;
		for(unsigned int i = 0; i < uiSamples; i++)
		{
			if(this->uiSegmentIndex == uiSegmentSamplesOverTwo)
			{
				// Last overlapped segment used up, calculate next overlapped segment.
				this->Filter(iLastSegment, this->uiBufferIndex);

				int iTemp = iLastSegment;
				iLastSegment = this->iSegment;
				this->iSegment = iTemp;

				this->uiSegmentIndex = 0;
			}

			// Place sample into ring buffer.
			this->lpBuffer[this->uiBufferIndex] = lpSamples[i];
			this->uiBufferIndex = (this->uiBufferIndex + 1) % uiBufferSamples;

			// Add the two segments togeather (overlap and add method).
			// Note: lpSamples is delayed by uiSegmentSamples to ensure we always have enough
			// in our buffer to fill lpSamples.
			lpSamples[i] = this->lpSegments[this->iSegment][this->uiSegmentIndex] + this->lpSegments[iLastSegment][uiSegmentSamplesOverTwo + this->uiSegmentIndex];
			this->uiSegmentIndex++;
		}
	}
	else
	{
		this->iSegment = -1;

		if(uiSamples > uiBufferSamples)
		{
			lpSamples += uiSamples - uiBufferSamples;
			uiSamples = uiBufferSamples;
		}

		// Fill ring buffer.
		if(this->uiBufferIndex + uiSamples <= uiBufferSamples)
		{
			memcpy(this->lpBuffer + this->uiBufferIndex, lpSamples, sizeof(float) * uiSamples);
		}
		else
		{
			unsigned int uiRemainingBufferSamples = uiBufferSamples - this->uiBufferIndex;
			memcpy(this->lpBuffer + this->uiBufferIndex, lpSamples, sizeof(float) * uiRemainingBufferSamples);
			memcpy(this->lpBuffer, lpSamples + uiRemainingBufferSamples, sizeof(float) * (uiSamples - uiRemainingBufferSamples));
		}
		this->uiBufferIndex = (this->uiBufferIndex + uiSamples) % uiBufferSamples;
	}
}

void CFFTBuffer::Filter(int iSegment, unsigned int uiBufferIndex)
{
	this->PrepareFFTBuffer(uiBufferIndex);
	this->FilterFFTBuffer(iSegment);
}

void CFFTBuffer::PrepareFFTBuffer(unsigned int uiBufferIndex)
{
	unsigned int uiBufferSamples = (3 * this->uiSegmentSamples) / 2;
	if(uiBufferIndex + this->uiSegmentSamples <= uiBufferSamples)
	{
		memcpy(this->lpFFTIn[0], this->lpBuffer + uiBufferIndex, sizeof(float) * this->uiSegmentSamples);
	}
	else
	{
		unsigned int uiRemainingBufferSamples = uiBufferSamples - uiBufferIndex;
		memcpy(this->lpFFTIn[0], this->lpBuffer + uiBufferIndex, sizeof(float) * uiRemainingBufferSamples);
		memcpy(this->lpFFTIn[0] + uiRemainingBufferSamples, this->lpBuffer, sizeof(float) * (this->uiSegmentSamples - uiRemainingBufferSamples));
	}
}

void CFFTBuffer::FilterFFTBuffer(int iSegment)
{
	DSP::ComputeFFT(this->uiSegmentSamples, false, this->lpFFTIn[0], 0, this->lpFFTOut[0], this->lpFFTOut[1]);

	unsigned int i, uiSegmentSamplesOverTwo = this->uiSegmentSamples / 2;
	for(i = 0; i < uiSegmentSamplesOverTwo; i++)
	{
		this->lpFFTOut[0][i] *= this->lpWeights[i];
		this->lpFFTOut[1][i] *= this->lpWeights[i];

		unsigned int uiMirrorIndex = this->uiSegmentSamples - i - 1;
		this->lpFFTOut[0][uiMirrorIndex] *= this->lpWeights[i];
		this->lpFFTOut[1][uiMirrorIndex] *= this->lpWeights[i];
	}

	DSP::ComputeFFT(this->uiSegmentSamples, true, this->lpFFTOut[0], this->lpFFTOut[1], this->lpFFTIn[0], this->lpFFTIn[1]);
	memcpy(this->lpSegments[iSegment], this->lpFFTIn[0], sizeof(float) * this->uiSegmentSamples);

	for(i = 0; i < this->uiSegmentSamples; i++)
	{
		this->lpSegments[iSegment][i] *= this->lpWindow[i];
	}
	//DSP::ComputeWindow(DSP::WINDOW_HANNING, this->uiSegmentSamples, this->lpSegments[iSegment]);
}