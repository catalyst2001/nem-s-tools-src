/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "virtuAmp.h"
#include "Configuration.h"
#include "Engine.h"
#include "Log.h"

using namespace VAmp;

CEngine::CEngine() : hWnd(NULL), hDC(0), hGLRC(0), bInitialized(false), uiCurrent(0), fAspectRatio(1.0f), uiWidth(0), uiHeight(0), bCacheTextureMode(false), pLeftMouseDownCable(0), pLeftMouseDownUnit(0), pLeftMouseDownControl(0), LastMousePosition(0, 0), pSelectedUnit(0), bUseLoadPosition(false), LoadPosition(8, 8), pPreamp(0), pSpeakerCabinet(0)
{
	InitializeCriticalSection(&this->CriticalSection);
}

CEngine::~CEngine()
{
	this->Destroy();
	this->UnloadTextureCache();

	DeleteCriticalSection(&this->CriticalSection);
}

void CEngine::Lock()
{
	EnterCriticalSection(&this->CriticalSection);
}

void CEngine::Unlock()
{
	LeaveCriticalSection(&this->CriticalSection);
}

bool CEngine::IsInitialized()
{
	return this->bInitialized;
}

bool CEngine::Initialize(HWND hWnd)
{
	this->Destroy();

	LogMessage("Initializing engine...");

	this->hWnd = hWnd;

	int iPixelFormat;
	PIXELFORMATDESCRIPTOR PixelFormat;

	// Fill in the pixel format descriptor with our info.
	PixelFormat.nSize = sizeof(PIXELFORMATDESCRIPTOR);
	PixelFormat.nVersion = 1;
	PixelFormat.dwFlags = PFD_DOUBLEBUFFER | PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL;
	PixelFormat.iPixelType = PFD_TYPE_RGBA;
	PixelFormat.cColorBits = 32;
	PixelFormat.cRedBits = 0;
	PixelFormat.cRedShift = 0;
	PixelFormat.cGreenBits = 0;
	PixelFormat.cGreenShift = 0;
	PixelFormat.cBlueBits = 0;
	PixelFormat.cBlueShift = 0;
	PixelFormat.cAlphaBits = 8;
	PixelFormat.cAlphaShift = 0;
	PixelFormat.cAccumBits = 0;
	PixelFormat.cAccumRedBits = 0;
	PixelFormat.cAccumGreenBits = 0;
	PixelFormat.cAccumBlueBits = 0;
	PixelFormat.cAccumAlphaBits = 0;
	PixelFormat.cDepthBits = 0;
	PixelFormat.cStencilBits = 0;
	PixelFormat.cAuxBuffers = 0;
	PixelFormat.iLayerType = PFD_MAIN_PLANE;
	PixelFormat.bReserved = 0;
	PixelFormat.dwLayerMask =0;
	PixelFormat.dwVisibleMask = 0;
	PixelFormat.dwDamageMask = 0;

	this->hDC = GetDC(this->hWnd);

	if(this->hDC == 0)
	{
		LogSystemError("GetDC() failed.");

		this->Destroy();
		return false;
	}

	// Find the best match with the device context.
	if((iPixelFormat = ChoosePixelFormat(this->hDC, &PixelFormat)) == 0)
	{
		LogSystemError("ChoosePixelFormat() failed.");

		this->Destroy();
		return false;
	}

	// Set the pixel format for the device context.
	if(SetPixelFormat(this->hDC, iPixelFormat, &PixelFormat) == FALSE)
	{
		LogSystemError("SetPixelFormat() failed.");

		this->Destroy();
		return false;
	}

	// Create an OpenGL context.
	if((this->hGLRC = wglCreateContext(this->hDC)) == 0)
	{
		LogSystemError("wglCreateContext() failed.");

		this->Destroy();
		return false;
	}

	// Make sure it is a valid context.
	if(!this->MakeCurrent())
	{
		LogSystemError("wglMakeCurrent() failed.");

		this->Destroy();
		return false;
	}

	this->MakeNotCurrent();

	LogMessage("Engine initialized.");

	this->bInitialized = true;

	this->Resize();

	return true;
}

void CEngine::Destroy()
{
	if(!this->bInitialized)
	{
		return;
	}

	LogMessage("Destroying engine...");

	this->Clear();

	if(this->MakeCurrent())
	{
		for(CTextureList::iterator Texture = this->Textures.begin(); Texture != this->Textures.end(); ++Texture)
		{
			if((*Texture)->uiReferences > 0)
			{
				glDeleteTextures(1, &(*Texture)->uiID);
			}
			delete *Texture;
		}
		this->Textures.clear();
		this->MakeNotCurrent();
	}
	else
	{
		for(CTextureList::iterator Texture = this->Textures.begin(); Texture != this->Textures.end(); ++Texture)
		{
			delete *Texture;
		}
		this->Textures.clear();
	}

	if(this->hGLRC != 0)
	{
		wglDeleteContext(this->hGLRC);
		this->hGLRC = 0;
	}

	if(this->hDC != 0)
	{
		ReleaseDC(this->hWnd, this->hDC);
		this->hDC = 0;
	}

	this->hWnd = 0;

	this->bInitialized = false;
	this->uiCurrent = 0;

	this->fAspectRatio = 1.0f;
	this->uiWidth = 0;
	this->uiHeight = 0;

	LogMessage("Engine destroyed.");
}

void CEngine::Resize()
{
	if(!this->bInitialized)
	{
		return;
	}

	if(!this->MakeCurrent())
	{
		return;
	}

	RECT Rect;
	GetClientRect(this->hWnd, &Rect);

	if(Rect.right - Rect.left == 0 || Rect.bottom - Rect.top == 0)
	{
		return;
	}

	this->uiWidth = (unsigned int)(Rect.right - Rect.left);
	this->uiHeight = (unsigned int)(Rect.bottom - Rect.top);
	this->fAspectRatio = (float)this->uiWidth / (float)this->uiHeight;

	glViewport(Rect.left, Rect.top, this->uiWidth, this->uiHeight);

	this->MakeNotCurrent();
}

bool CEngine::MakeCurrent()
{
	if(wglMakeCurrent(this->hDC, this->hGLRC) != FALSE)
	{
		this->uiCurrent++;
		return true;
	}

	return false;
}

void CEngine::MakeNotCurrent()
{
	if(this->uiCurrent == 0)
	{
		return;
	}

	this->uiCurrent--;

	if(this->uiCurrent == 0)
	{
		wglMakeCurrent(0, 0);
	}
}

void CEngine::Render()
{
	if(!this->bInitialized)
	{
		return;
	}

	if(!this->MakeCurrent())
	{
		return;
	}

	glClearColor(0.4f, 0.4f, 0.4f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-0.25, (double)this->uiWidth - 0.25, (double)this->uiHeight - 0.25, -0.25);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glEnable(GL_TEXTURE_2D);
	for(CCableList::iterator Cable = this->Cables.begin(); Cable != this->Cables.end(); ++Cable)
	{
		if((*Cable)->GetInput() == 0 || (*Cable)->GetOutput() == 0)
		{
			(*Cable)->Render();
		}
	}
	for(CUnitList::iterator Unit = this->Units.begin(); Unit != this->Units.end(); ++Unit)
	{
		if((*Unit)->GetInput())
		{
			(*Unit)->GetInput()->Render();
		}
		if((*Unit)->GetOutput())
		{
			(*Unit)->GetOutput()->Render();
		}
		(*Unit)->Render();
	}
	glDisable(GL_TEXTURE_2D);

	glFlush();
	SwapBuffers(this->hDC);

	this->MakeNotCurrent();
}

bool CEngine::HandleMessage(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case WM_COMMAND:
		{
			ECableInterp eCableInterp = CABLE_INTERP_COUNT;
			switch (LOWORD(wParam))
			{
				case ID_CABLES_LINEAR:
					eCableInterp = CABLE_INTERP_LINEAR;
					break;
				case ID_CABLES_BEZIER:
					eCableInterp = CABLE_INTERP_BEZIER;
					break;
				case ID_CABLES_COMPLEXBEZIER:
					eCableInterp = CABLE_INTERP_COMPLEX_BEZIER;
					break;
				case ID_ADD_CABLE:
				{
					this->Lock();

					Units::CCable *pCable = this->LoadCable();
					if(pCable != 0)
					{
						CVector Head = bUseLoadPosition ? LoadPosition : CVector(8, 8);
						CVector Tail = pCable->GetTail() - pCable->GetHead();

						//if(!bUseLoadPosition)
						{
							bool bInputSet = false;
							for(CUnitList::iterator Unit = this->Units.begin(); Unit != this->Units.end(); ++Unit)
							{
								if(!bInputSet)
								{
									if(!(*Unit)->Info.IsSpeakerCabinet() && (*Unit)->GetOutput() == 0)
									{
										pCable->SetInput(*Unit);
										Head = pCable->GetHead();
										bInputSet = true;
									}
								}
								else
								{
									if((*Unit)->Info.IsPreamp() && (*Unit)->GetInput() == 0)
									{
										pCable->SetOutput(*Unit);
										Tail = pCable->GetTail() - Head;
										break;
									}
								}
							}
						}

						pCable->SetHead(Head);
						pCable->SetTail(Head + Tail);
						pCable->Update(true);

						this->Render();
					}

					this->Unlock();
					return true;
				}
				case ID_EFFECTS_REMOVE:
					this->Lock();

					this->UnloadUnit(this->pSelectedUnit);
					this->Render();

					this->Unlock();
					return true;
				case ID_EFFECTS_CLEAR:
					this->Lock();

					this->Clear();
					this->Render();

					this->Unlock();
					return true;
				case ID_EFFECTS_AUTOPOSITION:
				{
					this->Lock();

					bool *lpPositioned = new bool[this->Units.size()];
					memset(lpPositioned, 0, this->Units.size() * sizeof(bool));

					for(CUnitList::const_iterator i = this->Units.begin(); i != this->Units.end(); ++i)
					{
						(*i)->SetPosition(CVector(this->uiWidth, this->uiHeight));
					}

					Units::CUnit *pUnit = this->pPreamp;
					while(pUnit != 0)
					{
						this->AutoPositionUnit(*pUnit);

						int iIndex = 0;
						for(CUnitList::const_iterator i = this->Units.begin(); i != this->Units.end(); ++i)
						{
							if(*i == pUnit)
							{
								lpPositioned[iIndex] = true;
								break;
							}
							iIndex++;
						}

						if(pUnit->GetOutput() != 0)
						{
							pUnit = pUnit->GetOutput()->GetOutput();
						}
						else
						{
							break;
						}
					}

					int iIndex = 0;
					for(CUnitList::const_iterator Unit = this->Units.begin(); Unit != this->Units.end(); ++Unit)
					{
						if(!lpPositioned[iIndex])
						{
							this->AutoPositionUnit(**Unit);
						}
						iIndex++;
					}

					for(CCableList::iterator Cable = this->Cables.begin(); Cable != this->Cables.end(); ++Cable)
					{
						(*Cable)->Update(true);
					}

					delete []lpPositioned;

					this->Render();

					this->Unlock();
					return true;
				}
				case ID_EFFECTS_CLEANCABLES:
				{
					this->Lock();

					for(CCableList::iterator Cable = this->Cables.begin(); Cable != this->Cables.end();)
					{
						if((*Cable)->GetInput() == 0 && (*Cable)->GetOutput() == 0)
						{
							CCableList::iterator Temp = Cable;
							++Cable;
							this->Cables.erase(Temp);
						}
						else
						{
							++Cable;
						}
					}
					this->Render();

					this->Unlock();
					return true;
				}
				default:
				{
					if(LOWORD(wParam) >= ID_ADD_UNIT_BASE && LOWORD(wParam) < ID_ADD_UNIT_BASE + Units::UNIT_TYPE_COUNT)
					{
						this->Lock();

						Units::CUnit *pUnit = this->LoadUnit((Units::EUnitType)(LOWORD(wParam) - ID_ADD_UNIT_BASE));

						if(pUnit != 0)
						{
							if(bUseLoadPosition)
							{
								pUnit->SetPosition(this->LoadPosition);
							}

							this->Render();
						}

						this->Unlock();
						return true;
					}
				}
			}
			if(eCableInterp != CABLE_INTERP_COUNT)
			{
				this->Lock();

				Configuration.SetCableInterp(eCableInterp);

				CheckMenuRadioItem(GetMenu(this->hWnd), ID_CABLES_LINEAR, ID_CABLES_COMPLEXBEZIER, LOWORD(wParam), MF_BYCOMMAND);
				for(CCableList::iterator Cable = this->Cables.begin(); Cable != this->Cables.end(); ++Cable)
				{
					(*Cable)->Update(false);
				}
				this->Render();

				this->Unlock();
				return true;
			}

			return false;
		}
		case WM_MOUSEMOVE:
		//case WM_NCMOUSEMOVE:
		{
			this->Lock();

			CVector MousePosition;
			MousePosition.X = (short)LOWORD(lParam);
			MousePosition.Y = (short)HIWORD(lParam);

			/*if(message == WM_NCMOUSEMOVE)
			{
				POINT Point = { MousePosition.X, MousePosition.Y };
				ScreenToClient(this->hWnd, &Point);
				MousePosition.X = Point.x;
				MousePosition.Y = Point.y;
			}*/

			if(this->pLeftMouseDownCable != 0)
			{
				if(this->bLeftMouseDownCableHead)
				{
					this->pLeftMouseDownCable->SetHead(this->pLeftMouseDownCable->GetHead() + MousePosition - this->LastMousePosition);
				}
				else
				{
					this->pLeftMouseDownCable->SetTail(this->pLeftMouseDownCable->GetTail() + MousePosition - this->LastMousePosition);
				}
				this->pLeftMouseDownCable->Update(false);
				this->Render();
			}
			else if(this->pLeftMouseDownUnit != 0)
			{
				if(this->pLeftMouseDownControl == 0)
				{
					this->pLeftMouseDownUnit->SetPosition(this->pLeftMouseDownUnit->GetPosition() + MousePosition - this->LastMousePosition);
					if(this->pLeftMouseDownUnit->GetInput() != 0)
					{
						this->pLeftMouseDownUnit->GetInput()->Update(true);
					}
					if(this->pLeftMouseDownUnit->GetOutput() != 0)
					{
						this->pLeftMouseDownUnit->GetOutput()->Update(true);
					}
					this->Render();
				}
				else
				{
					switch(this->pLeftMouseDownControl->GetType())
					{
						case Units::CONTROL_TYPE_KNOB:
						{
							Units::CKnob *pKnob = static_cast<Units::CKnob *>(this->pLeftMouseDownControl);
							float fValue = (pKnob->GetTrackingValue() - pKnob->GetMin()) / (pKnob->GetMax() - pKnob->GetMin()) + (float)(MousePosition.X - this->LastMousePosition.X) * 0.00275f;
							fValue = pKnob->GetMin() + fValue * (pKnob->GetMax() - pKnob->GetMin());
							pKnob->SetValue(fValue);
							this->Render();
							break;
						}
						case Units::CONTROL_TYPE_VERTICAL_SLIDER:
						{
							Units::CVerticalSlider *pSlider = static_cast<Units::CVerticalSlider *>(this->pLeftMouseDownControl);
							float fValue = (pSlider->GetValue() - pSlider->GetMin()) / (pSlider->GetMax() - pSlider->GetMin()) + (float)(this->LastMousePosition.Y - MousePosition.Y) * 0.0275f;
							fValue = pSlider->GetMin() + fValue * (pSlider->GetMax() - pSlider->GetMin());
							pSlider->SetValue(fValue);
							this->Render();
							break;
						}
					}
				}
			}

			this->LastMousePosition = MousePosition;

			this->Unlock();
			return true;
		}
		case WM_LBUTTONDOWN:
		{
			this->Lock();

			SetCapture(this->hWnd);

			this->LastMousePosition.X = (short)LOWORD(lParam);
			this->LastMousePosition.Y = (short)HIWORD(lParam);

			this->pLeftMouseDownCable = this->GetCable(this->LastMousePosition, this->bLeftMouseDownCableHead);

			// Don't let the user crab the cable if it is obscured by a unit.
			Units::CUnit *pUnit = this->GetUnit(this->LastMousePosition);
			if(this->pLeftMouseDownCable != 0 && pUnit != 0)
			{
				if(this->bLeftMouseDownCableHead && this->pLeftMouseDownCable->GetInput() != pUnit)
				{
					this->pLeftMouseDownCable = 0;
				}
				else if(!this->bLeftMouseDownCableHead && this->pLeftMouseDownCable->GetOutput() != pUnit)
				{
					this->pLeftMouseDownCable = 0;
				}
			}

			this->pLeftMouseDownUnit = this->pLeftMouseDownCable != 0 ? 0 : pUnit;
			this->pLeftMouseDownControl = this->pLeftMouseDownUnit == 0 ? 0 : this->pLeftMouseDownUnit->GetControl(this->LastMousePosition);

			if(this->pLeftMouseDownUnit != 0 && this->pLeftMouseDownUnit != this->Units.back())
			{
				this->Units.remove(this->pLeftMouseDownUnit);
				this->Units.push_back(this->pLeftMouseDownUnit);
				this->Render();
			}

			this->SetSelectedUnit(pLeftMouseDownUnit);

			this->Unlock();
			return true;
		}
		case WM_LBUTTONUP:
		//case WM_NCLBUTTONUP:
		{
			this->Lock();

			ReleaseCapture();

			this->LastMousePosition.X = (short)LOWORD(lParam);
			this->LastMousePosition.Y = (short)HIWORD(lParam);

			if(this->pLeftMouseDownCable != 0)
			{
				Units::CUnit *pBest = 0;
				if(this->bLeftMouseDownCableHead)
				{
					if(this->pLeftMouseDownCable->GetInput() != 0 && (this->pLeftMouseDownCable->GetHead() - this->pLeftMouseDownCable->GetInput()->GetPosition() - this->pLeftMouseDownCable->GetInput()->GetOutputJack()).GetLength() <= CABLE_RADIUS)
					{
						pBest = this->pLeftMouseDownCable->GetInput();
					}
				}
				else
				{
					if(this->pLeftMouseDownCable->GetOutput() != 0 && (this->pLeftMouseDownCable->GetTail() - this->pLeftMouseDownCable->GetOutput()->GetPosition() - this->pLeftMouseDownCable->GetOutput()->GetInputJack()).GetLength() <= CABLE_RADIUS)
					{
						pBest = this->pLeftMouseDownCable->GetOutput();
					}
				}

				if(pBest == 0)
				{
					for(CUnitList::const_iterator i = this->Units.begin(); i != this->Units.end(); ++i)
					{
						if(this->bLeftMouseDownCableHead)
						{
							if((this->pLeftMouseDownCable->GetHead() - (*i)->GetPosition() - (*i)->GetOutputJack()).GetLength() <= CABLE_RADIUS)
							{
								pBest = *i;
								break;
							}
						}
						else
						{
							if((this->pLeftMouseDownCable->GetTail() - (*i)->GetPosition() - (*i)->GetInputJack()).GetLength() <= CABLE_RADIUS)
							{
								pBest = *i;
								break;
							}
						}
					}

					if(pBest != 0)
					{
						if(this->bLeftMouseDownCableHead)
						{
							if(pBest->GetOutput())
							{
								pBest->GetOutput()->SetInput(0);
							}
							if(!pBest->Info.IsSpeakerCabinet())
							{
								this->pLeftMouseDownCable->SetInput(pBest);
							}
							else
							{
								pBest = 0;
							}
						}
						else
						{
							if(pBest->GetInput())
							{
								pBest->GetInput()->SetOutput(0);
							}
							if(!pBest->Info.IsPreamp())
							{
								this->pLeftMouseDownCable->SetOutput(pBest);
							}
							else
							{
								pBest = 0;
							}
						}
					}
				}

				if(pBest == 0)
				{
					if(this->bLeftMouseDownCableHead)
					{
						this->pLeftMouseDownCable->SetInput(0);
					}
					else
					{
						this->pLeftMouseDownCable->SetOutput(0);
					}
				}

				this->pLeftMouseDownCable->Update(true);
				this->Render();
			}
			else if(this->pLeftMouseDownUnit != 0 && this->pLeftMouseDownControl != 0)
			{
				switch(this->pLeftMouseDownControl->GetType())
				{
				case Units::CONTROL_TYPE_BUTTON:
					if(this->pLeftMouseDownUnit == this->GetUnit(this->LastMousePosition) && this->pLeftMouseDownControl == this->pLeftMouseDownUnit->GetControl(this->LastMousePosition))
					{
						Units::CButton *pButton = static_cast<Units::CButton *>(this->pLeftMouseDownControl);
						pButton->Call();
						this->Render();
					}
					break;
				case Units::CONTROL_TYPE_STOMP:
					if(this->pLeftMouseDownUnit == this->GetUnit(this->LastMousePosition) && this->pLeftMouseDownControl == this->pLeftMouseDownUnit->GetControl(this->LastMousePosition))
					{
						Units::CStomp *pStomp = static_cast<Units::CStomp *>(this->pLeftMouseDownControl);
						pStomp->SetPressed(!pStomp->GetPressed());
						this->Render();
					}
					break;
				case Units::CONTROL_TYPE_TOGGLE:
					if(this->pLeftMouseDownUnit == this->GetUnit(this->LastMousePosition) && this->pLeftMouseDownControl == this->pLeftMouseDownUnit->GetControl(this->LastMousePosition))
					{
						Units::CToggle *pToggle = static_cast<Units::CToggle *>(this->pLeftMouseDownControl);
						pToggle->SetOn(!pToggle->GetOn());
						this->Render();
					}
					break;
				}
			}

			this->pLeftMouseDownCable = 0;
			this->pLeftMouseDownUnit = 0;
			this->pLeftMouseDownControl = 0;

			this->Unlock();
			return true;
		}
		case WM_RBUTTONDOWN:
		{
			this->Lock();

			this->LastMousePosition.X = (short)LOWORD(lParam);
			this->LastMousePosition.Y = (short)HIWORD(lParam);

			Units::CUnit *pRightMouseDownUnit = this->GetUnit(this->LastMousePosition);

			if(pRightMouseDownUnit != 0 && pRightMouseDownUnit != this->Units.back())
			{
				this->Units.remove(pRightMouseDownUnit);
				this->Units.push_back(pRightMouseDownUnit);
				this->Render();
			}

			this->SetSelectedUnit(pRightMouseDownUnit);
			this->LoadPosition = this->LastMousePosition;

			this->Unlock();
			return true;
		}
		case WM_RBUTTONUP:
		//case WM_NCRBUTTONUP:
		{
			this->LastMousePosition.X = (short)LOWORD(lParam);
			this->LastMousePosition.Y = (short)HIWORD(lParam);

			//this->pSelectedUnit = 0;
			return false;
		}
		case WM_KEYDOWN:
		{
			this->Lock();

			int iShortcut = (int)wParam;
			CVector Position = this->pSelectedUnit == 0 ? CVector::Null : this->pSelectedUnit->GetPosition();
			switch(iShortcut)
			{
			case VK_UP:
				Position.Y -= 1;
				break;
			case VK_DOWN:
				Position.Y += 1;
				break;
			case VK_LEFT:
				Position.X -= 1;
				break;
			case VK_RIGHT:
				Position.X += 1;
				break;
			case VK_DELETE:
				if(GetKeyState(VK_SHIFT) & 0x80)
				{
					if(this->pSelectedUnit != 0)
					{
						this->pSelectedUnit->SetShortcut(0);
						this->SetSelectedUnit(this->pSelectedUnit);
					}
				}
				break;
			default:
				if(iShortcut != VK_SHIFT && iShortcut != VK_CONTROL && iShortcut != VK_MENU && (GetKeyState(VK_SHIFT) & 0x80))
				{
					if(this->pSelectedUnit != 0)
					{
						this->pSelectedUnit->SetShortcut(iShortcut);
						this->SetSelectedUnit(this->pSelectedUnit);
					}
				}
				else
				{
					for(CUnitList::iterator Unit = this->Units.begin(); Unit != this->Units.end(); ++Unit)
					{
						if((*Unit)->GetShortcut() == iShortcut)
						{
							Units::CControl *pStomp = (*Unit)->GetControl("Stomp");
							if(pStomp != 0 && pStomp->GetType() == VAmp::Units::CONTROL_TYPE_STOMP)
							{
								static_cast<Units::CStomp *>(pStomp)->SetPressed(!static_cast<Units::CStomp *>(pStomp)->GetPressed());
							}
						}
					}
				}
				break;
			}
			if(this->pSelectedUnit != 0 && this->pSelectedUnit->GetPosition() != Position)
			{
				this->pSelectedUnit->SetPosition(Position);
				if(this->pSelectedUnit->GetInput() != 0)
				{
					this->pSelectedUnit->GetInput()->Update(true);
				}
				if(this->pSelectedUnit->GetOutput() != 0)
				{
					this->pSelectedUnit->GetOutput()->Update(true);
				}
				this->Render();
			}

			this->Unlock();
			return true;
		}
		case WM_CONTEXTMENU:
		{
			RECT Rect;
			POINT Point = { (short)LOWORD(lParam), (short)HIWORD(lParam) };
		 
			GetClientRect(this->hWnd, &Rect); 
			ScreenToClient(this->hWnd, &Point); 
			if(PtInRect(&Rect, Point))
			{ 
				ClientToScreen(this->hWnd, &Point);
				TrackPopupMenu(GetSubMenu(GetMenu(this->hWnd), 3), TPM_LEFTALIGN, Point.x, Point.y, 0, this->hWnd, NULL); 
			} 

			return false;
		}
		case WM_INITMENU:
		//case WM_INITMENUPOPUP:
		{
			this->Lock();

			this->bUseLoadPosition = (HMENU)wParam != GetMenu(this->hWnd);
			for(unsigned int i = 0; i < VAmp::Units::UNIT_TYPE_COUNT; i++)
			{
				const VAmp::Units::CUnit::CUnitInfo *pTemplate = VAmp::Units::CUnit::GetUnitInfo((VAmp::Units::EUnitType)i);

				if(pTemplate->IsPreamp())
				{
					EnableMenuItem((HMENU)wParam, ID_ADD_UNIT_BASE + i, this->pPreamp == 0 ? MF_ENABLED : MF_GRAYED);
				}
				if(pTemplate->IsSpeakerCabinet())
				{
					EnableMenuItem((HMENU)wParam, ID_ADD_UNIT_BASE + i, this->pSpeakerCabinet == 0 ? MF_ENABLED : MF_GRAYED);
				}
			}
			EnableMenuItem((HMENU)wParam, ID_EFFECTS_REMOVE, this->pSelectedUnit != 0 ? MF_ENABLED : MF_GRAYED);

			this->Unlock();
			return true;
		}
		default:
		{
			return false;
		}
	}
}

#include "../lib/il.h"
#pragma comment(lib, "../../lib/DevIL.lib")

CTexture *CEngine::LoadTexture(const char *lpFileName)
{
	if(!this->bInitialized)
	{
		return 0;
	}

	for(CTextureList::iterator Texture = this->Textures.begin(); Texture != this->Textures.end(); ++Texture)
	{
		if(_stricmp((*Texture)->GetName(), lpFileName) == 0)
		{
			(*Texture)->uiReferences++;
			return *Texture;
		}
	}

	char lpFullFileName[MAX_PATH];
	GetFullFileName(lpFileName, lpFullFileName, sizeof(lpFullFileName));

	CTexture *pTexture = 0;

	ILuint uiImage;

	ilInit();

	ilEnable(IL_ORIGIN_SET);
	ilOriginFunc(IL_ORIGIN_UPPER_LEFT);

	ilGenImages(1, &uiImage);
	ilBindImage(uiImage);

	LogMessage("Loading %s...", lpFullFileName);

	if(ilLoadImage(lpFullFileName))
	{
		int iWidth = (unsigned int)ilGetInteger(IL_IMAGE_WIDTH);
		int iHeight = (unsigned int)ilGetInteger(IL_IMAGE_HEIGHT);
		int iBytesPerPixel = (unsigned int)ilGetInteger(IL_IMAGE_BYTES_PER_PIXEL);
		CRectangle Rectangle = CRectangle(0, iWidth - 1, iHeight - 1, 0);

		ILboolean bResult;
		if(iBytesPerPixel == 4)
		{
			bResult = ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE);

			if(bResult)
			{
				int x, y;
				bool bTranslucent;
				unsigned char *lpData = ilGetData();

				for(y = 0; y < iHeight; y++)
				{
					bTranslucent = false;
					for(x = 0; x < iWidth; x++)
					{
						if(lpData[(x + y * iWidth) * 4 + 3] > 0)
						{
							bTranslucent = true;
							break;
						}
					}
					Rectangle.Top = y;
					if(bTranslucent)
					{
						break;
					}
				}

				for(x = iWidth - 1; x > 0; x--)
				{
					bTranslucent = false;
					for(y = iHeight - 1; y > 0; y--)
					{
						if(lpData[(x + y * iWidth) * 4 + 3] > 0)
						{
							bTranslucent = true;
							break;
						}
					}
					if(bTranslucent)
					{
						break;
					}
					else
					{
						Rectangle.Right = x;
					}
				}

				for(y = iHeight - 1; y > 0; y--)
				{
					bTranslucent = false;
					for(x = 0; x < iWidth; x++)
					{
						if(lpData[(x + y * iWidth) * 4 + 3] > 0)
						{
							bTranslucent = true;
							break;
						}
					}
					if(bTranslucent)
					{
						break;
					}
					else
					{
						Rectangle.Bottom = y;
					}
				}

				for(x = 0; x < iWidth; x++)
				{
					bTranslucent = false;
					for(y = 0; y < iHeight; y++)
					{
						if(lpData[(x + y * iWidth) * 4 + 3] > 0)
						{
							bTranslucent = true;
							break;
						}
					}
					Rectangle.Left = x;
					if(bTranslucent)
					{
						break;
					}
				}
			}
		}
		else
		{
			iBytesPerPixel = 3;
			bResult = ilConvertImage(IL_RGB, IL_UNSIGNED_BYTE);
		}

		if(bResult)
		{
			if(this->MakeCurrent())
			{
				unsigned int uiID;
				glGenTextures(1, &uiID);

				glBindTexture(GL_TEXTURE_2D, uiID);

				if(uiWidth % 4 == 0)
				{
					glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
				}
				else if(uiWidth % 2 == 0)
				{
					glPixelStorei(GL_UNPACK_ALIGNMENT, 2);
				}
				else
				{
					glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
				}

				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP); 
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP); 

				glTexImage2D(GL_TEXTURE_2D, 0, iBytesPerPixel, iWidth, iHeight, 0, iBytesPerPixel == 4 ? GL_RGBA : GL_RGB, GL_UNSIGNED_BYTE, ilGetData());

				glBindTexture(GL_TEXTURE_2D, 0);

				this->MakeNotCurrent();

				LogMessage("%s loaded (%dx%d @ %d BPP).", lpFullFileName, iWidth, iHeight, iBytesPerPixel);

				pTexture = new CTexture(lpFileName, uiID, iWidth, iHeight, iBytesPerPixel, Rectangle);
				pTexture->uiReferences = 1;
				this->Textures.push_back(pTexture);
			}
			else
			{
				LogSystemError("wglMakeCurrent() failed.");
			}
		}
		else
		{
			LogError("ilConvertImage() failed with error code 0x%.8x.", ilGetError());
		}
	}
	else
	{
		LogError("ilLoadImage() failed with error code 0x%.8x.", ilGetError());
	}

	ilDeleteImages(1, &uiImage);
	ilShutDown();

	return pTexture;
}

void CEngine::UnloadTexture(CTexture *pTexture)
{
	if(!this->bInitialized || pTexture == 0 || pTexture->uiReferences == 0)
	{
		return;
	}

	pTexture->uiReferences--;

	if(!this->bCacheTextureMode && pTexture->uiReferences == 0)
	{
		if(this->MakeCurrent())
		{
			glDeleteTextures(1, &pTexture->uiID);

			this->MakeNotCurrent();
		}

		this->Textures.remove(pTexture);

		delete pTexture;
	}
}

void CEngine::UnloadTextureCache()
{
	if(!this->bInitialized)
	{
		return;
	}

	for(CTextureList::iterator Texture = this->Textures.begin(); Texture != this->Textures.end();)
	{
		if((*Texture)->uiReferences == 0)
		{
			if(this->MakeCurrent())
			{
				glDeleteTextures(1, &(*Texture)->uiID);

				this->MakeNotCurrent();
			}

			CTextureList::iterator Temp = Texture;
			++Texture;
			this->Textures.erase(Temp);
		}
		else
		{
			++Texture;
		}
	}
}

CFont *CEngine::LoadFont(const char *lpFileName)
{
	if(!this->bInitialized)
	{
		return 0;
	}

	for(CFontList::iterator Font = this->Fonts.begin(); Font != this->Fonts.end(); ++Font)
	{
		if(_stricmp((*Font)->GetName(), lpFileName) == 0)
		{
			(*Font)->uiReferences++;
			return *Font;
		}
	}

	char lpFullFileName[MAX_PATH];
	GetFullFileName(lpFileName, lpFullFileName, sizeof(lpFullFileName));

	LogMessage("Loading %s...", lpFullFileName);

	FILE *pFile = fopen(lpFullFileName, "rt");

	if(pFile == 0)
	{
		LogSystemError("Error opening %s for reading.", lpFileName);

		return 0;
	}

	bool bEOF = false;
	unsigned int uiBufferIndex = 0;
	unsigned int uiBufferCount = 0;
	char lpBuffer[8192];

	unsigned int uiLineNumber = 1;
	unsigned int uiLineIndex;
	char lpLine[8192];

	CVector Size = CVector(0, 0);
	CVector Spacing = CVector(0, 0);
	char lpAlphabet[FONT_CHAR_COUNT];
	CTexture *pTexture = 0;

	for(unsigned int i = 0; i < FONT_CHAR_COUNT; i++)
	{
		lpAlphabet[i] = -1;
	}

	while(!bEOF)
	{
		uiLineIndex = 0;
		while(uiLineIndex < sizeof(lpLine) - 1)
		{
			if(uiBufferIndex == uiBufferCount)
			{
				uiBufferIndex = 0;
				uiBufferCount = (unsigned int)fread(lpBuffer, sizeof(char), sizeof(lpBuffer), pFile);
				if(uiBufferCount == 0)
				{
					bEOF = true;
					break;
				}
			}

			if(lpBuffer[uiBufferIndex] == '\r')
			{
				uiBufferIndex++;
				break;
			}
			if(lpBuffer[uiBufferIndex] == '\n')
			{
				uiBufferIndex++;
				uiLineNumber++;
				break;
			}
			lpLine[uiLineIndex++] = lpBuffer[uiBufferIndex++];
		}

		lpLine[uiLineIndex] = '\0';

		char *pComment = strchr(lpLine, '#');
		if(pComment != 0)
		{
			*pComment = '\0';
		}

		char *pLine = lpLine;

		while(*pLine && isspace(*pLine))
		{
			pLine++;
		}

		if(*pLine == '\0')
		{
			continue;
		}

		char *pCommand = pLine, *pValue = pLine;

		while(*pValue && *pValue != '=')
		{
			pValue++;
		}

		if(*pValue == '=')
		{
			*pValue = '\0';

			char *pTemp = pValue - 1;
			while(pTemp > pCommand && isspace(*pTemp))
			{
				*pTemp = '\0';
				pTemp--;
			}

			pValue++;

			while(*pValue && isspace(*pValue))
			{
				pValue++;
			}

			if(_stricmp(pCommand, "Size") == 0)
			{
				if(sscanf(pValue, "[%d, %d]", &Size.X, &Size.Y) != 2)
				{
					LogMessage("Malformed %s on line %u.", pCommand, uiLineNumber);
				}
			}
			else if(_stricmp(pCommand, "Spacing") == 0)
			{
				if(sscanf(pValue, "[%d, %d]", &Spacing.X, &Spacing.Y) != 2)
				{
					LogMessage("Malformed %s on line %u.", pCommand, uiLineNumber);
				}
			}
			else if(_stricmp(pCommand, "Alphabet") == 0)
			{
				int iIndex;

				for(iIndex = 0; *pValue && iIndex < FONT_CHAR_COUNT; pValue++, iIndex++)
				{
					if(*pValue > 0)
					{
						lpAlphabet[*pValue] = (char)iIndex;
					}
				}

				for(iIndex = 'A'; iIndex <= 'Z'; iIndex++)
				{
					if(lpAlphabet[iIndex] == -1)
					{
						lpAlphabet[iIndex] = lpAlphabet[iIndex + ('a' - 'A')];
					}
				}

				for(iIndex = 'a'; iIndex <= 'z'; iIndex++)
				{
					if(lpAlphabet[iIndex] == -1)
					{
						lpAlphabet[iIndex] = lpAlphabet[iIndex - ('a' - 'A')];
					}
				}
			}
			else if(_stricmp(pCommand, "Texture") == 0)
			{
				pTexture = this->LoadTexture(pValue);
			}
			else
			{
				LogMessage("Unknown property %s on line %u.", pCommand, uiLineNumber);
			}
		}
	}

	fclose(pFile);

	if(pTexture == 0)
	{
		LogError("No Texture specified.");
		return 0;
	}

	if(Size.X == 0)
	{
		int iLetters = 0;
		for(int iIndex = 0; iIndex < FONT_CHAR_COUNT; iIndex++)
		{
			if(lpAlphabet[iIndex] != 0xff)
			{
				iLetters++;
			}
		}
		if(iLetters > 0)
		{
			Size.X = pTexture->GetWidth() / iLetters;
		}
	}

	if(Size.Y == 0)
	{
		Size.Y = pTexture->GetHeight();
	}

	LogMessage("%s loaded.", lpFileName);

	return new CFont(lpFileName, Size, Spacing, lpAlphabet, *pTexture);
}

void CEngine::UnloadFont(CFont *pFont)
{
	if(!this->bInitialized || pFont == 0 || pFont->uiReferences == 0)
	{
		return;
	}

	pFont->uiReferences--;

	if(pFont->uiReferences == 0)
	{
		this->UnloadTexture(&pFont->Texture);

		this->Fonts.remove(pFont);

		delete pFont;
	}
}

Units::CCable *CEngine::LoadCable()
{
	if(!this->bInitialized)
	{
		return 0;
	}

	Units::CCable *pCable = new Units::CCable(*this);

	if(!pCable->Load())
	{
		delete pCable;
		return 0;
	}

	this->Cables.push_back(pCable);
	return pCable;
}

Units::CCable *CEngine::LoadCable(Units::CUnit *pInput, Units::CUnit *pOutput)
{
	Units::CCable *pCable = this->LoadCable();

	if(pCable != 0)
	{
		pCable->SetInput(pInput);
		pCable->SetOutput(pOutput);
	}

	return pCable;
}

void CEngine::UnloadCable(Units::CCable *pCable)
{
	if(!this->bInitialized || pCable == 0)
	{
		return;
	}

	if(pCable->GetInput() != 0)
	{
		pCable->SetInput(0);
	}
	if(pCable->GetOutput() != 0)
	{
		pCable->SetOutput(0);
	}

	if(pCable == this->pLeftMouseDownCable)
	{
		this->pLeftMouseDownCable = 0;
	}

	this->Cables.remove(pCable);

	delete pCable;
}

bool CEngine::GetUnitRequiresRender() const
{
	for(CUnitList::const_iterator i = this->Units.begin(); i != this->Units.end(); ++i)
	{
		if((*i)->GetRequiresRender())
		{
			return true;
		}
	}
	return false;
}

Units::CUnit *CEngine::LoadUnit(Units::EUnitType eUnitType)
{
	if(!this->bInitialized)
	{
		return 0;
	}

	const Units::CUnit::CUnitInfo *pTemplate = Units::CUnit::GetUnitInfo(eUnitType);

	if(pTemplate == 0 || (this->pPreamp != 0 && pTemplate->IsPreamp()) || (this->pSpeakerCabinet != 0 && pTemplate->IsSpeakerCabinet()))
	{
		return 0;
	}

	Units::CUnit *pUnit = pTemplate->Create(*this);

	if(pUnit->Info.IsPreamp())
	{
		this->pPreamp = pUnit;
	}

	if(pUnit->Info.IsSpeakerCabinet())
	{
		this->pSpeakerCabinet = pUnit;
	}

	if(!pUnit->Load())
	{
		delete pUnit;
		return 0;
	}

	this->AutoPositionUnit(*pUnit);

	this->Units.push_back(pUnit);
	return pUnit;
}

void CEngine::AutoPositionUnit(Units::CUnit &Unit)
{
	bool bFits = false;
	for(int y = 8; y < (int)this->uiHeight - Unit.GetSize().Y / 2 && !bFits; y += 64)
	{
		for(int x = 8; x < (int)this->uiWidth - Unit.GetSize().X * 4 / 5 && !bFits; x += 192)
		{
			bool bIntersects = false;
			CVector Vector = CVector(x, y + (((x - 8) / 192) % 2 == 1 ? 32 : 0));

			for(CUnitList::const_iterator i = this->Units.begin(); i != this->Units.end(); ++i)
			{
				if(&Unit != *i && CVector::Intersects(Vector, Vector + Unit.GetSize(), (*i)->GetPosition(), (*i)->GetPosition() + (*i)->GetSize()))
				{
					bIntersects = true;
					break;
				}
			}

			if(!bIntersects)
			{
				bFits = true;
				Unit.SetPosition(Vector);
			}
		}
	}
}

void CEngine::UnloadUnit(Units::CUnit *pUnit)
{
	if(!this->bInitialized || pUnit == 0)
	{
		return;
	}

	Units::CCable *pUnloadInput = 0, *pUnloadOutput = 0;
	if(pUnit->GetInput())
	{
		if(pUnit->GetInput()->GetInput() == 0)
		{
			pUnloadInput = pUnit->GetInput();
		}
		pUnit->GetInput()->SetOutput(0);
	}
	if(pUnit->GetOutput())
	{
		if(pUnit->GetOutput()->GetOutput() == 0)
		{
			pUnloadOutput = pUnit->GetOutput();
		}
		pUnit->GetOutput()->SetInput(0);
	}
	this->UnloadCable(pUnloadInput);
	this->UnloadCable(pUnloadOutput);

	if(pUnit == this->pLeftMouseDownUnit)
	{
		this->pLeftMouseDownUnit = 0;
		this->pLeftMouseDownControl = 0;
	}
	if(pUnit == this->pSelectedUnit)
	{
		this->SetSelectedUnit(0);
	}

	if(pUnit == this->pPreamp)
	{
		this->pPreamp = 0;
	}
	if(pUnit == this->pSpeakerCabinet)
	{
		this->pSpeakerCabinet = 0;
	}

	this->Units.remove(pUnit);

	delete pUnit;
}

void CEngine::New(ENewTemplate eNewTemplate)
{
	LogMessage("Creating new pedalboard...");

	this->SetCacheTextureMode(true);
	this->Clear();
	this->SetCacheTextureMode(false);

	Units::CUnit **pUnit = 0;

	switch(eNewTemplate)
	{
#ifdef _DEBUG
		case NEW_TEMPLATE_TESTING:
		{
			Units::CUnit *lpUnits[] =
			{
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PREAMP),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PLAYER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_NOISE_GATE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_BOOST),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_METRONOME),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_OCTAVE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_EQUALIZER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_CHAOS),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FUZZ),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_AUTOMATIC_WAH),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_ENVELOPE_FILTER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_RING_MODULATOR),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_CHORUS),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FLANGER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_VIBRATO),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FEEDBACK_LOOP),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PARALLEL_FEEDBACK_LOOP),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_DELAY),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_EQUALIZER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_REVERB),
				//this->LoadUnit(VAmp::Units::UNIT_TYPE_LOOP_STATION),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_OSCILLOSCOPE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FFT_SPECTRUM),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_RECORDER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FADER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_SPEAKER_CABINET),
				0
			};
			pUnit = lpUnits;
			break;
		}
#endif
		case NEW_TEMPLATE_ESSENTIAL:
		{
			Units::CUnit *lpUnits[] =
			{
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PREAMP),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_SPEAKER_CABINET),
				0
			};
			pUnit = lpUnits;
			break;
		}
		case NEW_TEMPLATE_RECOMMENDED:
		{
			Units::CUnit *lpUnits[] =
			{
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PREAMP),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_NOISE_GATE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_EQUALIZER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_REVERB),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_OSCILLOSCOPE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FFT_SPECTRUM),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_SPEAKER_CABINET),
				0
			};
			pUnit = lpUnits;
			break;
		}
		case NEW_TEMPLATE_PLAYBACK:
		{
			Units::CUnit *lpUnits[] =
			{
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PREAMP),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_NOISE_GATE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_EQUALIZER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_REVERB),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PLAYER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_OSCILLOSCOPE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FFT_SPECTRUM),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_RECORDER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_SPEAKER_CABINET),
				0
			};
			pUnit = lpUnits;
			break;
		}
		case NEW_TEMPLATE_EVERYTHING:
		{
			Units::CUnit *lpUnits[] =
			{
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PREAMP),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_NOISE_GATE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_COMPRESSOR),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_BOOST),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_OCTAVE),
#ifdef _DEBUG
				this->LoadUnit(VAmp::Units::UNIT_TYPE_CHAOS),
#endif
				this->LoadUnit(VAmp::Units::UNIT_TYPE_DISTORTION),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_OVERDRIVE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FUZZ),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_AUTOMATIC_WAH),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_ENVELOPE_FILTER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_RING_MODULATOR),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_CHORUS),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FLANGER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PHASE_SHIFTER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_TREMOLO),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_VIBRATO),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_EQUALIZER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_DELAY),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FEEDBACK_LOOP),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PARALLEL_FEEDBACK_LOOP),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_REVERB),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_LOOP_STATION),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_PLAYER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FADER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_OSCILLOSCOPE),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_FFT_SPECTRUM),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_RECORDER),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_METRONOME),
				this->LoadUnit(VAmp::Units::UNIT_TYPE_SPEAKER_CABINET),
				0
			};
			pUnit = lpUnits;
			break;
		}
	}

	while(pUnit != 0 && pUnit[0] != 0 && pUnit[1] != 0)
	{
		this->LoadCable(pUnit[0], pUnit[1]);
		pUnit++;
	}

	this->UnloadTextureCache();

	LogMessage("New pedalboard created.");

	this->Render();
}

bool CEngine::Save(const char *lpFileName)
{
	LogMessage("Saving %s...", lpFileName);

	FILE *pFile = fopen(lpFileName, "wt");

	if(pFile == 0)
	{
		LogSystemError("Error opening %s for writing.", lpFileName);
		return false;
	}

	bool bFirst = true;
	for(CUnitList::iterator Unit = this->Units.begin(); Unit != this->Units.end(); ++Unit)
	{
		Units::CUnit *pUnit = *Unit;

		fprintf(pFile, "%s[%s]\n", bFirst ? "" : "\n", pUnit->Info.GetName());

		fprintf(pFile, "Position = [%d, %d]\n", pUnit->GetPosition().X, pUnit->GetPosition().Y);
		if(pUnit->GetShortcut())
		{
			fprintf(pFile, "Shortcut = %d\n", pUnit->GetShortcut());
		}

		unsigned int i;

		for(i = 0; i < pUnit->GetControlCount(); i++)
		{
			Units::CControl *pControl = pUnit->GetControl(i);
			if(pControl->GetName() != 0 && pControl->GetPersistent())
			{
				switch(pControl->GetType())
				{
				case Units::CONTROL_TYPE_BUTTON:
					if(static_cast<Units::CButton *>(pControl)->GetValue() != 0)
					{
						fprintf(pFile, "%s = %s\n", pControl->GetName(), static_cast<Units::CButton *>(pControl)->GetValue());
					}
					break;
				case Units::CONTROL_TYPE_KNOB:
					fprintf(pFile, "%s = %f\n", pControl->GetName(), static_cast<Units::CKnob *>(pControl)->GetValue());
					break;
				case Units::CONTROL_TYPE_STOMP:
					fprintf(pFile, "%s = %s\n", pControl->GetName(), static_cast<Units::CStomp *>(pControl)->GetPressed() ? "True" : "False");
					break;
				case Units::CONTROL_TYPE_TOGGLE:
					fprintf(pFile, "%s = %s\n", pControl->GetName(), static_cast<Units::CToggle *>(pControl)->GetOn() ? "True" : "False");
					break;
				case Units::CONTROL_TYPE_VERTICAL_SLIDER:
					fprintf(pFile, "%s = %f\n", pControl->GetName(), static_cast<Units::CVerticalSlider *>(pControl)->GetValue());
					break;
				}
			}
		}

		for(i = 0; i < pUnit->GetVariableCount(); i++)
		{
			Units::CVariable *pVariable = pUnit->GetVariable(i);

			char lpValue[256];
			pVariable->Print(lpValue);
			fprintf(pFile, "%s = %s\n", pVariable->GetName(), lpValue);
		}

		bFirst = false;
	}

	for(CCableList::iterator Cable = this->Cables.begin(); Cable != this->Cables.end(); ++Cable)
	{
		Units::CCable *pCable = *Cable;

		fprintf(pFile, "%s[Cable]\n", bFirst ? "" : "\n");

		if(pCable->GetInput() == 0)
		{
			fprintf(pFile, "Head = [%d, %d]\n", pCable->GetHead().X, pCable->GetHead().Y);
		}
		else
		{
			fprintf(pFile, "Input = %d\n", this->GetUnitIndex(pCable->GetInput()));
		}
		if(pCable->GetOutput() == 0)
		{
			fprintf(pFile, "Tail = [%d, %d]\n", pCable->GetTail().X, pCable->GetTail().Y);
		}
		else
		{
			fprintf(pFile, "Output = %d\n", this->GetUnitIndex(pCable->GetOutput()));
		}

		bFirst = false;
	}

	fclose(pFile);

	LogMessage("%s saved.", lpFileName);

	return true;
}

bool CEngine::Open(const char *lpFileName)
{
	LogMessage("Opening %s...", lpFileName);

	this->SetCacheTextureMode(true);
	this->Clear();
	this->SetCacheTextureMode(false);

	FILE *pFile = fopen(lpFileName, "rt");

	if(pFile == 0)
	{
		LogSystemError("Error opening %s for reading.", lpFileName);

		this->UnloadTextureCache();
		this->Render();
		return false;
	}

	bool bEOF = false;
	unsigned int uiBufferIndex = 0;
	unsigned int uiBufferCount = 0;
	char lpBuffer[8192];

	unsigned int uiLineNumber = 1;
	unsigned int uiLineIndex;
	char lpLine[8192];

	Units::CCable *pCable = 0;
	Units::CUnit *pUnit = 0;

	while(!bEOF)
	{
		uiLineIndex = 0;
		while(uiLineIndex < sizeof(lpLine) - 1)
		{
			if(uiBufferIndex == uiBufferCount)
			{
				uiBufferIndex = 0;
				uiBufferCount = (unsigned int)fread(lpBuffer, sizeof(char), sizeof(lpBuffer), pFile);
				if(uiBufferCount == 0)
				{
					bEOF = true;
					break;
				}
			}

			if(lpBuffer[uiBufferIndex] == '\r')
			{
				uiBufferIndex++;
				break;
			}
			if(lpBuffer[uiBufferIndex] == '\n')
			{
				uiBufferIndex++;
				uiLineNumber++;
				break;
			}
			lpLine[uiLineIndex++] = lpBuffer[uiBufferIndex++];
		}

		lpLine[uiLineIndex] = '\0';

		char *pComment = strchr(lpLine, '#');
		if(pComment != 0)
		{
			*pComment = '\0';
		}

		char *pLine = lpLine;

		while(*pLine && isspace(*pLine))
		{
			pLine++;
		}

		if(*pLine == '\0')
		{
			continue;
		}

		if(*pLine == '[')
		{
			char *pUnitName = pLine + 1;
			while(*pUnitName && *pUnitName != ']')
			{
				pUnitName++;
			}

			if(*pUnitName == ']')
			{
				*pUnitName = '\0';
				if(_stricmp(pLine + 1, "Cable") == 0)
				{
					pCable = this->LoadCable();
					pUnit = 0;
				}
				else
				{
					pCable = 0;
					pUnit = 0;

					const Units::CUnit::CUnitInfo *pUnitInfo = Units::CUnit::GetUnitInfo(pLine + 1);
					if(pUnitInfo == 0)
					{
						LogMessage("Unknown object type %s on line %u.", pLine + 1, uiLineNumber);
					}
					else
					{
						pUnit = this->LoadUnit(pUnitInfo->GetType());

						if(pUnit == 0)
						{
							LogMessage("Error creating unit type %s on line %u.", pLine + 1, uiLineNumber);
						}
					}
				}
			}
			else
			{
				LogMessage("Malformed object type on line %u.", uiLineNumber);
				pCable = 0;
				pUnit = 0;
			}
		}
		else if(pCable != 0 || pUnit != 0)
		{
			char *pCommand = pLine, *pValue = pLine;

			while(*pValue && *pValue != '=')
			{
				pValue++;
			}

			if(*pValue == '=')
			{
				*pValue = '\0';

				char *pTemp = pValue - 1;
				while(pTemp > pCommand && isspace(*pTemp))
				{
					*pTemp = '\0';
					pTemp--;
				}

				pValue++;

				while(*pValue && isspace(*pValue))
				{
					pValue++;
				}

				if(pCable != 0)
				{
					if(_stricmp(pCommand, "Head") == 0)
					{
						CVector Head;
						if(sscanf(pValue, "[%d, %d]", &Head.X, &Head.Y) == 2)
						{
							pCable->SetHead(Head);
						}
					}
					else if(_stricmp(pCommand, "Tail") == 0)
					{
						CVector Tail;
						if(sscanf(pValue, "[%d, %d]", &Tail.X, &Tail.Y) == 2)
						{
							pCable->SetTail(Tail);
						}
					}
					else if(_stricmp(pCommand, "Input") == 0)
					{
						int iIndex;
						if(sscanf(pValue, "%d", &iIndex) == 1)
						{
							pCable->SetInput(this->GetUnit(iIndex));
						}
					}
					else if(_stricmp(pCommand, "Output") == 0)
					{
						int iIndex;
						if(sscanf(pValue, "%d", &iIndex) == 1)
						{
							pCable->SetOutput(this->GetUnit(iIndex));
						}
					}
					else
					{
						LogMessage("Unknown Cable property %s on line %u.", pCommand, uiLineNumber);
					}
				}
				else if(pUnit != 0)
				{
					if(_stricmp(pCommand, "Position") == 0)
					{
						CVector Position;
						if(sscanf(pValue, "[%d, %d]", &Position.X, &Position.Y) == 2)
						{
							pUnit->SetPosition(Position);
						}
					}
					else if(_stricmp(pCommand, "Shortcut") == 0)
					{
						int iShortcut = 0;
						if(sscanf(pValue, "%d", &iShortcut) == 1)
						{
							pUnit->SetShortcut(iShortcut);
						}
					}
					else
					{
						bool bFound = false;
						for(unsigned int j = 0; j < pUnit->GetControlCount(); j++)
						{
							Units::CControl *pControl = pUnit->GetControl(j);
							if(pControl->GetName() != 0 && pControl->GetPersistent() && _stricmp(pCommand, pControl->GetName()) == 0)
							{
								switch(pControl->GetType())
								{
									case Units::CONTROL_TYPE_BUTTON:
									{
										static_cast<Units::CButton *>(pControl)->SetValue(pValue);
										bFound = true;
										break;
									}
									case Units::CONTROL_TYPE_KNOB:
									{
										float fValue;
										if(sscanf(pValue, "%f", &fValue) == 1)
										{
											static_cast<Units::CKnob *>(pControl)->SetValue(fValue);
										}
										bFound = true;
										break;
									}
									case Units::CONTROL_TYPE_STOMP:
									{
										if(_stricmp(pValue, "True") == 0)
										{
											static_cast<Units::CStomp *>(pControl)->SetPressed(true);
										}
										else if(_stricmp(pValue, "False") == 0)
										{
											static_cast<Units::CStomp *>(pControl)->SetPressed(false);
										}
										bFound = true;
										break;
									}
									case Units::CONTROL_TYPE_TOGGLE:
									{
										if(_stricmp(pValue, "True") == 0)
										{
											static_cast<Units::CToggle *>(pControl)->SetOn(true);
										}
										else if(_stricmp(pValue, "False") == 0)
										{
											static_cast<Units::CToggle *>(pControl)->SetOn(false);
										}
										bFound = true;
										break;
									}
									case Units::CONTROL_TYPE_VERTICAL_SLIDER:
									{
										float fValue;
										if(sscanf(pValue, "%f", &fValue) == 1)
										{
											static_cast<Units::CVerticalSlider *>(pControl)->SetValue(fValue);
										}
										bFound = true;
										break;
									}
								}
								break;
							}
						}

						Units::CVariable *pVariable = pUnit->GetVariable(pCommand);
						if(pVariable != 0)
						{
							pVariable->Parse(pValue);
							bFound = true;
						}

						if(!bFound)
						{
							LogMessage("Unknown %s property %s on line %u.", pUnit->Info.GetName(), pCommand, uiLineNumber);
						}
					}
				}
				else
				{
					LogMessage("Unknown property %s on line %u.", pCommand, uiLineNumber);
				}
			}
		}
	}

	fclose(pFile);

	this->UnloadTextureCache();

	LogMessage("%s opened.", lpFileName);

	this->Render();
	return true;
}

void CEngine::Clear()
{
	this->pLeftMouseDownCable = 0;
	this->pLeftMouseDownUnit = 0;
	this->pLeftMouseDownControl = 0;
	this->SetSelectedUnit(0);

	this->pPreamp = 0;
	this->pSpeakerCabinet = 0;

	for(CCableList::iterator Cable = this->Cables.begin(); Cable != this->Cables.end(); ++Cable)
	{
		delete *Cable;
	}
	this->Cables.clear();

	for(CUnitList::iterator Unit = this->Units.begin(); Unit != this->Units.end(); ++Unit)
	{
		delete *Unit;
	}
	this->Units.clear();

	LogMessage("Pedalboard cleared.");
}

void CEngine::Process(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples)
{
	bool bConnected = false;
	if(this->pPreamp != 0)
	{
		float fNormalizer = 1.0f;
		this->pPreamp->Process(lpData, uiSamplesPerSecond, uiSamples, fNormalizer);

		if(this->pSpeakerCabinet != 0)
		{
			Units::CCable *pCable = this->pPreamp->GetOutput();
			while(pCable != 0 && pCable->GetOutput() != 0)
			{
				if(pCable->GetOutput() == this->pSpeakerCabinet)
				{
					bConnected = true;
				}
				pCable = pCable->GetOutput()->GetOutput();
			}
		}
	}

	if(!bConnected)
	{
		memset(lpData, 0, sizeof(float) * uiSamples);
	}
}

Units::CCable *CEngine::GetCable(CVector MousePosition, bool &bHead) const
{
	for(CCableList::const_iterator i = this->Cables.begin(); i != this->Cables.end(); ++i)
	{
		if((*i)->IntersectsMouse(MousePosition, bHead))
		{
			return *i;
		}
	}
	return 0;
}

int CEngine::GetUnitIndex(Units::CUnit *pUnit)
{
	int iIndex = 0;
	for(CUnitList::const_iterator i = this->Units.begin(); i != this->Units.end(); ++i)
	{
		if(*i == pUnit)
		{
			return iIndex;
		}
		iIndex++;
	}
	return -1;
}

Units::CUnit *CEngine::GetUnit(int iIndex) const
{
	int iCurrentIndex = 0;
	for(CUnitList::const_iterator i = this->Units.begin(); i != this->Units.end(); ++i)
	{
		if(iCurrentIndex == iIndex)
		{
			return *i;
		}
		iCurrentIndex++;
	}
	return 0;
}

Units::CUnit *CEngine::GetUnit(CVector MousePosition) const
{
	Units::CUnit *pUnit = 0;
	for(CUnitList::const_iterator i = this->Units.begin(); i != this->Units.end(); ++i)
	{
		CVector Position = (*i)->GetPosition();
		CVector Size = (*i)->GetSize();

		if((this->LastMousePosition.X >= Position.X && this->LastMousePosition.X <= Position.X + Size.X) && (this->LastMousePosition.Y >= Position.Y && this->LastMousePosition.Y <= Position.Y + Size.Y))
		{
			pUnit = *i;
		}
	}
	return pUnit;
}

void CEngine::SetSelectedUnit(Units::CUnit *pSelectedUnit)
{
	this->pSelectedUnit = pSelectedUnit;

	SetStatusBarText(STATUSBAR_PANEL_SELECTION, this->pSelectedUnit == 0 ? "None" : pSelectedUnit->Info.GetName());

	TCHAR lpName[64] = "None";
	if(this->pSelectedUnit != 0 && this->pSelectedUnit->GetShortcut() != 0)
	{
		GetKeyNameText(MapVirtualKey(this->pSelectedUnit->GetShortcut(), 0) << 16, lpName, sizeof(lpName));
		lpName[sizeof(lpName) - 1] = '\0';
		if(*lpName == '\0')
		{
			strcpy(lpName, "Unknown");
		}
	}
	SetStatusBarText(STATUSBAR_PANEL_SHORTCUT, lpName);
}
