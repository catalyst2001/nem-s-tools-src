/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Metronome.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CMetronomeInfo, CMetronome, MetronomeInfo);

#define METRONOME_TEMPO_MIN 20
#define METRONOME_TEMPO_MAX 220

CMetronome::CMetronome(CEngine &Engine) : CUnit(CMetronome::MetronomeInfo, Engine), pPower(0), pDepth(0), pTempo(0), pTempoUp(0), pTempoDown(0), pFont(0), pBeats(0), pStomp(0)
{

}

CMetronome::~CMetronome()
{
	this->Unload();
}

bool CMetronome::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/metronome.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CKnob(*this, "Depth", 0.0f, 1.0f, 0.25f);
	this->pDepth->SetPosition(CVector(20, 28));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDepth);

	this->pTempo = new CIntVariable("Tempo", 120, METRONOME_TEMPO_MIN, METRONOME_TEMPO_MAX);
	this->Variables.push_back(this->pTempo);

	this->pTempoUp = new CButton(*this, "TempoUp", new CButton::CEventClass<CMetronome>(this, &CMetronome::OnTempoUp));
	this->pTempoUp->SetPersistent(false);
	this->pTempoUp->SetPosition(CVector(60, 50));
	this->pTempoUp->SetSize(CVector(16, 16));
	this->pTempoUp->SetTexture(this->Engine.LoadTexture("units/up.png"));
	this->pTempoUp->SetUpTexture(this->Engine.LoadTexture("units/button_text_u.png"));
	this->pTempoUp->SetDownTexture(this->Engine.LoadTexture("units/button_text_d.png"));
	this->Controls.push_back(this->pTempoUp);

	this->pTempoDown = new CButton(*this, "TempoDown", new CButton::CEventClass<CMetronome>(this, &CMetronome::OnTempoDown));
	this->pTempoDown->SetPersistent(false);
	this->pTempoDown->SetPosition(CVector(76, 50));
	this->pTempoDown->SetSize(CVector(16, 16));
	this->pTempoDown->SetTexture(this->Engine.LoadTexture("units/down.png"));
	this->pTempoDown->SetUpTexture(this->Engine.LoadTexture("units/button_text_u.png"));
	this->pTempoDown->SetDownTexture(this->Engine.LoadTexture("units/button_text_d.png"));
	this->Controls.push_back(this->pTempoDown);

	this->pFont = this->Engine.LoadFont("fonts/lcd.fnt");

	this->pBeats = new CKnob(*this, "Beats", 1.0f, 8.0f, 4.0f, true);
	this->pBeats->SetPosition(CVector(100, 28));
	this->pBeats->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pBeats);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->uiSample = 0;
	this->uiTickSample = 0xffffffff;
	this->uiBeat = 0xffffffff;

	return true;
}

void CMetronome::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	this->pTempo = 0;
	this->pTempoUp = 0;
	this->pTempoDown = 0;
	this->Engine.UnloadFont(this->pFont);
	this->pFont = 0;
	this->pBeats = 0;
	this->pStomp = 0;
}

void CMetronome::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();

	if(this->pFont != 0)
	{
		char lpTempo[4];
		sprintf(lpTempo, "%d", this->pTempo->iValue);
		this->pFont->Render(FONT_ALIGN_RIGHT | FONT_ALIGN_MIDDLE, CRectangle(28, 90, 48, 62), CColor(255, 64, 64, 255), lpTempo);
	}
}

#define METRONOME_PRIMARY_TICK_FREQUENCY 1640.0f
#define METRONOME_SECONDARY_TICK_FREQUENCY 784.0f
#define METRONOME_TICK_TIME 0.01f

void CMetronome::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		this->uiSample = 0;
		this->uiTickSample = 0xffffffff;
		this->uiBeat = 0xffffffff;
		return;
	}

	float fDepth = this->pDepth->GetValue();
	float fOneMinusDepth = 1.0f - fDepth;
	unsigned int uiTempo = 60 * uiSamplesPerSecond / this->pTempo->iValue;
	unsigned int uiBeats = (unsigned int)this->pBeats->GetValue();
	float fTickFrequency = VA_2PI / ((float)uiSamplesPerSecond / (this->uiBeat == 0 ? METRONOME_PRIMARY_TICK_FREQUENCY : METRONOME_SECONDARY_TICK_FREQUENCY));
	float fTickVolume = this->uiBeat == 0 ? 1.0f : 0.66f;
	unsigned int uiTickSamples = (unsigned int)ceilf((float)uiSamplesPerSecond * METRONOME_TICK_TIME);

	for(unsigned int i = 0; i < uiSamples; i++)
	{
		if(this->uiSample == 0)
		{
			if(this->uiBeat == 0xffffffff)
			{
				this->uiBeat = 0;
			}
			else
			{
				this->uiBeat++;
				this->uiBeat %= uiBeats;
			}

			this->uiTickSample = 0;
			fTickFrequency = VA_2PI / ((float)uiSamplesPerSecond / (this->uiBeat == 0 ? METRONOME_PRIMARY_TICK_FREQUENCY : METRONOME_SECONDARY_TICK_FREQUENCY));
			fTickVolume = this->uiBeat == 0 ? 1.0f : 0.66f;
		}

		if(this->uiTickSample == uiTickSamples)
		{
			this->uiTickSample = 0xffffffff;
		}

		if(this->uiTickSample == 0xffffffff)
		{
			lpData[i] *= fOneMinusDepth;
		}
		else
		{
			lpData[i] = lpData[i] * fOneMinusDepth + fTickVolume * sinf((float)this->uiTickSample++ * fTickFrequency) * fDepth;
		}

		this->uiSample++;
		this->uiSample %= uiTempo;
	}
}

void CMetronome::OnTempoUp(CButton &Button)
{
	if(this->pTempo->iValue < METRONOME_TEMPO_MAX)
	{
		if(GetKeyState(VK_MENU) & 0x80)
		{
			this->pTempo->iValue += 10;
			if(this->pTempo->iValue > METRONOME_TEMPO_MAX)
			{
				this->pTempo->iValue = METRONOME_TEMPO_MAX;
			}
		}
		else
		{
			this->pTempo->iValue++;
		}
	}
}

void CMetronome::OnTempoDown(CButton &Button)
{
	if(this->pTempo->iValue > METRONOME_TEMPO_MIN)
	{
		if(GetKeyState(VK_MENU) & 0x80)
		{
			this->pTempo->iValue -= 10;
			if(this->pTempo->iValue < METRONOME_TEMPO_MIN)
			{
				this->pTempo->iValue = METRONOME_TEMPO_MIN;
			}
		}
		else
		{
			this->pTempo->iValue--;
		}
	}
}
