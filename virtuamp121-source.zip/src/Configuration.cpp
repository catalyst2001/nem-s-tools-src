/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "virtuAMP.h"
#include "Configuration.h"
#include "Log.h"

using namespace VAmp;

CConfiguration::CConfiguration() : WindowPosition(CW_USEDEFAULT, 0), WindowSize(CW_USEDEFAULT, 0), bWindowMaximized(false), eAudioDriver(Audio::AUDIO_DRIVER_WINDOWS_MULTIMEDIA), uiAudioBuffers(4), uiBufferDenominator(21), uiBufferFPS(24), eCableInterp(CABLE_INTERP_BEZIER)
{
#ifdef USE_DIRECTSOUND
	OSVERSIONINFO OSVersionInfo;
	memset(&OSVersionInfo, 0, sizeof(OSVERSIONINFO));
	OSVersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	// Default to DirectSound in Windows XP and up.
    if(GetVersionEx(&OSVersionInfo) && (OSVersionInfo.dwMajorVersion > 5 || (OSVersionInfo.dwMajorVersion == 5 && OSVersionInfo.dwMinorVersion >= 1)))
	{
		this->eAudioDriver = Audio::AUDIO_DRIVER_DIRECTSOUND;
	}
#endif
}

bool CConfiguration::Save(const char *lpFileName)
{
	LogMessage("Saving %s...", lpFileName);

	FILE *pFile = fopen(lpFileName, "wt");

	if(pFile == 0)
	{
		LogSystemError("Error opening %s for writing.", lpFileName);
		return false;
	}

	fprintf(pFile, "# virtuAMP Configuration\n\n");
	fprintf(pFile, "Window.Position = [%d, %d]\n", this->WindowPosition.X, this->WindowPosition.Y);
	fprintf(pFile, "Window.Size = [%d, %d]\n", this->WindowSize.X, this->WindowSize.Y);
	fprintf(pFile, "Window.State = %s\n", this->bWindowMaximized ? "Maximized" : "Normal");
	fprintf(pFile, "Audio.Driver = %s\n", Audio::CAudioDriver::GetName(this->eAudioDriver));
	fprintf(pFile, "Audio.Buffers = %u\n", this->uiAudioBuffers);
	fprintf(pFile, "Audio.BufferDenominator = %u\n", this->uiBufferDenominator);
	fprintf(pFile, "Audio.BufferFPS = %u\n", this->uiBufferFPS);
	fprintf(pFile, "Video.CableInterpolationMode = %u\n", (unsigned int)this->eCableInterp);

	fclose(pFile);

	return true;
}

bool CConfiguration::Open(const char *lpFileName)
{
	LogMessage("Opening %s...", lpFileName);

	FILE *pFile = fopen(lpFileName, "rt");

	if(pFile == 0)
	{
		LogSystemError("Error opening %s for reading.", lpFileName);
		return false;
	}

	bool bEOF = false;
	unsigned int uiBufferIndex = 0;
	unsigned int uiBufferCount = 0;
	char lpBuffer[8192];

	unsigned int uiLineNumber = 1;
	unsigned int uiLineIndex;
	char lpLine[8192];

	while(!bEOF)
	{
		uiLineIndex = 0;
		while(uiLineIndex < sizeof(lpLine) - 1)
		{
			if(uiBufferIndex == uiBufferCount)
			{
				uiBufferIndex = 0;
				uiBufferCount = (unsigned int)fread(lpBuffer, sizeof(char), sizeof(lpBuffer), pFile);
				if(uiBufferCount == 0)
				{
					bEOF = true;
					break;
				}
			}

			if(lpBuffer[uiBufferIndex] == '\r')
			{
				uiBufferIndex++;
				break;
			}
			if(lpBuffer[uiBufferIndex] == '\n')
			{
				uiBufferIndex++;
				uiLineNumber++;
				break;
			}
			lpLine[uiLineIndex++] = lpBuffer[uiBufferIndex++];
		}

		lpLine[uiLineIndex] = '\0';

		char *pComment = strchr(lpLine, '#');
		if(pComment != 0)
		{
			*pComment = '\0';
		}

		char *pLine = lpLine;

		while(*pLine && isspace(*pLine))
		{
			pLine++;
		}

		if(*pLine == '\0')
		{
			continue;
		}

		char *pCommand = pLine, *pValue = pLine;

		while(*pValue && *pValue != '=')
		{
			pValue++;
		}

		if(*pValue == '=')
		{
			*pValue = '\0';

			char *pTemp = pValue - 1;
			while(pTemp > pCommand && isspace(*pTemp))
			{
				*pTemp = '\0';
				pTemp--;
			}

			pValue++;

			while(*pValue && isspace(*pValue))
			{
				pValue++;
			}

			if(_stricmp(pCommand, "Window.Position") == 0)
			{
				CVector WindowPosition;
				if(sscanf(pValue, "[%d, %d]", &WindowPosition.X, &WindowPosition.Y) == 2)
				{
					this->WindowPosition = WindowPosition;
				}
			}
			else if(_stricmp(pCommand, "Window.Size") == 0)
			{
				CVector WindowSize;
				if(sscanf(pValue, "[%d, %d]", &WindowSize.X, &WindowSize.Y) == 2)
				{
					this->WindowSize = WindowSize;
				}
			}
			else if(_stricmp(pCommand, "Window.State") == 0)
			{
				this->bWindowMaximized = _stricmp(pValue, "Maximized") == 0;
			}
			else if(_stricmp(pCommand, "Audio.Driver") == 0)
			{
				this->eAudioDriver = Audio::CAudioDriver::GetType(pValue);
			}
			else if(_stricmp(pCommand, "Audio.Buffers") == 0)
			{
				unsigned int uiAudioBuffers;
				if(sscanf(pValue, "%u", &uiAudioBuffers) == 1)
				{
					if(uiAudioBuffers < AUDIO_BUFFERS_MIN)
						uiAudioBuffers = AUDIO_BUFFERS_MIN;
					else if(uiAudioBuffers > AUDIO_BUFFERS_MAX)
						uiAudioBuffers = AUDIO_BUFFERS_MAX;

					this->uiAudioBuffers = uiAudioBuffers;
				}
			}
			else if(_stricmp(pCommand, "Audio.BufferDenominator") == 0)
			{
				unsigned int uiBufferDenominator;
				if(sscanf(pValue, "%u", &uiBufferDenominator) == 1)
				{
					if(uiBufferDenominator < BUFFER_DENOMINATOR_MIN)
						uiBufferDenominator = BUFFER_DENOMINATOR_MIN;
					else if(uiBufferDenominator > BUFFER_DENOMINATOR_MAX)
						uiBufferDenominator = BUFFER_DENOMINATOR_MAX;

					this->uiBufferDenominator = uiBufferDenominator;
				}
			}
			else if(_stricmp(pCommand, "Audio.BufferFPS") == 0)
			{
				unsigned int uiBufferFPS;
				if(sscanf(pValue, "%u", &uiBufferFPS) == 1)
				{
					if(uiBufferFPS < BUFFER_DENOMINATOR_MIN)
						uiBufferFPS = BUFFER_DENOMINATOR_MIN;
					else if(uiBufferFPS > BUFFER_DENOMINATOR_MAX)
						uiBufferFPS = BUFFER_DENOMINATOR_MAX;

					this->uiBufferFPS = uiBufferFPS;
				}
			}
			else if(_stricmp(pCommand, "Video.CableInterpolationMode") == 0)
			{
				unsigned int uiCableInterp;
				if(sscanf(pValue, "%u", &uiCableInterp) == 1)
				{
					if(uiCableInterp < 0)
						uiCableInterp = 0;
					else if(uiCableInterp > CABLE_INTERP_COUNT)
						uiCableInterp = CABLE_INTERP_COUNT;

					this->eCableInterp = (ECableInterp)uiCableInterp;
				}
			}
		}
	}

	fclose(pFile);

	return true;
}

namespace VAmp
{
	CConfiguration Configuration = CConfiguration();
}
