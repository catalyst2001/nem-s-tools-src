/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"

#define AUDIO_SAMPLES 44100

namespace VAmp
{
	class CEngine;

	namespace Audio
	{
		enum EAudioDriver
		{
			AUDIO_DRIVER_NULL = 0,
			AUDIO_DRIVER_WINDOWS_MULTIMEDIA,
#ifdef USE_DIRECTSOUND
			AUDIO_DRIVER_DIRECTSOUND,
#endif
			AUDIO_DRIVER_COUNT
		};

		class CAudioDriver
		{
		protected:
			HWND hWnd;
			CEngine *pEngine;

		public:
			CAudioDriver(HWND hWnd, CEngine *pEngine);
			virtual ~CAudioDriver();

			virtual EAudioDriver GetType() const = 0;

			virtual bool IsPlaying() = 0;
			virtual bool Play(unsigned int uiSamplesPerSecond) = 0;
			virtual void Stop() = 0;

			static EAudioDriver GetType(const char *lpName);
			static const char *GetName(EAudioDriver eAudioDriver);
			static CAudioDriver *Create(EAudioDriver eAudioDriver, HWND hWnd, CEngine *pEngine);
		};
	}
}
