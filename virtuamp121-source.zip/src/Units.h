/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "AutomaticWah.h"
#include "Boost.h"
#include "Chaos.h"
#include "Chorus.h"
#include "Compressor.h"
#include "Delay.h"
#include "Distortion.h"
#include "EnvelopeFilter.h"
#include "Equalizer.h"
#include "Fader.h"
#include "FeedbackLoop.h"
#include "FFTSpectrum.h"
#include "Flanger.h"
#include "Fuzz.h"
#include "LoopStation.h"
#include "Metronome.h"
#include "NoiseGate.h"
#include "Octave.h"
#include "Oscilloscope.h"
#include "Overdrive.h"
#include "ParallelFeedbackLoop.h"
#include "PhaseShifter.h"
#include "Player.h"
#include "Preamp.h"
#include "Recorder.h"
#include "Reverb.h"
#include "RingModulator.h"
#include "SpeakerCabinet.h"
#include "Tremolo.h"
#include "Vibrato.h"
