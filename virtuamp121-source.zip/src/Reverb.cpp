/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Reverb.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CReverbInfo, CReverb, ReverbInfo);

CReverb::CReverb(CEngine &Engine) : CUnit(CReverb::ReverbInfo, Engine), pPower(0), pDepth(0), pPredelay(0), pDecay(0), pDiffusion(0), pStomp(0)
{

}

CReverb::~CReverb()
{
	this->Unload();
}

bool CReverb::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/reverb.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CKnob(*this, "Depth", 0.0f, 1.0f, 0.165f);
	this->pDepth->SetPosition(CVector(9, 34));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDepth);

	this->pPredelay = new CKnob(*this, "Predelay", 0.005f, 0.205f, 0.105f);
	this->pPredelay->SetPosition(CVector(43, 34));
	this->pPredelay->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pPredelay);

	this->pDecay = new CKnob(*this, "Decay", 0.25f, 0.85f, 0.55f);
	this->pDecay->SetPosition(CVector(77, 34));
	this->pDecay->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDecay);

	this->pDiffusion = new CKnob(*this, "Diffusion", 0.0025f, 0.05f, 0.02625f);
	this->pDiffusion->SetPosition(CVector(111, 34));
	this->pDiffusion->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDiffusion);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	return true;
}

void CReverb::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	this->pPredelay = 0;
	this->pDecay = 0;
	this->pDiffusion = 0;
	this->pStomp = 0;

	unsigned int i;
	for(i = 0; i < REVERB_COMB_FILTERS; i++)
	{
		this->lpCombBuffers[i].Clear();
	}
	for(i = 0; i < REVERB_ALLPASS_FILTERS; i++)
	{
		this->lpAllPassBuffers[i].Clear();
	}
}

void CReverb::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

// http://www.harmony-central.com/Effects/Articles/Reverb/
// http://www.ramsete.com/aurora/SAW/RoomSim.html

void CReverb::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	unsigned int i, j;

	float fMaxCombSpread = this->pPredelay->GetMax() / float(REVERB_COMB_FILTERS);
	float fMaxAllpassSpread = this->pDiffusion->GetMax() / float(REVERB_ALLPASS_FILTERS);

	for(i = 0; i < REVERB_COMB_FILTERS; i++)
	{
		this->lpCombBuffers[i].SetSamples((unsigned int)ceilf((float)uiSamplesPerSecond * (this->pPredelay->GetMax() + (float)i * fMaxCombSpread)) + uiSamples);
	}
	for(i = 0; i < REVERB_ALLPASS_FILTERS; i++)
	{
		this->lpAllPassBuffers[i].SetSamples((unsigned int)ceilf((float)uiSamplesPerSecond * (this->pDiffusion->GetMax() - (float)i * fMaxAllpassSpread)) + uiSamples);
	}

	if(!this->pStomp->GetPressed() || this->pDepth->GetValue() == 0.0f)
	{
		for(i = 0; i < REVERB_COMB_FILTERS; i++)
		{
			this->lpCombBuffers[i].Advance(uiSamples, lpData);
		}
		for(i = 0; i < REVERB_ALLPASS_FILTERS; i++)
		{
			this->lpAllPassBuffers[i].Advance(uiSamples, lpData);
		}

		return;
	}

	float fDepth = this->pDepth->GetValue();
	float fOneMinusDepth = 1.0f - fDepth;
	float fPredelay = this->pPredelay->GetValue();
	float fDecay = this->pDecay->GetValueInverse();
	float fDiffusion = this->pDiffusion->GetValue();

	float fCombSpread = fPredelay / float(REVERB_COMB_FILTERS);
	float fAllpassSpread = fDiffusion / float(REVERB_ALLPASS_FILTERS);

	float *lpTemp = new float[uiSamples];
	float *lpBuffer = new float[uiSamples];
	memset(lpBuffer, 0, sizeof(float) * uiSamples);

	float fNormalize = 1.0f / float(REVERB_COMB_FILTERS);
	for(i = 0; i < REVERB_COMB_FILTERS; i++)
	{
		float fCombDecay = fDecay - fNormalize * (float)i * this->pDecay->GetMin();
		unsigned int uiBufferOffset = this->lpCombBuffers[i]() - (unsigned int)ceilf((float)uiSamplesPerSecond * (fPredelay + (float)i * fCombSpread)) - uiSamples;

		for(j = 0; j < uiSamples; j++)
		{
			lpTemp[j] = lpData[j] + this->lpCombBuffers[i][uiBufferOffset + j] * fCombDecay;
			lpBuffer[j] += fNormalize * lpTemp[j];
		}
		this->lpCombBuffers[i].Advance(uiSamples, lpTemp);
	}

	float fGain = 1.0f / sqrtf(2.0f/*float(REVERB_ALLPASS_FILTERS)*/);
	for(i = 0; i < REVERB_ALLPASS_FILTERS; i++)
	{
		unsigned int uiBufferOffset = this->lpAllPassBuffers[i]() - (unsigned int)ceilf((float)uiSamplesPerSecond * (fDiffusion - (float)i * fAllpassSpread)) - uiSamples;

		for(j = 0; j < uiSamples; j++)
		{
			float fTemp = this->lpAllPassBuffers[i][uiBufferOffset + j];
			lpTemp[j] = lpBuffer[j] + fTemp * fGain;
			lpBuffer[j] = -(lpTemp[j] * fGain) + fTemp;
		}
		this->lpAllPassBuffers[i].Advance(uiSamples, lpTemp);
	}

	for(i = 0; i < uiSamples; i++)
	{
		lpData[i] = fOneMinusDepth * lpData[i] + fDepth * lpBuffer[i];
	}

	delete []lpBuffer;
	delete []lpTemp;
}
