/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Overdrive.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(COverdriveInfo, COverdrive, OverdriveInfo);

COverdrive::COverdrive(CEngine &Engine) : CUnit(COverdrive::OverdriveInfo, Engine), pPower(0), pLevel(0), pTone(0), pGain(0), pStomp(0)
{

}

COverdrive::~COverdrive()
{
	this->Unload();
}

bool COverdrive::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/overdrive.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pLevel = new CKnob(*this, "Level", 0.0f, 2.0f, 1.0f);
	this->pLevel->SetPosition(CVector(20, 28));
	this->pLevel->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pLevel);

	this->pTone = new CKnob(*this, "Tone", 0.0f, 0.5f, 0.25f);
	this->pTone->SetPosition(CVector(60, 42));
	this->pTone->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pTone);

	this->pGain = new CKnob(*this, "Gain", 0.0f, 40.0f, 20.0f);
	this->pGain->SetPosition(CVector(100, 28));
	this->pGain->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pGain);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	return true;
}

void COverdrive::UnloadInternal()
{
	this->pPower = 0;
	this->pLevel = 0;
	this->pTone = 0;
	this->pGain = 0;
	this->pStomp = 0;
}

void COverdrive::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void COverdrive::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		return;
	}

	float fLevel = this->pLevel->GetValue();
	float fTone = this->pTone->GetValue();
	float fGain = powf(10.0f, this->pGain->GetValue() / 20.0f);

	float fToneStart = 1.0f - fTone;

	for(unsigned int i = 0; i < uiSamples; i++)
	{
		lpData[i] *= fGain;

		if(lpData[i] < -1.0f)
		{
			lpData[i] = -1.0f;
		}
		else if(lpData[i] > 1.0f)
		{
			lpData[i] = 1.0f;
		}
		else if(lpData[i] < -fToneStart)
		{
			float fRemainder = -(lpData[i] + fToneStart);
			float fTemp = fRemainder / fTone;
			//fTemp = 1.0f - (fTemp - fTemp * fTemp);
			fTemp = 1.0f + (fTemp - fTemp * fTemp);
			lpData[i] = -fToneStart - fRemainder * fTemp;
		}
		else if(lpData[i] > fToneStart)
		{
			float fRemainder = lpData[i] - fToneStart;
			float fTemp = fRemainder / fTone;
			//fTemp = 1.0f - (fTemp - fTemp * fTemp);
			fTemp = 1.0f + (fTemp - fTemp * fTemp);
			lpData[i] = fToneStart + fRemainder * fTemp;
		}

		lpData[i] *= fLevel;
	}

	fNormalizer = fLevel;
}
