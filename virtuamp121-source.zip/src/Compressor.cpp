/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Compressor.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CCompressorInfo, CCompressor, CompressorInfo);

CCompressor::CCompressor(CEngine &Engine) : CUnit(CCompressor::CompressorInfo, Engine), pPower(0), pAttack(0), pLevel(0), pSustain(0), pStomp(0), Buffer()
{

}

CCompressor::~CCompressor()
{
	this->Unload();
}

bool CCompressor::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/compressor.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pLevel = new CKnob(*this, "Level", 0.0f, 1.0f, 0.75f);
	this->pLevel->SetPosition(CVector(9, 34));
	this->pLevel->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pLevel);

	this->pAttack = new CKnob(*this, "Attack", 0.0f, 0.5f, 0.25f);
	this->pAttack->SetPosition(CVector(77, 34));
	this->pAttack->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pAttack);

	this->pSustain = new CKnob(*this, "Sustain", 0.0f, 16.0f, 8.0f);
	this->pSustain->SetPosition(CVector(111, 34));
	this->pSustain->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pSustain);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->fInputLevel = 0.0f;
	this->fInputPeak = 0.0f;
	this->fInputVelocity = 0.0f;
	this->fOutputLevel = 0.0f;
	this->fOutputPeak = 0.0f;
	this->fOutputVelocity = 0.0f;
	this->fSampleLevel = 0.0f;

	return true;
}

void CCompressor::UnloadInternal()
{
	this->pPower = 0;
	this->pAttack = 0;
	this->pLevel = 0;
	this->pSustain = 0;
	this->pStomp = 0;

	this->Buffer.Clear();
}

void CCompressor::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();

	if(this->fInputLevel > 0.0f)
	{
		float fLevel = this->fInputLevel > 1.0f ? 1.0f : this->fInputLevel;
		CVector TopLeft = CVector(45, 35);
		CVector BottomRight = CVector(56, 65);
		TopLeft.Y += (int)((1.0f - fLevel) * (float)(BottomRight.Y - TopLeft.Y));

		glBegin(GL_QUADS);
		glColor3ub(255, 128, 128);
		glVertex2i(TopLeft.X, TopLeft.Y);
		glColor3ub(128, 255, 128);
		glVertex2i(TopLeft.X, BottomRight.Y);
		glColor3ub(128, 255, 128);
		glVertex2i(BottomRight.X, BottomRight.Y);
		glColor3ub(255, 128, 128);
		glVertex2i(BottomRight.X, TopLeft.Y);
		glEnd();

		glColor3ub(255, 255, 255);
	}

	if(this->fInputPeak > 0.0f)
	{
		float fLevel = this->fInputPeak > 1.0f ? 1.0f : this->fInputPeak;
		CVector TopLeft = CVector(45, 35);
		CVector BottomRight = CVector(56, 65);
		TopLeft.Y += (int)((1.0f - fLevel) * (float)(BottomRight.Y - TopLeft.Y));

		glColor3ub(240, 240, 240);

		glBegin(GL_LINES);
		glVertex2i(TopLeft.X, TopLeft.Y);
		glVertex2i(BottomRight.X, TopLeft.Y);
		glEnd();

		glColor3ub(255, 255, 255);
	}

	if(this->fOutputLevel > 0.0f)
	{
		float fLevel = this->fOutputLevel > 1.0f ? 1.0f : this->fOutputLevel;
		CVector TopLeft = CVector(62, 35);
		CVector BottomRight = CVector(73, 65);
		TopLeft.Y += (int)((1.0f - fLevel) * (float)(BottomRight.Y - TopLeft.Y));

		glBegin(GL_QUADS);
		glColor3ub(255, 128, 128);
		glVertex2i(TopLeft.X, TopLeft.Y);
		glColor3ub(128, 255, 128);
		glVertex2i(TopLeft.X, BottomRight.Y);
		glColor3ub(128, 255, 128);
		glVertex2i(BottomRight.X, BottomRight.Y);
		glColor3ub(255, 128, 128);
		glVertex2i(BottomRight.X, TopLeft.Y);
		glEnd();

		glColor3ub(255, 255, 255);
	}

	if(this->fOutputPeak > 0.0f)
	{
		float fLevel = this->fOutputPeak > 1.0f ? 1.0f : this->fOutputPeak;
		CVector TopLeft = CVector(62, 35);
		CVector BottomRight = CVector(73, 65);
		TopLeft.Y += (int)((1.0f - fLevel) * (float)(BottomRight.Y - TopLeft.Y));

		glColor3ub(240, 240, 240);

		glBegin(GL_LINES);
		glVertex2i(TopLeft.X, TopLeft.Y);
		glVertex2i(BottomRight.X, TopLeft.Y);
		glEnd();

		glColor3ub(255, 255, 255);
	}
}

void CCompressor::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	this->Buffer.SetSamples(uiSamplesPerSecond / 10);
	this->Buffer.Advance(uiSamples, lpData);

	float fMin = *this->Buffer.GetBuffer(), fMax = *this->Buffer.GetBuffer();
	for(unsigned int i = 1; i < this->Buffer(); i++)
	{
		if(this->Buffer[i] < fMin)
		{
			fMin = this->Buffer[i];
		}
		if(this->Buffer[i] > fMax)
		{
			fMax = this->Buffer[i];
		}
	}

	float fFade = 0.05f * ((float)uiSamples / (float)uiSamplesPerSecond);
	this->fInputVelocity += fFade;
	this->fInputPeak -= this->fInputVelocity;
	if(this->fInputPeak < 0.0f)
		this->fInputPeak = 0.0f;
	this->fOutputVelocity += fFade;
	this->fOutputPeak -= this->fOutputVelocity;
	if(this->fOutputPeak < 0.0f)
		this->fOutputPeak = 0.0f;

	if(!this->pStomp->GetPressed())
	{
		this->fSampleLevel = this->fOutputLevel = this->fInputLevel = fMax - fMin;
		if(this->fInputLevel > this->fInputPeak)
		{
			this->fInputPeak = this->fInputLevel;
			this->fInputVelocity = 0.0f;
		}
		if(this->fOutputLevel > this->fOutputPeak)
		{
			this->fOutputPeak = this->fOutputLevel;
			this->fOutputVelocity = 0.0f;
		}
		return;
	}

	float fLastInputLevel = this->fInputLevel;
	this->fInputLevel = fMax - fMin;

	float fLevel = this->pLevel->GetValue();

	if(this->fInputLevel != 0.0f)
	{
		float fAttack = this->pAttack->GetValue();
		float fSustain = this->pSustain->GetValue();

		float fNormalize0 = (1.0f / (fLastInputLevel > 0.15f ? fLastInputLevel : 0.15f)) * fLevel;
		float fNormalize1 = (1.0f / (this->fInputLevel > 0.15f ? this->fInputLevel : 0.15f)) * fLevel;

		if(this->fInputLevel > 0.05f && (this->fInputLevel > fLastInputLevel * 0.95f || this->fInputLevel > this->fSampleLevel * fNormalizer))
		{
			float fStep;
			if(fAttack == 0.0f)
				fStep = fNormalize1;
			else
				fStep = fNormalize1 / (fAttack * (float)uiSamplesPerSecond);

			unsigned int i = 0;
			for(; i < uiSamples; i++)
			{
				this->fSampleLevel += fStep;
				if(this->fSampleLevel >= fNormalizer)
					break;

				float fI = (float)i / (float)uiSamples;
				lpData[i] *= ((1.0f - fI) * fNormalize0 + fI * fNormalize1) * this->fSampleLevel;
			}

			if(i < uiSamples)
			{
				this->fSampleLevel = fNormalizer;

				for(; i < uiSamples; i++)
				{
					float fI = (float)i / (float)uiSamples;
					lpData[i] *= ((1.0f - fI) * fNormalize0 + fI * fNormalize1);
				}
			}	
		}
		else
		{
			float fStep;
			if(fSustain == 0.0f)
				fStep = fNormalize1;
			else
				fStep = fNormalize1 / (fSustain * (float)uiSamplesPerSecond);

			unsigned int i = 0;
			for(; i < uiSamples; i++)
			{
				this->fSampleLevel -= fStep;
				if(this->fSampleLevel <= 0.0f)
					break;

				float fI = (float)i / (float)uiSamples;
				lpData[i] *= ((1.0f - fI) * fNormalize0 + fI * fNormalize1) * this->fSampleLevel;
			}

			if(i < uiSamples)
			{
				this->fSampleLevel = 0.0f;

				for(; i < uiSamples; i++)
				{
					lpData[i] = 0.0f;
				}
			}
		}
	}
	else
	{
		this->fSampleLevel = 0.0f;
		memset(lpData, 0, sizeof(float) * uiSamples);
	}

	this->fOutputLevel = this->fSampleLevel * fLevel;

	if(this->fInputLevel > this->fInputPeak)
	{
		this->fInputPeak = this->fInputLevel;
		this->fInputVelocity = 0.0f;
	}
	if(this->fOutputLevel > this->fOutputPeak)
	{
		this->fOutputPeak = this->fOutputLevel;
		this->fOutputVelocity = 0.0f;
	}

	//fNormalizer = fLevel;
}
