/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "AudioBuffer.h"
#include "Unit.h"

#define LOOP_STATION_TRACKS 10

namespace VAmp
{
	namespace Units
	{
		class CLoopStation : public CUnit
		{
			REGISTER_UNIT(CLoopStationInfo, CLoopStation, LoopStationInfo, UNIT_TYPE_LOOP_STATION, "Loop Station", CATEGORY_PLAYBACK);

		private:
			CSprite *pBeatStart;
			CSprite *pBeat;
			CSprite *pPower;
			CSprite *pRecord;
			CKnob *pLevel;
			CKnob *pTrackLevel;
			CKnob *pTrack;
			CKnob *pTime;
			CButton *pReset;
			CButton *pReverse;
			CButton *pErase;
			CButton *pPlayRecord;
			CStomp *pStomp;

			class CTrack
			{
			public:
				float fLevel;
				bool bReverse;
				bool bErased;
				DSP::CAudioBuffer Buffer;

			public:
				CTrack() : fLevel(1.0f), bReverse(false), bErased(true), Buffer()
				{
				}
			};

			bool bLastRecording;
			unsigned int uiIndex;
			unsigned int uiLastTrack;
			CTrack Tracks[LOOP_STATION_TRACKS];

		public:
			CLoopStation(CEngine &Engine);
			virtual ~CLoopStation();

		protected:
			virtual bool LoadInternal();
			virtual void UnloadInternal();

			virtual void RenderInternal();

			virtual void ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer);

		private:
			void OnReset(CButton &Button);
			void OnReverse(CButton &Button);
			void OnErase(CButton &Button);
			void OnPlayRecord(CButton &Button);
		};
	}
}
