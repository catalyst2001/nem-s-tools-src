/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"

namespace VAmp
{
	class CVector
	{
	public:
		static const CVector Null;

	public:
		union
		{
			struct
			{
				int X;
				int Y;
			};
			int Components[2];
		};

	public:
		inline CVector()
		{

		}

		inline CVector(const int iX, const int iY) : X(iX), Y(iY)
		{

		}

		inline CVector(const int *lpComponents) : X(lpComponents[0]), Y(lpComponents[1])
		{

		}

		inline CVector(const CVector &Vector) : X(Vector.X), Y(Vector.Y)
		{

		}

		inline int &operator[](int iIndex)
		{
			assert(iIndex >= 0 && iIndex < 1);

			return this->Components[iIndex];
		}

		inline int operator[](int iIndex) const
		{
			assert(iIndex >= 0 && iIndex < 1);

			return this->Components[iIndex];
		}

		inline bool operator==(const CVector &Vector) const
		{
			return this->X == Vector.X && this->Y == Vector.Y;
		}

		inline bool operator!=(const CVector &Vector) const
		{
			return this->X != Vector.X || this->Y != Vector.Y;
		}

		inline CVector operator+() const
		{
			return CVector(this->X < 0 ? -this->X : this->X, this->Y < 0 ? -this->Y : this->Y);
		}

		inline CVector operator+(const CVector &Vector) const
		{
			return CVector(this->X + Vector.X, this->Y + Vector.Y);
		}

		inline CVector &operator+=(const CVector &Vector)
		{
			this->X += Vector.X;
			this->Y += Vector.Y;

			return *this;
		}

		inline CVector operator-() const
		{
			return CVector(-this->X, -this->Y);
		}

		inline CVector operator-(const CVector &Vector) const
		{
			return CVector(this->X - Vector.X, this->Y - Vector.Y);
		}

		inline CVector &operator-=(const CVector &Vector)
		{
			this->X -= Vector.X;
			this->Y -= Vector.Y;

			return *this;
		}

		inline CVector operator*(int iValue) const
		{
			return CVector(this->X * iValue, this->Y * iValue);
		}

		inline CVector &operator*=(int iValue)
		{
			this->X *= iValue;
			this->Y *= iValue;

			return *this;
		}

		inline CVector operator/(int iValue) const
		{
			return CVector(this->X / iValue, this->Y / iValue);
		}

		inline CVector &operator/=(int iValue)
		{
			this->X /= iValue;
			this->Y /= iValue;

			return *this;
		}

		inline int GetLength() const
		{
			return (int)froundf(sqrtf((float)(this->X * this->X) + (float)(this->Y * this->Y)));
		}

		static inline bool Intersects(const CVector &Min, const CVector &Max, const CVector &Vector)
		{
			return (Vector.X >= Min.X && Vector.X <= Max.X) && (Vector.Y >= Min.Y && Vector.Y <= Max.Y);
		}

		static inline bool Intersects(const CVector &Min0, const CVector &Max0, const CVector &Min1, const CVector &Max1)
		{
			return Min0.X <= Max1.X && Min0.Y <= Max1.Y && Max0.X >= Min1.X && Max0.Y >= Min1.Y;
		}
	};
}
