/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "virtuAMP.h"
#include "Log.h"

using namespace VAmp;

CLog::CLog(const char *lpFileName)
{
	InitializeCriticalSection(&this->CriticalSection);

	char lpFullFileName[MAX_PATH];
	GetFullFileName(lpFileName, lpFullFileName, sizeof(lpFullFileName));

	this->pFile = fopen(lpFullFileName, "wb");
	*this->lpLastError = '\0';
}

CLog::~CLog()
{
	if(this->pFile != 0)
	{
		fclose(this->pFile);
	}

	DeleteCriticalSection(&this->CriticalSection);
}

void CLog::Log(EMessageType eMessageType, const char *lpFormat, ...)
{
	va_list ArgumentList;
	va_start(ArgumentList, lpFormat);
	this->Log(eMessageType, lpFormat, ArgumentList);
	va_end(ArgumentList);
}

void CLog::Log(EMessageType eMessageType, const char *lpFormat, va_list ArgumentList)
{
	EnterCriticalSection(&this->CriticalSection);

	char lpMessageType[8192] = "";
	char lpMessageContent[8192] = "";
	char lpMessageExtra[8192] = "";

	_vsnprintf(lpMessageContent, sizeof(lpMessageContent), lpFormat, ArgumentList);
	lpMessageContent[sizeof(lpMessageContent) - 1] = '\0';

	switch(eMessageType)
	{
		case MESSAGE_TYPE_ERROR:
		{
			strcpy(lpMessageType, "Error: ");
			break;
		}
		case MESSAGE_TYPE_SYSTEM_ERROR:
		{
			strcpy(lpMessageType, "System Error: ");

			DWORD dwLastError = ::GetLastError();

			LPVOID lpMessage;

			if(FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwLastError, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPSTR)&lpMessage, 0, NULL))
			{
				_snprintf(lpMessageExtra, sizeof(lpMessageExtra), "(Code: 0x%.8x; Message: %s)", dwLastError, lpMessage);
				lpMessageExtra[sizeof(lpMessageExtra) - 1] = '\0';

				char *pTemp = lpMessageExtra;
				for(; *pTemp; pTemp++)
				{
					if(*pTemp == '\r' || *pTemp == '\n')
					{
						*pTemp = ' ';
					}
				}

				LocalFree(lpMessage);
			}
			else
			{
				_snprintf(lpMessageExtra, sizeof(lpMessageExtra), "(Code: 0x%.8x; Message: %s)", dwLastError, "<Unable to retrieve system error message string.>");
				lpMessageExtra[sizeof(lpMessageExtra) - 1] = '\0';
			}
			break;
		}
#ifdef USE_DIRECTSOUND
		case MESSAGE_TYPE_DIRECTSOUND_ERROR:
		{
			strcpy(lpMessageType, "Direct Sound Error: ");

			const char *lpMessage = DXGetErrorString8(LastDirectSoundError);

			if(lpMessage != 0)
			{
				_snprintf(lpMessageExtra, sizeof(lpMessageExtra), "(Code: 0x%.8x; Message: %s)", LastDirectSoundError, lpMessage);
				lpMessageExtra[sizeof(lpMessageExtra) - 1] = '\0';

				char *pTemp = lpMessageExtra;
				for(; *pTemp; pTemp++)
				{
					if(*pTemp == '\r' || *pTemp == '\n')
					{
						*pTemp = ' ';
					}
				}
			}
			else
			{
				_snprintf(lpMessageExtra, sizeof(lpMessageExtra), "(Code: 0x%.8x; Message: %s)", LastDirectSoundError, "<Unable to retrieve direct sound error message string.>");
				lpMessageExtra[sizeof(lpMessageExtra) - 1] = '\0';
			}
		
			break;
		}
#endif
	}

	if(this->pFile != 0)
	{
		if(*lpMessageContent)
		{
			if(*lpMessageType)
			{
				fwrite(lpMessageType, 1, strlen(lpMessageType), this->pFile);
			}
			fwrite(lpMessageContent, 1, strlen(lpMessageContent), this->pFile);
			if(*lpMessageExtra)
			{
				fwrite(lpMessageExtra, 1, strlen(lpMessageExtra), this->pFile);
			}
			fwrite("\r\n", 1, 2, this->pFile);
		}
	}

	switch(eMessageType)
	{
	case MESSAGE_TYPE_ERROR:
	case MESSAGE_TYPE_SYSTEM_ERROR:
		strcpy(this->lpLastError, lpMessageContent);
		break;
	}

	LeaveCriticalSection(&this->CriticalSection);
}

namespace VAmp
{
	CLog Log = CLog("log.txt");

	void LogMessage(const char *lpFormat, ...)
	{
		va_list ArgumentList;
		va_start(ArgumentList, lpFormat);
		Log.Log(MESSAGE_TYPE_INFO, lpFormat, ArgumentList);
		va_end(ArgumentList);
	}

	void LogError(const char *lpFormat, ...)
	{
		va_list ArgumentList;
		va_start(ArgumentList, lpFormat);
		Log.Log(MESSAGE_TYPE_ERROR, lpFormat, ArgumentList);
		va_end(ArgumentList);
	}

	void LogSystemError(const char *lpFormat, ...)
	{
		va_list ArgumentList;
		va_start(ArgumentList, lpFormat);
		Log.Log(MESSAGE_TYPE_SYSTEM_ERROR, lpFormat, ArgumentList);
		va_end(ArgumentList);
	}

#ifdef USE_DIRECTSOUND
	HRESULT LastDirectSoundError = 0;

	void LogDirectSoundError(HRESULT Error, const char *lpFormat, ...)
	{
		LastDirectSoundError = Error;

		va_list ArgumentList;
		va_start(ArgumentList, lpFormat);
		Log.Log(MESSAGE_TYPE_DIRECTSOUND_ERROR, lpFormat, ArgumentList);
		va_end(ArgumentList);
	}
#endif
}
