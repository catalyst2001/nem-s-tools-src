/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Tremolo.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CTremoloInfo, CTremolo, TremoloInfo);

CTremolo::CTremolo(CEngine &Engine) : CUnit(CTremolo::TremoloInfo, Engine), pPower(0), pDepth(0), pShape(0), pRate(0), pStomp(0)
{

}

CTremolo::~CTremolo()
{
	this->Unload();
}

bool CTremolo::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/tremolo.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CKnob(*this, "Depth", 0.0f, 1.0f, 0.5f);
	this->pDepth->SetPosition(CVector(20, 28));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDepth);

	this->pShape = new CKnob(*this, "Shape", 0.25f, 1.75f, 1.0f);
	this->pShape->SetPosition(CVector(60, 42));
	this->pShape->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pShape);

	this->pRate = new CKnob(*this, "Rate", 1.0f, 20.0f, 8.0f);
	this->pRate->SetPosition(CVector(100, 28));
	this->pRate->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pRate);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->fPhase = 0.0f;

	return true;
}

void CTremolo::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	this->pShape = 0;
	this->pRate = 0;
	this->pStomp = 0;
}

void CTremolo::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CTremolo::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed() || this->pDepth->GetValue() == 0.0f)
	{
		this->fPhase = 0.0f;
		return;
	}

	float fDepth = this->pDepth->GetValue();
	float fOneMinusDepth = 1.0f - fDepth;
	float fShape = this->pShape->GetValue();
	float fRate = VA_2PI / ((float)uiSamplesPerSecond / this->pRate->GetValue());

	for(unsigned int i = 0; i < uiSamples; i++)
	{
		float fAmplitude = cosf(fPhase++ * fRate);
		if(fAmplitude < 0.0f)
			fAmplitude = -powf(-fAmplitude, fShape);
		else
			fAmplitude = powf(fAmplitude, fShape);

		lpData[i] = fOneMinusDepth * lpData[i] + fDepth * lpData[i] * fAmplitude;
	}

	this->fPhase = fmodf(this->fPhase, (float)uiSamplesPerSecond / this->pRate->GetValue());
}
