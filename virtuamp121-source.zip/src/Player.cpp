/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "virtuAMP.h"
#include "Engine.h"
#include "Log.h"
#include "Player.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CPlayerInfo, CPlayer, PlayerInfo);

CPlayer::CPlayer(CEngine &Engine) : CUnit(CPlayer::PlayerInfo, Engine), pPower(0), pGain(0), pMix(0), pOpen(0), pStomp(0), hWaveIn(NULL), uiBufferSamples(0), lpBuffer(0)
{

}

CPlayer::~CPlayer()
{
	this->Unload();
}

bool CPlayer::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/Player.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pGain = new CKnob(*this, "Gain", -20.0f, 20.0f, 0.0f);
	this->pGain->SetPosition(CVector(36, 34));
	this->pGain->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pGain);

	this->pMix = new CKnob(*this, "Mix", 0.0f, 1.0f, 0.5f);
	this->pMix->SetPosition(CVector(84, 34));
	this->pMix->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pMix);

	this->pOpen = new CButton(*this, "FileName", new CButton::CEventClass<CPlayer>(this, &CPlayer::OnOpen));
	this->pOpen->SetPosition(CVector(127, 70));
	this->pOpen->SetTexture(this->Engine.LoadTexture("units/open.png"));
	this->pOpen->SetUpTexture(this->Engine.LoadTexture("units/button_u.png"));
	this->pOpen->SetDownTexture(this->Engine.LoadTexture("units/button_d.png"));
	this->Controls.push_back(this->pOpen);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPersistent(false);
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->hWaveIn = NULL;

	return true;
}

void CPlayer::UnloadInternal()
{
	this->StopPlaying();

	this->Engine.UnloadTexture(this->pOpen->GetUpTexture());
	this->Engine.UnloadTexture(this->pOpen->GetDownTexture());

	this->pPower = 0;
	this->pGain = 0;
	this->pMix = 0;
	this->pOpen = 0;
	this->pStomp = 0;

	this->uiBufferSamples = 0;

	delete []this->lpBuffer;
	this->lpBuffer = 0;
}

void CPlayer::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CPlayer::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		this->StopPlaying();
		return;
	}

	if(!this->IsPlaying())
	{
		if(!this->StartPlaying(uiSamplesPerSecond))
		{
			this->pStomp->SetPressed(false);
			return;
		}
	}

	float fGain = powf(10.0f, this->pGain->GetValue() / 20.0f);
	float fMix = this->pMix->GetValue();
	float fOneMinusMix = 1.0f - fMix;

	unsigned int uiSampleLength = this->WaveFormat.wf.nBlockAlign;
	unsigned int uiInputSamples = 0;

	if(fMix == 0.0f)
	{
		LONG iCurrent = mmioSeek(this->hWaveIn, 0, SEEK_CUR);
		LONG iEnd = mmioSeek(this->hWaveIn, 0, SEEK_END);
		if(iCurrent > 0)
		{
			iCurrent = mmioSeek(this->hWaveIn, iCurrent + (LONG)uiSamples * uiSampleLength, SEEK_SET);
		}
		
		uiInputSamples = (iCurrent == -1 || iEnd == -1 || iCurrent > iEnd) ? 0 : uiSamples;

		for(unsigned int i = 0; i < uiSamples; i++)
		{
			lpData[i] = fOneMinusMix * lpData[i];
		}
	}
	else
	{
		if(this->uiBufferSamples != uiSamples)
		{
			this->uiBufferSamples = uiSamples;

			delete []this->lpBuffer;
			this->lpBuffer = new char[this->uiBufferSamples * uiSampleLength];
		}

		// Read the WAVE data.
		LONG iResult = mmioRead(this->hWaveIn, this->lpBuffer, uiSamples * uiSampleLength);
		if(iResult > 0)
		{
			uiInputSamples = (unsigned int)iResult / uiSampleLength;
		}

		//while(1)
		//{
		//	LONG iResult = mmioRead(this->hWaveIn, this->lpBuffer + uiInputSamples * uiSampleLength, (uiSamples - uiInputSamples) * uiSampleLength);
		//	if(iResult < 0)
		//	{
		//		break;
		//	}
		//	else
		//	{
		//		uiInputSamples += (unsigned int)iResult / uiSampleLength;
		//		if(uiInputSamples < uiSamples)
		//		{
		//			mmioSeek(this->hWaveIn, 0, SEEK_SET);
		//		}
		//		else
		//		{
		//			break;
		//		}
		//	}
		//}

		switch(this->WaveFormat.wf.wFormatTag)
		{
		case WAVE_FORMAT_PCM:
			switch(this->WaveFormat.wBitsPerSample)
			{
			case 8:
				if(this->WaveFormat.wf.nChannels == 1)
				{
					float fNormalizedMix = fMix / 128.0f;
					for(unsigned int i = 0; i < uiInputSamples; i++)
					{
						lpData[i] = fNormalizedMix * (float)((int)this->lpBuffer[i] - 128) * fGain + fOneMinusMix * lpData[i];
					}
				}
				else
				{
					unsigned char *lpCurrent = reinterpret_cast<unsigned char *>(this->lpBuffer);
					float fNormalizedMix = fMix / ((float)this->WaveFormat.wf.nChannels * 128.0f);
					for(unsigned int i = 0; i < uiInputSamples; i++)
					{
						int iValue = (int)lpCurrent[0] - 128;
						for(WORD j = 1; j < this->WaveFormat.wf.nChannels; j++)
						{
							iValue += (int)lpCurrent[j] - 128;
						}

						lpData[i] = fNormalizedMix * (float)iValue * fGain + fOneMinusMix * lpData[i];

						lpCurrent += this->WaveFormat.wf.nChannels;
					}
				}
				break;
			case 16:
				if(this->WaveFormat.wf.nChannels == 1)
				{
					float fNormalizedMix = fMix / 32768.0f;
					for(unsigned int i = 0; i < uiInputSamples; i++)
					{
						lpData[i] = fNormalizedMix * (float)reinterpret_cast<short *>(this->lpBuffer)[i] * fGain + fOneMinusMix * lpData[i];
					}
				}
				else
				{
					short *lpCurrent = reinterpret_cast<short *>(this->lpBuffer);
					float fNormalizedMix = fMix / ((float)this->WaveFormat.wf.nChannels * 32768.0f);
					for(unsigned int i = 0; i < uiInputSamples; i++)
					{
						int iValue = lpCurrent[0];
						for(WORD j = 1; j < this->WaveFormat.wf.nChannels; j++)
						{
							iValue += lpCurrent[j];
						}

						lpData[i] = fNormalizedMix * (float)iValue * fGain + fOneMinusMix * lpData[i];

						lpCurrent += this->WaveFormat.wf.nChannels;
					}
				}
				break;
			}
			break;
		case WAVE_FORMAT_IEEE_FLOAT:
			switch(this->WaveFormat.wBitsPerSample)
			{
			case 32:
				if(this->WaveFormat.wf.nChannels == 1)
				{
					for(unsigned int i = 0; i < uiInputSamples; i++)
					{
						lpData[i] = fMix * reinterpret_cast<float *>(this->lpBuffer)[i] * fGain + fOneMinusMix * lpData[i];
					}
				}
				else
				{
					float *lpCurrent = reinterpret_cast<float *>(this->lpBuffer);
					float fNormalizedMix = fMix / (float)this->WaveFormat.wf.nChannels;
					for(unsigned int i = 0; i < uiInputSamples; i++)
					{
						float fValue = lpCurrent[0];
						for(WORD j = 1; j < this->WaveFormat.wf.nChannels; j++)
						{
							fValue += lpCurrent[j];
						}

						lpData[i] = fNormalizedMix * fValue * fGain + fOneMinusMix * lpData[i];

						lpCurrent += this->WaveFormat.wf.nChannels;
					}
				}
				break;
			case 64:
				if(this->WaveFormat.wf.nChannels == 1)
				{
					for(unsigned int i = 0; i < uiInputSamples; i++)
					{
						lpData[i] = fMix * (float)reinterpret_cast<double *>(this->lpBuffer)[i] * fGain + fOneMinusMix * lpData[i];
					}
				}
				else
				{
					double *lpCurrent = reinterpret_cast<double *>(this->lpBuffer);
					float fNormalizedMix = fMix / (float)this->WaveFormat.wf.nChannels;
					for(unsigned int i = 0; i < uiInputSamples; i++)
					{
						float fValue = (float)lpCurrent[0];
						for(WORD j = 1; j < this->WaveFormat.wf.nChannels; j++)
						{
							fValue += (float)lpCurrent[j];
						}

						lpData[i] = fNormalizedMix * fValue * fGain + fOneMinusMix * lpData[i];

						lpCurrent += this->WaveFormat.wf.nChannels;
					}
				}
				break;
			}
			break;
		}

		for(unsigned int i = uiInputSamples; i < uiSamples; i++)
		{
			lpData[i] = fOneMinusMix * lpData[i];
		}
	}

	fNormalizer = fMix * fGain + fOneMinusMix * fNormalizer;

	if(uiInputSamples == 0)
	{
		this->pStomp->SetPressed(false);
	}
}

void CPlayer::OnOpen(CButton &Button)
{
	char lpFileName[MAX_PATH] = "";
	if(this->pOpen->GetValue() != 0)
	{
		strcpy(lpFileName, this->pOpen->GetValue());
	}

	if(ShowFileDialog(FILE_DIALOG_OPEN, "Open Recording", "Wave Files (*.wav)\0*.wav\0", "wav", lpFileName, sizeof(lpFileName)))
	{
		this->StopPlaying();
		this->pStomp->SetPressed(false);

		this->pOpen->SetValue(lpFileName);
	}
}

bool CPlayer::IsPlaying()
{
	return this->hWaveIn != NULL;
}

bool CPlayer::StartPlaying(unsigned int uiSamplesPerSecond)
{
	if(this->IsPlaying())
	{
		return true;
	}

	if(this->pOpen->GetValue() == 0 || *this->pOpen->GetValue() == '\0')
	{
		return false;
	}

	memset(&this->WaveInfo, 0, sizeof(MMCKINFO));
	memset(&this->WaveFormatInfo, 0, sizeof(MMCKINFO));
	memset(&this->WaveDataInfo, 0, sizeof(MMCKINFO));
	memset(&this->WaveFormat, 0, sizeof(PCMWAVEFORMAT));

	this->uiBufferSamples = 0;

	delete []this->lpBuffer;
	this->lpBuffer = 0;

	// Open the WAVE file.
	if((this->hWaveIn = mmioOpen(const_cast<char *>(this->pOpen->GetValue()), 0, MMIO_READ | MMIO_ALLOCBUF | MMIO_DENYWRITE)) == NULL)
	{
		LogError("Error opening %s for reading.", this->pOpen->GetValue());
		return false;
	}

	// Descend to WAVE chunk.
	this->WaveInfo.fccType = mmioFOURCC('W', 'A', 'V', 'E');

	if(mmioDescend(this->hWaveIn, &this->WaveInfo, 0, MMIO_FINDRIFF) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveIn, 0);
		this->hWaveIn= NULL;

		LogError("Error descending to WAVE chunk for %s.", this->pOpen->GetValue());
		return false;
	}

	// Descend to WAVE format chunk.
	this->WaveFormatInfo.ckid = mmioFOURCC('f', 'm', 't', ' ');

	if(mmioDescend(this->hWaveIn, &this->WaveFormatInfo, &this->WaveInfo, 0) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveIn, 0);
		this->hWaveIn= NULL;

		LogError("Error descending to WAVE format chunk for %s.", this->pOpen->GetValue());
		return false;
	}

	// Read WAVE format.
	if(mmioRead(this->hWaveIn, (HPSTR)&this->WaveFormat, sizeof(PCMWAVEFORMAT)) != sizeof(PCMWAVEFORMAT))
	{
		mmioClose(this->hWaveIn, 0);
		this->hWaveIn= NULL;

		LogError("Error reading WAVE format chunk for %s.", this->pOpen->GetValue());
		return false;
	}

	bool bSupportedFormat = true;

	switch(this->WaveFormat.wf.wFormatTag)
	{
	case WAVE_FORMAT_PCM:
		if(this->WaveFormat.wf.nChannels <= 0)
		{
			bSupportedFormat = false;
			LogError("PCM WAVE data chunk for %s has no channels.", this->pOpen->GetValue());
		}
		if(this->WaveFormat.wf.nSamplesPerSec != uiSamplesPerSecond)
		{
			bSupportedFormat = false;
			LogError("PCM WAVE data chunk for %s is not sampled at %u Hz.", this->pOpen->GetValue(), uiSamplesPerSecond);
		}
		if(this->WaveFormat.wf.nBlockAlign != this->WaveFormat.wf.nChannels * (this->WaveFormat.wBitsPerSample / 8))
		{
			bSupportedFormat = false;
			LogError("PCM WAVE data chunk for %s is not tightly packed.", this->pOpen->GetValue());
		}
		if(this->WaveFormat.wBitsPerSample != 8 && this->WaveFormat.wBitsPerSample != 16)
		{
			bSupportedFormat = false;
			LogError("PCM WAVE data chunk for %s is not 8 or 16 bit.", this->pOpen->GetValue());
		}
		break;
	case WAVE_FORMAT_IEEE_FLOAT:
		if(this->WaveFormat.wf.nChannels <= 0)
		{
			bSupportedFormat = false;
			LogError("IEEE Float WAVE data chunk for %s has no channels.", this->pOpen->GetValue());
		}
		if(this->WaveFormat.wf.nSamplesPerSec != uiSamplesPerSecond)
		{
			bSupportedFormat = false;
			LogError("IEEE Float WAVE data chunk for %s is not sampled at %u Hz.", this->pOpen->GetValue(), uiSamplesPerSecond);
		}
		if(this->WaveFormat.wf.nBlockAlign != this->WaveFormat.wf.nChannels * (this->WaveFormat.wBitsPerSample / 8))
		{
			bSupportedFormat = false;
			LogError("IEEE Float WAVE data chunk for %s is not tightly packed.", this->pOpen->GetValue());
		}
		if(this->WaveFormat.wBitsPerSample != 32 && this->WaveFormat.wBitsPerSample != 64)
		{
			bSupportedFormat = false;
			LogError("IEEE Float WAVE data chunk for %s is not 32 or 64 bit.", this->pOpen->GetValue());
		}
		break;
	default:
		bSupportedFormat = false;
		LogError("WAVE data chunk for %s is not PCM or IEEE floating point.", this->pOpen->GetValue());
		break;
	}

	if(!bSupportedFormat)
	{
		mmioClose(this->hWaveIn, 0);
		this->hWaveIn= NULL;

		return false;
	}

	// Ascend to the WAVE layer.
	if(mmioAscend(this->hWaveIn, &this->WaveFormatInfo, 0) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveIn, 0);
		this->hWaveIn= NULL;

		LogError("Error ascending from WAVE format chunk for %s.", this->pOpen->GetValue());
		return false;
	}

	// Create WAVE data chunk.
	this->WaveDataInfo.ckid = mmioFOURCC('d', 'a', 't', 'a');

	if(mmioDescend(this->hWaveIn, &this->WaveDataInfo, &this->WaveInfo, MMIO_FINDCHUNK) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveIn, 0);
		this->hWaveIn= NULL;

		LogError("Error descending to WAVE data chunk for %s.", this->pOpen->GetValue());
		return false;
	}

	if(this->WaveDataInfo.cksize == 0)
	{
		mmioClose(this->hWaveIn, 0);
		this->hWaveIn= NULL;

		LogError("WAVE data chunk for %s contains no data.", this->pOpen->GetValue());
		return false;
	}

	return true;
}

void CPlayer::StopPlaying()
{
	if(!this->IsPlaying())
	{
		return;
	}

	if(mmioAscend(this->hWaveIn, &this->WaveDataInfo, 0) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveIn, 0);
		this->hWaveIn= NULL;

		LogError("Error ascending from WAVE data chunk for %s.", this->pOpen->GetValue());
		return;
	}

	if(mmioAscend(this->hWaveIn, &this->WaveInfo, 0) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveIn, 0);
		this->hWaveIn= NULL;

		LogError("Error ascending from WAVE chunk for %s.", this->pOpen->GetValue());
		return;
	}

	mmioClose(this->hWaveIn, 0);
	this->hWaveIn= NULL;
}
