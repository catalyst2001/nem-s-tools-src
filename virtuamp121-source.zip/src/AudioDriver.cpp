/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "AudioDriver.h"
#include "DirectSoundAudio.h"
#include "NullAudio.h"
#include "WinMMAudio.h"

using namespace VAmp;
using namespace VAmp::Audio;

CAudioDriver::CAudioDriver(HWND hWnd, CEngine *pEngine) : hWnd(hWnd), pEngine(pEngine)
{

}

CAudioDriver::~CAudioDriver()
{

}

namespace VAmp
{
	namespace Audio
	{
		const char *lpAudioDriverNames[] =
		{
			"Null",
			"Windows Multimedia",
#ifdef USE_DIRECTSOUND
			"DirectSound",
#endif
			0
		};
	}
}

EAudioDriver CAudioDriver::GetType(const char *lpName)
{
	for(unsigned int i = 0; i < AUDIO_DRIVER_COUNT; i++)
	{
		if(_stricmp(lpName, lpAudioDriverNames[i]) == 0)
		{
			return (EAudioDriver)i;
		}
	}

	return AUDIO_DRIVER_NULL;
}

const char *CAudioDriver::GetName(EAudioDriver eAudioDriver)
{
	if(eAudioDriver >= 0 && eAudioDriver < AUDIO_DRIVER_COUNT)
	{
		return lpAudioDriverNames[eAudioDriver];
	}

	return 0;
}

CAudioDriver *CAudioDriver::Create(EAudioDriver eAudioDriver, HWND hWnd, CEngine *pEngine)
{
	switch(eAudioDriver)
	{
	case Audio::AUDIO_DRIVER_NULL:
		return new VAmp::Audio::CNullAudio(hWnd, pEngine);
	case AUDIO_DRIVER_WINDOWS_MULTIMEDIA:
		return new VAmp::Audio::CWinMMAudio(hWnd, pEngine);
#ifdef USE_DIRECTSOUND
	case AUDIO_DRIVER_DIRECTSOUND:
		return new VAmp::Audio::CDirectSoundAudio(hWnd, pEngine);
#endif
	default:
		return 0;
	}
}
