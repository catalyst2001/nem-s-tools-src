/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "Rectangle.h"
#include "Texture.h"
#include "Vector.h"

namespace VAmp
{
	namespace Units
	{
		enum EControlType
		{
			CONTROL_TYPE_BUTTON,
			CONTROL_TYPE_KNOB,
			CONTROL_TYPE_SPRITE,
			CONTROL_TYPE_STOMP,
			CONTROL_TYPE_TOGGLE,
			CONTROL_TYPE_VERTICAL_SLIDER,
			CONTROL_TYPE_COUNT
		};

		class CUnit;

		class CControl
		{
		protected:
			CUnit &Unit;
			char *lpName;
			bool bPersistent;

			bool bVisible;
			CVector Position;
			CVector Size;
			CRectangle Rectangle;
			CTexture *pTexture;

		public:
			CControl(CUnit &Unit);
			CControl(CUnit &Unit, const char *lpName);
			virtual ~CControl();

			inline const char *GetName() const
			{
				return this->lpName;
			}

			inline void SetPersistent(bool bPersistent)
			{
				this->bPersistent = bPersistent;
			}

			inline bool GetPersistent() const
			{
				return this->bPersistent;
			}

			inline void SetVisible(bool bVisible)
			{
				this->bVisible = bVisible;
			}

			inline bool GetVisible() const
			{
				return this->bVisible;
			}

			inline void SetPosition(const CVector &Position)
			{
				this->Position = Position;
			}

			inline const CVector &GetPosition() const
			{
				return this->Position;
			}

			inline void SetSize(const CVector &Size)
			{
				this->Size = Size;
			}

			inline const CVector &GetSize() const
			{
				return this->Size;
			}

			inline void SetRectangle(const CRectangle &Rectangle)
			{
				this->Rectangle = Rectangle;
			}

			inline const CRectangle &GetRectangle() const
			{
				return this->Rectangle;
			}

			inline void SetTexture(CTexture *pTexture)
			{
				this->pTexture = pTexture;

				if(this->pTexture != 0 && this->Size.X == 0 && this->Size.Y == 0)
				{
					this->Size.X = this->pTexture->GetWidth();
					this->Size.Y = this->pTexture->GetHeight();
				}
			}

			inline CTexture *GetTexture() const
			{
				return this->pTexture;
			}

			virtual EControlType GetType() const = 0;

			void Render();

		protected:
			virtual void RenderInternal();
		};

		class CButton : public CControl
		{
		public:
			class CEvent
			{
			public:
				virtual ~CEvent()
				{

				}

				virtual void Call(CButton &Button) = 0;
			};

			template <class T>
			class CEventClass : public CEvent
			{
			private:
				T *pClass;
				void (T::*pEvent)(CButton &Button);

			public:
				CEventClass(T *pClass, void (T::*pEvent)(CButton &))
				{
					this->pClass = pClass;
					this->pEvent = pEvent;
				}

				virtual ~CEventClass()
				{

				}

				virtual void Call(CButton &Button)
				{
					(this->pClass->*pEvent)(Button);
				}
			};

		private:
			CEvent *pEvent;
			CTexture *pUpTexture;
			CTexture *pDownTexture;
			char *lpValue;

		public:
			CButton(CUnit &Unit, const char *lpName, CEvent *pEvent, char *lpValue = 0);
			virtual ~CButton();

			inline void SetValue(const char *lpValue)
			{
				delete []this->lpValue;
				if(lpValue != 0)
				{
					this->lpValue = new char[strlen(lpValue) + 1];
					strcpy(this->lpValue, lpValue);
				}
				else
				{
					this->lpValue = 0;
				}
			}

			inline void SetUpTexture(CTexture *pUpTexture)
			{
				this->pUpTexture = pUpTexture;

				if(this->pUpTexture != 0 && this->Size.X == 0 && this->Size.Y == 0)
				{
					this->Size.X = this->pUpTexture->GetWidth();
					this->Size.Y = this->pUpTexture->GetHeight();
				}
			}

			inline CTexture *GetUpTexture() const
			{
				return this->pUpTexture;
			}

			inline void SetDownTexture(CTexture *pDownTexture)
			{
				this->pDownTexture = pDownTexture;
			}

			inline CTexture *GetDownTexture() const
			{
				return this->pDownTexture;
			}

			inline const char *GetValue() const
			{
				return this->lpValue;
			}

			void Call()
			{
				if(this->pEvent != 0)
				{
					this->pEvent->Call(*this);
				}
			}

			virtual EControlType GetType() const;

		protected:
			virtual void RenderInternal();
		};

		class CKnob : public CControl
		{
		private:
			float fMin;
			float fMax;
			float fValue;
			bool bSwitch;

			float fMinRotation;
			float fMaxRotation;

		public:
			CKnob(CUnit &Unit, const char *lpName, float fMin = -1.0f, float fMax = 1.0f, float fValue = 0.0f, bool bSwitch = false, float fMinRotation = -135.0f, float fMaxRotation = 135.0f);
			virtual ~CKnob();

			inline void SetMin(float fMin)
			{
				this->fMin = fMin;
				if(this->fValue < this->fMin)
				{
					this->fValue = this->fMin;
				}
			}

			inline float GetMin() const
			{
				return this->fMin;
			}

			inline void SetMax(float fMax)
			{
				this->fMax = fMax;
				if(this->fValue > this->fMax)
				{
					this->fValue = this->fMax;
				}
			}

			inline float GetMax() const
			{
				return this->fMax;
			}

			inline void SetValue(float fValue)
			{
				if(fValue < this->fMin)
				{
					fValue = this->fMin;
				}
				else if(fValue > this->fMax)
				{
					fValue = this->fMax;
				}
				this->fValue = fValue;
			}

			inline float GetValue() const
			{
				if(this->bSwitch)
				{
					return froundf(this->fValue);
				}
				return this->fValue;
			}

			inline float GetValueInverse() const
			{
				if(this->bSwitch)
				{
					return froundf(this->fMax + this->fMin - this->fValue);
				}
				return this->fMax + this->fMin - this->fValue;
			}

			inline float GetValueExponential() const
			{
				float fValue = this->fValue - this->fMin;
				float fRange = this->fMax - this->fMin;
				fValue = this->fMin + ((fValue * fValue) / (fRange * fRange)) * fRange;
				if(this->bSwitch)
				{
					return froundf(fValue);
				}
				return fValue;
			}

			inline float GetTrackingValue() const
			{
				return this->fValue;
			}

			inline void SetMinRotation(float fMinRotation)
			{
				this->fMinRotation = fMinRotation;
			}

			inline float GetMinRotation() const
			{
				return this->fMinRotation;
			}

			inline void SetMaxRotation(float fMaxRotation)
			{
				this->fMaxRotation = fMaxRotation;
			}

			inline float GetMaxRotation() const
			{
				return this->fMaxRotation;
			}

			virtual EControlType GetType() const;

		protected:
			virtual void RenderInternal();
		};

		class CSprite : public CControl
		{
		public:
			CSprite(CUnit &Unit);
			virtual ~CSprite();

			virtual EControlType GetType() const;
		};

		class CStomp : public CControl
		{
		private:
			bool bPressed;

		public:
			CStomp(CUnit &Unit, const char *lpName, bool bPressed = false);
			virtual ~CStomp();

			inline void SetPressed(bool bPressed)
			{
				this->bPressed = bPressed;
			}

			inline bool GetPressed() const
			{
				return this->bPressed;
			}

			virtual EControlType GetType() const;
		};

		class CToggle : public CControl
		{
		private:
			bool bOn;
			CTexture *pOnTexture;
			CTexture *pOffTexture;

		public:
			CToggle(CUnit &Unit, const char *lpName, bool bOn);
			virtual ~CToggle();

			inline void SetOn(bool bOn)
			{
				this->bOn = bOn;
			}

			inline bool GetOn() const
			{
				return this->bOn;
			}

			inline void SetOnTexture(CTexture *pOnTexture)
			{
				this->pOnTexture = pOnTexture;

				if(this->pOnTexture != 0 && this->Size.X == 0 && this->Size.Y == 0)
				{
					this->Size.X = this->pOnTexture->GetWidth();
					this->Size.Y = this->pOnTexture->GetHeight();
				}
			}

			inline CTexture *GetOnTexture() const
			{
				return this->pOnTexture;
			}

			inline void SetOffTexture(CTexture *pOffTexture)
			{
				this->pOffTexture = pOffTexture;
			}

			inline CTexture *GetOffTexture() const
			{
				return this->pOffTexture;
			}

			virtual EControlType GetType() const;

		protected:
			virtual void RenderInternal();
		};

		class CVerticalSlider : public CControl
		{
		private:
			float fMin;
			float fMax;
			float fValue;

			float fMinOffset;
			float fMaxOffset;

		public:
			CVerticalSlider(CUnit &Unit, const char *lpName, float fMin = -1.0f, float fMax = 1.0f, float fValue = 0.0f, float fMinOffset = -1.0f, float fMaxOffset = 1.0f);
			virtual ~CVerticalSlider();

			inline void SetMin(float fMin)
			{
				this->fMin = fMin;
				if(this->fValue < this->fMin)
				{
					this->fValue = this->fMin;
				}
			}

			inline float GetMin() const
			{
				return this->fMin;
			}

			inline void SetMax(float fMax)
			{
				this->fMax = fMax;
				if(this->fValue > this->fMax)
				{
					this->fValue = this->fMax;
				}
			}

			inline float GetMax() const
			{
				return this->fMax;
			}

			inline void SetValue(float fValue)
			{
				if(fValue < this->fMin)
				{
					fValue = this->fMin;
				}
				else if(fValue > this->fMax)
				{
					fValue = this->fMax;
				}
				this->fValue = fValue;
			}

			inline float GetValue() const
			{
				return this->fValue;
			}

			inline float GetValueInverse() const
			{
				return this->fMax + this->fMin - this->fValue;
			}

			inline void SetMinOffset(float fMinOffset)
			{
				this->fMinOffset = fMinOffset;
			}

			inline float GetMinOffset() const
			{
				return this->fMinOffset;
			}

			inline void SetMaxOffset(float fMaxOffset)
			{
				this->fMaxOffset = fMaxOffset;
			}

			inline float GetMaxOffset() const
			{
				return this->fMaxOffset;
			}

			virtual EControlType GetType() const;

		protected:
			virtual void RenderInternal();
		};
	}
}
