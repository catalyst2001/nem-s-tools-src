/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"

namespace VAmp
{
	namespace DSP
	{
		class CFFTBuffer
		{
		protected:
			int iSegment;
			unsigned int uiSegmentSamples;

			float *lpWeights;

			unsigned int uiSegmentIndex;
			float *lpSegments[2];

			float *lpFFTIn[2];
			float *lpFFTOut[2];

			float *lpWindow;

			unsigned int uiBufferIndex;
			float *lpBuffer;

		public:
			CFFTBuffer(unsigned int uiSegmentSamples);
			virtual ~CFFTBuffer();

			inline unsigned int operator()() const
			{
				return this->uiSegmentSamples;
			}

			inline float &operator[](unsigned int uiIndex)
			{
				assert(uiIndex < this->uiSegmentSamples);
				return this->lpWeights[uiIndex];
			}

			inline float operator[](unsigned int uiIndex) const
			{
				assert(uiIndex < this->uiSegmentSamples);
				return this->lpWeights[uiIndex];
			}

			inline unsigned int GetSamples() const
			{
				return this->uiSegmentSamples;
			}

			inline float *GetWeights() const
			{
				return this->lpWeights;
			}

			void Advance(bool bApplyFilter, unsigned int uiSamples, float *lpSamples);

			void Clear();

		protected:
			virtual void Filter(int iSegment, unsigned int uiBufferIndex);

			void PrepareFFTBuffer(unsigned int uiBufferIndex);
			void FilterFFTBuffer(int iSegment);
		};
	}
}
