/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Configuration.h"
#include "Engine.h"
#include "Interpolate.h"
#include "Cable.h"
#include "Unit.h"

using namespace VAmp;
using namespace VAmp::Units;

CCable::CCable(CEngine &Engine) : bLoaded(false), Engine(Engine), Head(0, 0), Tail(64, 0), pHead(0), pShell(0), pInput(0), pOutput(0)
{

}

CCable::~CCable()
{
	if(this->pInput != 0)
	{
		this->pInput->SetOutput(0);
	}
}

void CCable::SetInput(CUnit *pInput)
{
	if(this->pInput != 0)
	{
		this->pInput->SetOutput(0);
	}

	this->pInput = pInput;

	if(this->pInput != 0)
	{
		this->pInput->SetOutput(this);
	}
	if(this->pOutput != 0)
	{
		this->pOutput->SetInput(this);
	}
	this->Update(true);
}

void CCable::SetOutput(CUnit *pOutput)
{
	if(this->pOutput != 0)
	{
		this->pOutput->SetInput(0);
	}

	this->pOutput = pOutput;

	if(this->pInput != 0)
	{
		this->pInput->SetOutput(this);
	}
	if(this->pOutput != 0)
	{
		this->pOutput->SetInput(this);
	}
	this->Update(true);
}

void CCable::Update(bool bClampToUnits)
{
	if(bClampToUnits)
	{
		if(this->pInput != 0)
		{
			this->Head = this->pInput->GetPosition() + this->pInput->GetOutputJack();
		}
		if(this->pOutput != 0)
		{
			this->Tail = this->pOutput->GetPosition() + this->pOutput->GetInputJack();
		}
	}

	CVector Head = this->Head, Tail = this->Tail;
	if(this->pShell != 0)
	{
		Head.X += this->pShell->GetWidth();
		Tail.X -= this->pShell->GetWidth();
	}

	switch(Configuration.GetCableInterp())
	{
		case CABLE_INTERP_LINEAR:
		{
			CInterpolate::Linear(Head, Tail, BEZIER_CURVE_NODES, this->lpNodes);
			break;
		}
		case CABLE_INTERP_BEZIER:
		{
			// Bezier
			int iDistance = abs(Tail.X - Head.X) / 2;
			if(iDistance < 32)
				iDistance = 32;
			if(iDistance > 256)
				iDistance = 256;

			CInterpolate::Bezier(Head, Tail, CVector(iDistance, 0), CVector(iDistance, 0), BEZIER_CURVE_NODES, this->lpNodes);
			break;
		}
		case CABLE_INTERP_COMPLEX_BEZIER:
		{
			int iWidth = (Head.X - Tail.X) / 2;
			int iDistance = abs(iWidth);
			if(iDistance < 32)
				iDistance = 32;
			if(iDistance > 128)
				iDistance = 128;
			CVector Mid = (Head + Tail) / 2;

			CInterpolate::Bezier(Head, Mid, CVector(iDistance, 0), CVector(-iDistance - iWidth, 0), BEZIER_CURVE_NODES / 2, this->lpNodes);
			CInterpolate::Bezier(Mid, Tail, CVector(-iDistance - iWidth, 0), CVector(iDistance, 0), BEZIER_CURVE_NODES / 2, this->lpNodes + BEZIER_CURVE_NODES / 2);
			break;
		}
	}

	CVector Last = CVector(0, CABLE_WIDTH);
	for(unsigned int i = 0; i < BEZIER_CURVE_NODES; i++)
	{
		if(i == 0 || i == BEZIER_CURVE_NODES - 1)
		{
			this->lpQuads[i * 2 + 0] = this->lpNodes[i] + CVector(0, CABLE_WIDTH);
			this->lpQuads[i * 2 + 1] = this->lpNodes[i] + CVector(0, -CABLE_WIDTH);
		}
		else
		{
			CVector A = this->lpNodes[i] - this->lpNodes[i - 1];
			CVector B = this->lpNodes[i + 1] - this->lpNodes[i];
			CVector Cross;
			float fX = (float)(A.Y + B.Y) * -0.5f;
			float fY = (float)(A.X + B.X) * 0.5f;
			float fLength = sqrtf(fX * fX + fY * fY);
			if(fLength == 0.0f)
			{
				Cross = Last;
			}
			else
			{
				float fTemp = float(CABLE_WIDTH) / fLength;
				Cross = CVector((int)froundf(fX * fTemp), (int)froundf(fY * fTemp));
				Last = Cross;
			}
			
			this->lpQuads[i * 2 + 0] = this->lpNodes[i] + Cross;
			this->lpQuads[i * 2 + 1] = this->lpNodes[i] - Cross;
		}
	}
}

bool CCable::Load()
{
	this->pHead = this->Engine.LoadTexture("units/cable head.png");
	this->pShell = this->Engine.LoadTexture("units/cable shell.png");
	return true;
}

void CCable::Unload()
{
	this->Engine.UnloadTexture(this->pHead);
	this->pHead = 0;

	this->Engine.UnloadTexture(this->pShell);
	this->pShell = 0;
}

bool CCable::IntersectsMouse(CVector MousePosition, bool &bHead) const
{
	CVector Head = this->Head - MousePosition;
	CVector Tail = this->Tail - MousePosition;

	if(this->pShell == 0)
	{
		if(Head.GetLength() <= CABLE_RADIUS)
		{
			bHead = true;
			return true;
		}

		if(Tail.GetLength() <= CABLE_RADIUS)
		{
			bHead = false;
			return true;
		}
	}
	else
	{
		Head += CVector(this->pShell->GetWidth(), this->pShell->GetHeight() / 2);
		if(this->pShell->GetRectangle().Intersects(Head))
		{
			bHead = true;
			return true;
		}

		Tail += CVector(0, this->pShell->GetHeight() / 2);
		if(this->pShell->GetRectangle().Intersects(Tail))
		{
			bHead = false;
			return true;
		}
	}

	return false;
}

void CCable::Render()
{
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glColor3ub(11, 11, 13);
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(2, GL_INT, sizeof(CVector), this->lpQuads);
	glDrawArrays(GL_QUAD_STRIP, 0, BEZIER_CURVE_NODES * 2);
	//glDrawArrays(GL_POINTS, 0, BEZIER_CURVE_NODES);
	glDisableClientState(GL_VERTEX_ARRAY);
	glColor3ub(255, 255, 255);
	//glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	if(this->pShell != 0)
	{
		CVector ShellSize = CVector(this->pShell->GetWidth(), this->pShell->GetHeight());

		if(this->pHead != 0)
		{
			CVector HeadSize = CVector(this->pHead->GetWidth(), this->pHead->GetHeight());

			this->pHead->Bind();

			if(this->pInput == 0 || this->Head != this->pInput->GetPosition() + this->pInput->GetOutputJack())
			{
				glBegin(GL_QUADS);
				glTexCoord2i(1, 0);
				glVertex2i(this->Head.X - ShellSize.X, this->Head.Y - HeadSize.Y / 2);
				glTexCoord2i(1, 1);
				glVertex2i(this->Head.X - ShellSize.X, this->Head.Y + HeadSize.Y / 2);
				glTexCoord2i(0, 1);
				glVertex2i(this->Head.X - ShellSize.X + HeadSize.X, this->Head.Y + HeadSize.Y / 2);
				glTexCoord2i(0, 0);
				glVertex2i(this->Head.X - ShellSize.X + HeadSize.X, this->Head.Y - HeadSize.Y / 2);
				glEnd();
			}

			if(this->pOutput == 0 || this->Tail != this->pOutput->GetPosition() + this->pOutput->GetInputJack())
			{
				glBegin(GL_QUADS);
				glTexCoord2i(0, 0);
				glVertex2i(this->Tail.X + ShellSize.X - HeadSize.X, this->Tail.Y - HeadSize.Y / 2);
				glTexCoord2i(0, 1);
				glVertex2i(this->Tail.X + ShellSize.X - HeadSize.X, this->Tail.Y + HeadSize.Y / 2);
				glTexCoord2i(1, 1);
				glVertex2i(this->Tail.X + ShellSize.X, this->Tail.Y + HeadSize.Y / 2);
				glTexCoord2i(1, 0);
				glVertex2i(this->Tail.X + ShellSize.X, this->Tail.Y - HeadSize.Y / 2);
				glEnd();
			}

			this->pHead->Unbind();
		}

		this->pShell->Bind();

		glBegin(GL_QUADS);
		glTexCoord2i(0, 0);
		glVertex2i(this->Tail.X - ShellSize.X, this->Tail.Y - ShellSize.Y / 2);
		glTexCoord2i(0, 1);
		glVertex2i(this->Tail.X - ShellSize.X, this->Tail.Y + ShellSize.Y / 2);
		glTexCoord2i(1, 1);
		glVertex2i(this->Tail.X, this->Tail.Y + ShellSize.Y / 2);
		glTexCoord2i(1, 0);
		glVertex2i(this->Tail.X, this->Tail.Y - ShellSize.Y / 2);
		glEnd();

		glBegin(GL_QUADS);
		glTexCoord2i(0, 0);
		glVertex2i(this->Head.X, this->Head.Y - ShellSize.Y / 2);
		glTexCoord2i(0, 1);
		glVertex2i(this->Head.X, this->Head.Y + ShellSize.Y / 2);
		glTexCoord2i(1, 1);
		glVertex2i(this->Head.X + ShellSize.X, this->Head.Y + ShellSize.Y / 2);
		glTexCoord2i(1, 0);
		glVertex2i(this->Head.X + ShellSize.X, this->Head.Y - ShellSize.Y / 2);
		glEnd();

		this->pShell->Unbind();
	}
}
