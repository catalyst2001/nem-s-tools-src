/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "Texture.h"
#include "Vector.h"

#define BEZIER_CURVE_NODES 50
#define CABLE_WIDTH 4
#define CABLE_RADIUS 12

namespace VAmp
{
	class CEngine;

	namespace Units
	{
		class CUnit;

		class CCable
		{
		private:
			bool bLoaded;
			CEngine &Engine;

			CVector Head;
			CVector Tail;

			CVector lpNodes[BEZIER_CURVE_NODES];
			CVector lpQuads[BEZIER_CURVE_NODES * 2];
			CTexture *pHead;
			CTexture *pShell;

			CUnit *pInput;
			CUnit *pOutput;

		public:
			CCable(CEngine &Engine);
			~CCable();

			inline void SetHead(const CVector &Head)
			{
				this->Head = Head;
			}

			inline const CVector &GetHead() const
			{
				return this->Head;
			}

			inline void SetTail(const CVector &Tail)
			{
				this->Tail = Tail;
			}

			inline const CVector &GetTail() const
			{
				return this->Tail;
			}

			void SetInput(CUnit *pInput);

			inline CUnit *GetInput() const
			{
				return this->pInput;
			}

			void SetOutput(CUnit *pOutput);

			inline CUnit *GetOutput() const
			{
				return this->pOutput;
			}

			void Update(bool bClampToUnits);

			inline bool IsLoaded() const
			{
				return this->bLoaded;
			}

			bool Load();
			void Unload();

			bool IntersectsMouse(CVector MousePosition, bool &bHead) const;

			void Render();
		};
	}
}
