/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "Color.h"
#include "Rectangle.h"
#include "Texture.h"
#include "Vector.h"

#define FONT_CHAR_COUNT 128

namespace VAmp
{
	class CEngine;

	enum EFontAlign
	{
		FONT_ALIGN_LEFT = 0x00,
		FONT_ALIGN_CENTER = 0x01,
		FONT_ALIGN_RIGHT = 0x02,
		FONT_ALIGN_TOP = 0x00,
		FONT_ALIGN_MIDDLE = 0x04,
		FONT_ALIGN_BOTTOM = 0x08
	};

	class CFont
	{
		friend CEngine;

	private:
		char *lpName;
		CVector Size;
		CVector Spacing;
		char lpAlphabet[FONT_CHAR_COUNT];
		CTexture &Texture;

		unsigned int uiReferences;

	public:
		CFont(const char *lpName, const CVector &Size, const CVector &Spacing, const char *lpAlphabet, CTexture &Texture);
		~CFont();

		inline const char *GetName() const
		{
			return this->lpName;
		}

		CVector GetSize(const char *lpString) const;

		void Render(unsigned int uiFontAlign, const CRectangle &Rectangle, const CColor &Color, const char *lpString);

		void Render(const CVector &Position, const CColor &Color, const char *lpString);
	};
}
