/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Interpolate.h"

using namespace VAmp;

void CInterpolate::Linear(const CVector &A, const CVector &B, unsigned int uiCount, CVector *lpNodes)
{
	for(unsigned int i = 0; i < uiCount; i++)
	{
		lpNodes[i] = A + (B - A) * i / (uiCount - 1);
	}
}

// A0+B0  -^^-
// |     -    -   A1-B1
// |   -/      \  |
// | -/         \ |
// |/            \A1
// A0
void CInterpolate::Bezier(const CVector &A0, const CVector &A1, const CVector &B0, const CVector &B1, unsigned int uiCount, CVector *lpNodes)
{
	for(unsigned int i = 0; i < uiCount; i++)
	{
		float fT1 = (float)i / (float)(uiCount - 1);
		float fT2 = fT1 * fT1;
		float fT3 = fT2 * fT1;
		lpNodes[i].X = (int)froundf((float)(2 * (A0.X - A1.X) + 3 * (B0.X + B1.X)) * fT3 + (float)(3 * (A1.X - A0.X) - 3 * (B1.X + 2 * B0.X)) * fT2 + (float)(3 * B0.X) * fT1 + A0.X);
		lpNodes[i].Y = (int)froundf((float)(2 * (A0.Y - A1.Y) + 3 * (B0.Y + B1.Y)) * fT3 + (float)(3 * (A1.Y - A0.Y) - 3 * (B1.Y + 2 * B0.Y)) * fT2 + (float)(3 * B0.Y) * fT1 + A0.Y);
	}
}
