/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "Control.h"
#include "Variable.h"

namespace VAmp
{
	class CEngine;

	namespace Units
	{
		class CCable;

		enum EUnitType
		{
			UNIT_TYPE_AUTOMATIC_WAH,
			UNIT_TYPE_BOOST,
#ifdef _DEBUG
			UNIT_TYPE_CHAOS,
#endif
			UNIT_TYPE_CHORUS,
			UNIT_TYPE_COMPRESSOR,
			UNIT_TYPE_DELAY,
			UNIT_TYPE_DISTORTION,
			UNIT_TYPE_ENVELOPE_FILTER,
			UNIT_TYPE_EQUALIZER,
			UNIT_TYPE_FADER,
			UNIT_TYPE_FEEDBACK_LOOP,
			UNIT_TYPE_FFT_SPECTRUM,
			UNIT_TYPE_FLANGER,
			UNIT_TYPE_FUZZ,
			UNIT_TYPE_LOOP_STATION,
			UNIT_TYPE_METRONOME,
			UNIT_TYPE_NOISE_GATE,
			UNIT_TYPE_OCTAVE,
			UNIT_TYPE_OSCILLOSCOPE,
			UNIT_TYPE_OVERDRIVE,
			UNIT_TYPE_PARALLEL_FEEDBACK_LOOP,
			UNIT_TYPE_PHASE_SHIFTER,
			UNIT_TYPE_PLAYER,
			UNIT_TYPE_PREAMP,
			UNIT_TYPE_RECORDER,
			UNIT_TYPE_REVERB,
			UNIT_TYPE_RING_MODULATOR,
			UNIT_TYPE_SPEAKER_CABINET,
			UNIT_TYPE_TREMOLO,
			UNIT_TYPE_VIBRATO,
			UNIT_TYPE_COUNT
		};

		enum ECategory
		{
			CATEGORY_DELAY,
			CATEGORY_DISTORTION,
			CATEGORY_ESSENTIAL,
			CATEGORY_FILTER,
			CATEGORY_MODULATION,
			CATEGORY_OTHER,
			CATEGORY_PITCH_SHIFT,
			CATEGORY_PLAYBACK,
			CATEGORY_COUNT
		};

		class CUnit
		{
			friend CCable;

		public:
			class CUnitInfo
			{
			public:
				virtual EUnitType GetType() const = 0;

				virtual const char *GetName() const = 0;

				virtual ECategory GetCategory() const = 0;

				virtual CUnit *Create(CEngine &Engine) const = 0;

				bool IsPreamp() const
				{
					switch(this->GetType())
					{
						case UNIT_TYPE_PREAMP:
							return true;
						default:
							return false;
					}
				}

				bool IsSpeakerCabinet() const
				{
					switch(this->GetType())
					{
						case UNIT_TYPE_SPEAKER_CABINET:
							return true;
						default:
							return false;
					}
				}
			};

			const CUnitInfo &Info;

		protected:
			bool bLoaded;
			CEngine &Engine;
			CVector Position;
			CVector Size;

			CVector InputJack;
			CVector OutputJack;

			CCable *pInput;
			CCable *pOutput;

			bool bRequiresRender;
			int iShortcut;

			typedef std::list<CControl *> CControlList;
			CControlList Controls;

			typedef std::list<CVariable *> CVariableList;
			CVariableList Variables;

		public:
			CUnit(const CUnitInfo &Info, CEngine &Engine);
			virtual ~CUnit();

			CEngine &GetEngine()
			{
				return this->Engine;
			}

			inline void SetPosition(const CVector &Position)
			{
				this->Position = Position;
			}

			inline const CVector &GetPosition() const
			{
				return this->Position;
			}

			inline const CVector &GetSize() const
			{
				return this->Size;
			}

			inline const CVector &GetInputJack() const
			{
				return this->InputJack;
			}

			inline const CVector &GetOutputJack() const
			{
				return this->OutputJack;
			}

			inline bool IsLoaded() const
			{
				return this->bLoaded;
			}

			bool Load();
			void Unload();

			inline CCable *GetInput() const
			{
				return this->pInput;
			}

			inline CCable *GetOutput() const
			{
				return this->pOutput;
			}

			inline void SetShortcut(int iShortcut)
			{
				this->iShortcut = iShortcut;
			}

			inline int GetShortcut() const
			{
				return this->iShortcut;
			}

			inline void SetRequiresRender(bool bRequiresRender)
			{
				this->bRequiresRender = bRequiresRender;
			}

			inline bool GetRequiresRender() const
			{
				return this->bRequiresRender;
			}

			unsigned int GetControlCount() const;
			CControl *GetControl(unsigned int uiIndex) const;
			CControl *GetControl(const char *lpName) const;
			CControl *GetControl(CVector MousePosition) const;

			unsigned int GetVariableCount() const;
			CVariable *GetVariable(unsigned int uiIndex) const;
			CVariable *GetVariable(const char *lpName) const;

			void Render();

			void Process(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer);

			static const CUnitInfo *GetUnitInfo(EUnitType eUnitType);
			static const CUnitInfo *GetUnitInfo(const char *lpName);

			static const char *GetCategoryName(ECategory eCategory);

		protected:
			virtual bool LoadInternal() = 0;
			virtual void UnloadInternal() = 0;

			inline void SetInput(CCable *pInput)
			{
				this->pInput = pInput;
			}

			inline void SetOutput(CCable *pOutput)
			{
				this->pOutput = pOutput;
			}

			virtual void RenderInternal();

			virtual void ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer) = 0;
		};
	}
}

#define REGISTER_UNIT(INFOCLASSNAME, CLASSNAME, NAME, TYPENAME, UNIT, CATEGORY) \
	public: \
		class INFOCLASSNAME : public CUnit::CUnitInfo \
		{ \
		public: \
			virtual EUnitType GetType() const \
			{ \
				return TYPENAME; \
			} \
			\
			virtual const char *GetName() const \
			{ \
				return UNIT; \
			} \
			\
			virtual ECategory GetCategory() const \
			{ \
				return CATEGORY; \
			} \
			\
			virtual CUnit *Create(CEngine &Engine) const \
			{ \
				return new CLASSNAME(Engine); \
			} \
		}; \
		\
		static const INFOCLASSNAME NAME

#define LINK_UNIT(INFOCLASSNAME, CLASSNAME, NAME) const CLASSNAME::INFOCLASSNAME CLASSNAME::NAME = CLASSNAME::INFOCLASSNAME()
