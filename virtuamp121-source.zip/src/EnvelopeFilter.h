/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "FFTBuffer.h"
#include "Unit.h"

namespace VAmp
{
	namespace Units
	{
		class CEnvelopeFilter : public CUnit
		{
			REGISTER_UNIT(CEnvelopeFilterInfo, CEnvelopeFilter, EnvelopeFilterInfo, UNIT_TYPE_ENVELOPE_FILTER, "Envelope Filter", CATEGORY_FILTER);

		private:
			CSprite *pPower;
			CKnob *pSensitivity;
			CKnob *pDecay;
			CKnob *pPeak;
			CKnob *pMode;
			CToggle *pBoost;
			CToggle *pUp;
			CStomp *pStomp;

		public:
			CEnvelopeFilter(CEngine &Engine);
			virtual ~CEnvelopeFilter();

		protected:
			virtual bool LoadInternal();
			virtual void UnloadInternal();

			virtual void RenderInternal();

			virtual void ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer);

		private:
			class CEnvelopeFilterBuffer : public DSP::CFFTBuffer
			{
			public:
				float fEnvelopeLower;
				float fEnvelopeUpper;

				bool bBoost;
				float fSensitivity;
				float fDecay;
				float fPeak;
				enum EFilterMode
				{
					FILTER_MODE_LOW_PASS,
					FILTER_MODE_HIGH_PASS,
					FILTER_MODE_BAND_PASS,
					FILTER_MODE_COUNT
				} eFilterMode;

				enum EFilterDirection
				{
					FILTER_DIRECTION_UP,
					FILTER_DIRECTION_DOWN,
					FILTER_DIRECTION_COUNT
				} eFilterDirection;

				unsigned int uiSamplesPerSecond;

			public:
				CEnvelopeFilterBuffer(unsigned int uiSegmentSamples) : CFFTBuffer(uiSegmentSamples), fEnvelopeLower(0.0f), fEnvelopeUpper(0.0f), bBoost(false), fSensitivity(0.0f), fDecay(0.0f), fPeak(0.0f), eFilterMode(FILTER_MODE_LOW_PASS), eFilterDirection(FILTER_DIRECTION_UP), uiSamplesPerSecond(0)
				{

				}

				virtual ~CEnvelopeFilterBuffer()
				{

				}

			protected:
				virtual void Filter(int iSegment, unsigned int uiBufferIndex);
			} Buffer;
		};
	}
}
