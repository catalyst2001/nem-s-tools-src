/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Equalizer.h"

using namespace VAmp;
using namespace VAmp::Units;

int CEqualizer::lpBandFrequencies[] = { 100, 200, 400, 800, 1600, 3200, 6400 };

LINK_UNIT(CEqualizerInfo, CEqualizer, EqualizerInfo);

CEqualizer::CEqualizer(CEngine &Engine) : CUnit(CEqualizer::EqualizerInfo, Engine), pPower(0), pLevel(0), pStomp(0), Buffer(512)
{
	for(unsigned int i = 0; i < EQUALIZER_SLIDERS; i++)
	{
		lpBands[i] = 0;
	}
}

CEqualizer::~CEqualizer()
{
	this->Unload();
}

bool CEqualizer::LoadInternal()
{
	this->Size = CVector(152, 248);

	unsigned int i;

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/equalizer.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pLevel = new CVerticalSlider(*this, "Level", -20.0f, 20.0f, 0.0f, 22.0f, -22.0f);
	this->pLevel->SetPosition(CVector(16, 48));
	this->pLevel->SetTexture(this->Engine.LoadTexture("units/slider.png"));
	this->Controls.push_back(this->pLevel);

	for(i = 0; i < EQUALIZER_SLIDERS; i++)
	{
		char lpBand[64];
		sprintf(lpBand, "Band %d", lpBandFrequencies[i]);
		this->lpBands[i] = new CVerticalSlider(*this, lpBand, -20.0f, 20.0f, 0.0f, 22.0f, -22.0f);
		this->lpBands[i]->SetPosition(CVector(32 + i * 16, 48));
		this->lpBands[i]->SetTexture(this->Engine.LoadTexture("units/slider.png"));
		this->Controls.push_back(this->lpBands[i]);
	}

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	for(i = 0; i < EQUALIZER_SLIDERS; i++)
	{
		this->lpLevels[i] = 1.0f;
	}

	return true;
}

void CEqualizer::UnloadInternal()
{
	this->pPower = 0;
	this->pLevel = 0;
	for(unsigned int i = 0; i < EQUALIZER_SLIDERS; i++)
	{
		lpBands[i] = 0;
	}
	this->pStomp = 0;
}

void CEqualizer::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

float CEqualizer::Interpolate(float fMinHz, float fMaxHz)
{
	float fAvgHz = (fMinHz + fMaxHz) * 0.5f;
	if(fAvgHz < (float)this->lpBandFrequencies[0])
		return this->lpLevels[0];

	if(fAvgHz > (float)this->lpBandFrequencies[EQUALIZER_SLIDERS- 1])
		return this->lpLevels[EQUALIZER_SLIDERS - 1];

	int i;
	for(i = EQUALIZER_SLIDERS - 2; i >= 0; i--)
	{
		if(fAvgHz > (float)this->lpBandFrequencies[i])
		{
			break;
		}
	}

	float fS1 = this->lpLevels[i];
	float fS2 = this->lpLevels[i + 1];

	if(fS1 == fS2)
	{
		return fS1;
	}

	float fS0 = i > 0 ? this->lpLevels[i - 1] : fS1;
	float fS3 = i < EQUALIZER_SLIDERS - 2 ? this->lpLevels[i + 2] : fS2;

	float fInt = ((float)this->lpBandFrequencies[i + 1] - fAvgHz) / ((float)this->lpBandFrequencies[i + 1] - (float)this->lpBandFrequencies[i]);
	float fInt2 = fInt * fInt;

	float fA0 = fS3 - fS2 - fS0 + fS1;
	float fA1 = fS0 - fS1 - fA0;
	float fA2 = fS2 - fS0;

	return fA0 * fInt * fInt2 + fA1 * fInt2 + fA2 * fInt + fS1;
}

void CEqualizer::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		this->Buffer.Advance(false, uiSamples, lpData);
		return;
	}

	unsigned int i;

	float fLevel = powf(10.0f, this->pLevel->GetValue() / 20.0f);

	bool bEqualize = false;
	bool bCalculateWeights = false;
	float lpLevels[EQUALIZER_SLIDERS];
	for(i = 0; i < EQUALIZER_SLIDERS; i++)
	{
		lpLevels[i] = powf(10.0f, this->lpBands[i]->GetValue() / 20.0f);

		bEqualize = bEqualize || lpLevels[i] != 1.0f;
		bCalculateWeights = bCalculateWeights || lpLevels[i] != this->lpLevels[i];
	}

	// Look back a third of a second.
	if(bEqualize)
	{
		if(bCalculateWeights)
		{
			memcpy(this->lpLevels, lpLevels, sizeof(float) * EQUALIZER_SLIDERS);

			unsigned int uiSegmentSamplesOverTwo = this->Buffer() / 2;
			float fBinHz = (float)uiSamplesPerSecond / (float)uiSegmentSamplesOverTwo;
			float fHz = fBinHz * 0.5f;
			this->Buffer[0] = this->Interpolate(0.0f, fBinHz);
			for(i = 1; i < uiSegmentSamplesOverTwo; i++)
			{
				float f = this->Interpolate(fHz, fHz + fBinHz);
				this->Buffer[i] = f;
				fHz += fBinHz;
			}

			bCalculateWeights = false;
		}

		this->Buffer.Advance(true, uiSamples, lpData);
	}
	else 
	{
		this->Buffer.Advance(false, uiSamples, lpData);
	}

	if(fLevel != 1.0f)
	{
		for(i = 0; i < uiSamples; i++)
		{
			lpData[i] *= fLevel;
		}
	}

	//fNormalizer *= fLevel;
}
