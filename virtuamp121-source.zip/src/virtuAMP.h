/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "resource.h"

#define ID_ADD_UNIT_BASE 34000
#define ID_ADD_CATEGORY_BASE 35000
#define ID_AUDIO_DRIVER_BASE 36000
#define ID_AUDIO_BUFFER_DENOMINATOR_BASE 37000
#define ID_AUDIO_BUFFER_FPS_BASE 38000

bool GetFileExists(const char *lpFileName);

void GetFullFileName(const char *lpFileName, char *lpFullFileName, int iFullFileNameSize);

enum EFileDialogType
{
	FILE_DIALOG_OPEN = 0,
	FILE_DIALOG_SAVE
};

bool ShowFileDialog(int iType, const char *lpTitle, const char *lpFilter, const char *lpDefaultExtension, char *lpFileName, unsigned int uiFileNameSize);

enum EStatusBarPanel
{
	STATUSBAR_PANEL_SELECTION = 0,
	STATUSBAR_PANEL_SHORTCUT,
	STATUSBAR_PANEL_ERROR
};

void SetStatusBarText(EStatusBarPanel eStatusBarPanel, LPCTSTR lpText);
