/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Font.h"

using namespace VAmp;

CFont::CFont(const char *lpName, const CVector &Size, const CVector &Spacing, const char *lpAlphabet, CTexture &Texture) : Size(Size), Spacing(Spacing), Texture(Texture)
{
	this->lpName = new char[strlen(lpName) + 1];
	strcpy(this->lpName, lpName);

	memcpy(this->lpAlphabet, lpAlphabet, sizeof(this->lpAlphabet));
}

CFont::~CFont()
{
	delete []this->lpName;
}

CVector CFont::GetSize(const char *lpString) const
{
	if(*lpString == '\0')
	{
		return CVector::Null;
	}

	int iX = 0;
	CVector Size(0, this->Size.Y);
	for(; *lpString; lpString++)
	{
		if(*lpString == '\n')
		{
			if(iX > Size.X)
			{
				Size.X = iX;
			}
			Size.Y += this->Size.Y + this->Spacing.X;

			iX = 0;
		}
		else if(*lpString > 0 && this->lpAlphabet[*lpString] != -1)
		{
			if(iX > 0)
			{
				iX += this->Spacing.X;
			}
			iX += this->Size.X;
		}
	}

	if(iX > Size.X)
	{
		Size.X = iX;
	}

	return Size;
}

void CFont::Render(unsigned int uiFontAlign, const CRectangle &Rectangle, const CColor &Color, const char *lpString)
{
	CVector Position;
	CVector Size = this->GetSize(lpString);

	if(uiFontAlign & FONT_ALIGN_RIGHT)
	{
		Position.X = Rectangle.Right - Size.X;
	}
	else if(uiFontAlign & FONT_ALIGN_CENTER)
	{
		Position.X = (Rectangle.Right + Rectangle.Left) / 2 - Size.X / 2;
	}
	else
	{
		Position.X = Rectangle.Left;
	}

	if(uiFontAlign & FONT_ALIGN_BOTTOM)
	{
		Position.Y = Rectangle.Bottom - Size.Y;
	}
	else if(uiFontAlign & FONT_ALIGN_MIDDLE)
	{
		Position.Y = (Rectangle.Top + Rectangle.Bottom) / 2 - Size.Y / 2;
	}
	else
	{
		Position.Y = Rectangle.Top;
	}

	this->Render(Position, Color, lpString);
}

void CFont::Render(const CVector &Position, const CColor &Color, const char *lpString)
{
	if(*lpString == '\0')
	{
		return;
	}

	CVector CurrentPosition = Position;

	float fYEnd = (float)this->Size.Y / (float)this->Texture.GetHeight();
	float fOneOverWidth = 1.0f / (float)this->Texture.GetWidth();

	this->Texture.Bind();
	glColor4ub(Color.R, Color.G, Color.B, Color.A);
	for(; *lpString; lpString++)
	{
		if(*lpString == '\n')
		{
			CurrentPosition.X = Position.X;
			CurrentPosition.Y += this->Size.Y + this->Spacing.Y;
		}
		else if(*lpString > 0 && this->lpAlphabet[*lpString] != -1)
		{
			int iXStart = (int)this->lpAlphabet[*lpString] * this->Size.X;
			int iXEnd = ((int)this->lpAlphabet[*lpString] + 1) * this->Size.X - 1;

			float fXStart = (float)iXStart * fOneOverWidth;
			float fXEnd = (float)iXEnd * fOneOverWidth;

			if(CurrentPosition.X > Position.X)
			{
				CurrentPosition.X += this->Spacing.X;
			}

			glBegin(GL_POLYGON);
			glTexCoord2f(fXStart, 0.0f);
			glVertex2i(CurrentPosition.X, CurrentPosition.Y);
			glTexCoord2f(fXEnd, 0.0f);
			glVertex2i(CurrentPosition.X + this->Size.X, CurrentPosition.Y);
			glTexCoord2f(fXEnd, fYEnd);
			glVertex2i(CurrentPosition.X + this->Size.X, CurrentPosition.Y + this->Size.Y);
			glTexCoord2f(fXStart, fYEnd);
			glVertex2i(CurrentPosition.X, CurrentPosition.Y + this->Size.Y);
			glEnd();

			CurrentPosition.X += this->Size.X;
		}
	}
	glColor4ub(255, 255, 255, 255);
	this->Texture.Unbind();
}
