/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"

namespace VAmp
{
	class CColor
	{
	public:
		static const CColor Black;
		static const CColor White;
		static const CColor Red;
		static const CColor Green;
		static const CColor Blue;

	public:
		union
		{
			struct
			{
				unsigned char R;
				unsigned char G;
				unsigned char B;
				unsigned char A;
			};
			unsigned char Components[4];
		};

	public:
		inline CColor()
		{

		}

		inline CColor(unsigned char iR, unsigned char iG, unsigned char iB, unsigned char iA) : R(iR), G(iG), B(iB), A(iA)
		{

		}

		inline CColor(const unsigned char *lpComponents) : R(lpComponents[0]), G(lpComponents[1]), B(lpComponents[2]), A(lpComponents[3])
		{

		}

		inline CColor(const CColor &Color) : R(Color.R), G(Color.G), B(Color.B), A(Color.A)
		{

		}

		inline unsigned char &operator[](int iIndex)
		{
			assert(iIndex >= 0 && iIndex < 1);

			return this->Components[iIndex];
		}

		inline unsigned char operator[](int iIndex) const
		{
			assert(iIndex >= 0 && iIndex < 1);

			return this->Components[iIndex];
		}

		inline bool operator==(const CColor &Color) const
		{
			return this->R == Color.R && this->G == Color.G && this->B == Color.B && this->A == Color.A;
		}

		inline bool operator!=(const CColor &Color) const
		{
			return this->R != Color.R || this->G != Color.G || this->B != Color.B || this->A != Color.A;
		}
	};
}
