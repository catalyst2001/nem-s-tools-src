/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "virtuAMP.h"
#include "AudioDriver.h"
#include "Configuration.h"
#include "Engine.h"
#include "Log.h"

static HINSTANCE hVAmpInstance;
static HWND hMainWindow;
static HWND hStatusBarWindow;

static char lpFileName[MAX_PATH] = "";

VAmp::Audio::CAudioDriver *pAudio = 0;
VAmp::CEngine Engine = VAmp::CEngine();

unsigned int uiBufferDenominatorCount = 0;
unsigned int lpBufferDenominator[BUFFER_DENOMINATOR_MAX];

const unsigned int uiBufferFPSCount = 7;
const unsigned int lpBufferFPS[] = { 1, 2, 4, 8, 16, 24, 30 };

LPTSTR *CommandLineToArgvA(LPTSTR lpCmdLine, int *pNumArgs);
void SetMainWindowText(LPCTSTR lpFileName);

LRESULT CALLBACK MainProc(HWND, UINT, WPARAM, LPARAM);
#if _MSC_VER <= 1200
BOOL CALLBACK AboutProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
#else
INT_PTR CALLBACK AboutProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
#endif

int APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	hVAmpInstance = hInstance;

	char lpConfigurationFileName[MAX_PATH];
	GetFullFileName("virtuAMP.ini", lpConfigurationFileName, sizeof(lpConfigurationFileName));
	if(GetFileExists(lpConfigurationFileName))
	{
		VAmp::Configuration.Open(lpConfigurationFileName);
	}

	WNDCLASSEX WindowClass;
	WindowClass.cbSize			= sizeof(WNDCLASSEX);
	WindowClass.style			= CS_HREDRAW | CS_VREDRAW;
	WindowClass.lpfnWndProc		= MainProc;
	WindowClass.cbClsExtra		= 0;
	WindowClass.cbWndExtra		= 0;
	WindowClass.hInstance		= hInstance;
	WindowClass.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_VIRTUAMP));
	WindowClass.hCursor			= LoadCursor(NULL, IDC_ARROW);
	WindowClass.hbrBackground	= (HBRUSH)(COLOR_BACKGROUND + 1);
	WindowClass.lpszMenuName	= MAKEINTRESOURCE(IDC_VIRTUAMP);
	WindowClass.lpszClassName	= "VIRTUAMP";
	WindowClass.hIconSm			= LoadIcon(WindowClass.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	if(!RegisterClassEx(&WindowClass))
	{
		return 1;
	}

	hMainWindow = CreateWindow("VIRTUAMP", "virtuAMP", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, VAmp::Configuration.GetWindowPosition().X, VAmp::Configuration.GetWindowPosition().Y, VAmp::Configuration.GetWindowSize().X, VAmp::Configuration.GetWindowSize().Y, NULL, NULL, hInstance, NULL);

	if(hMainWindow == NULL)
	{
		return 1;
	}

	Engine.Lock();
	if(Engine.Initialize(hMainWindow))
	{
		int iNumArgs;
		LPTSTR *lpCmdArgs = CommandLineToArgvA(lpCmdLine, &iNumArgs);

		if(iNumArgs < 1 || !Engine.Open(lpCmdArgs[0]))
		{
#ifdef _DEBUG
			Engine.New(VAmp::NEW_TEMPLATE_TESTING);
#else
			Engine.New();
#endif
		}
		else
		{
			strcpy(lpFileName, lpCmdArgs[0]);
			SetMainWindowText(lpFileName);
		}

		for(int i = 0; i < iNumArgs; i++)
		{
			delete lpCmdArgs[i];
		}
		delete []lpCmdArgs;
	}
	Engine.Unlock();

	ShowWindow(hMainWindow, VAmp::Configuration.GetWindowMaximized() ? SW_SHOWMAXIMIZED : SW_SHOWNORMAL);
	UpdateWindow(hMainWindow);

	pAudio = VAmp::Audio::CAudioDriver::Create(VAmp::Configuration.GetAudioDriver(), hMainWindow, &Engine);
	if(!pAudio->Play(AUDIO_SAMPLES))
	{
		CheckMenuItem(GetMenu(hMainWindow), ID_AUDIO_MUTE, MF_CHECKED);
	}

	HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_VIRTUAMP));

	MSG msg;
	while(GetMessage(&msg, NULL, 0, 0))
	{
		if(!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	VAmp::Configuration.Save(lpConfigurationFileName);

	delete pAudio;

	return (int)msg.wParam;
}

LPTSTR *CommandLineToArgvA(LPTSTR lpCmdLine, int *pNumArgs)
{
	*pNumArgs = 0;
	LPTSTR *lpCmdArgs = NULL;

	for(;;)
	{
		while(*lpCmdLine && isspace(*lpCmdLine))
		{
			lpCmdLine++;
		}

		if(*lpCmdLine == '\0')
		{
			break;
		}

		bool bQuoted = *lpCmdLine == '"';

		if(bQuoted)
		{
			lpCmdLine++;
		}

		LPTSTR lpEnd = lpCmdLine;
		for(; *lpEnd; lpEnd++)
		{
			if(*lpEnd == '"' || (!bQuoted && isspace(*lpEnd)))
			{
				break;
			}
		}

		LPTSTR *lpTemp = new LPTSTR[*pNumArgs + 1];
		memcpy(lpTemp, lpCmdArgs, *pNumArgs * sizeof(LPTSTR));
		delete []lpCmdArgs;
		lpCmdArgs = lpTemp;

		lpCmdArgs[*pNumArgs] = new TCHAR[lpEnd - lpCmdLine + 1];
		memcpy(lpCmdArgs[*pNumArgs], lpCmdLine, lpEnd - lpCmdLine);
		lpCmdArgs[*pNumArgs][lpEnd - lpCmdLine] = '\0';

		(*pNumArgs)++;

		if(*lpEnd == '\0')
		{
			break;
		}

		if(bQuoted || *lpEnd != '"')
		{
			lpEnd++;
		}

		lpCmdLine = lpEnd;
	}

	return lpCmdArgs;
}

void SetMainWindowText(LPCTSTR lpFileName)
{
	if(lpFileName && *lpFileName)
	{
		const char *pTemp = strrchr(lpFileName, '\\');
		if(pTemp != 0 && *pTemp)
		{
			char lpTitle[MAX_PATH];
			strcpy(lpTitle, pTemp + 1);
			strcat(lpTitle, " - virtuAMP");

			SetWindowText(hMainWindow, lpTitle);
			return;
		}
	}
	
	SetWindowText(hMainWindow, "virtuAMP");
}

void SetStatusBarText(EStatusBarPanel eStatusBarPanel, LPCTSTR lpText)
{
	SendMessage(hStatusBarWindow, SB_SETTEXT, (WPARAM)eStatusBarPanel, (LPARAM)lpText);
}

bool GetFileExists(const char *lpFileName)
{
	WIN32_FIND_DATA FindData;
	HANDLE Handle = FindFirstFile(lpFileName, &FindData);

	if(Handle == INVALID_HANDLE_VALUE)
	{
		return false;
	}
	else
	{
		FindClose(Handle);

		return (FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0;
	}
}

void GetFullFileName(const char *lpFileName, char *lpFullFileName, int iFullFileNameSize)
{
	GetModuleFileName(NULL, lpFullFileName, iFullFileNameSize);
	lpFullFileName[iFullFileNameSize - 1] = '\0';
	char *pTemp = strrchr(lpFullFileName, '\\');
	if(pTemp != 0)
	{
		pTemp++;
		*pTemp = '\0';
#ifdef _DEBUG // We look for resources in our .exe directory (not the working directory), this allows the debug build to find them.
		strcat(pTemp, "..\\..\\..\\bin\\");
		pTemp += 13;
#endif
		strncpy(pTemp, lpFileName, lpFullFileName + iFullFileNameSize - pTemp);
		lpFullFileName[iFullFileNameSize - 1] = '\0';
	}
	else
	{
		strcpy(lpFullFileName, lpFileName);
	}
}

bool ShowFileDialog(int iType, LPCTSTR lpTitle, LPCTSTR lpFilter, LPCTSTR lpDefaultExtension, LPTSTR lpFileName, unsigned int uiFileNameSize)
{
	static char lpInitialDirectory[MAX_PATH] = "";

	if(*lpFileName)
	{
		strcpy(lpInitialDirectory, lpFileName);
		char *pFileName = strrchr(lpFileName, '\\') > strrchr(lpFileName, '/') ? strrchr(lpFileName, '\\') : strrchr(lpFileName, '/');
		if(pFileName)
		{
			*pFileName = '\0';
		}

		*lpFileName = '\0';
	}

	OPENFILENAME OpenFileName;
	memset(&OpenFileName, 0, sizeof(OpenFileName));
	OpenFileName.lStructSize = sizeof(OpenFileName);

	OpenFileName.hwndOwner = hMainWindow;
	//OpenFileName.hInstance = InstanceHandle;
	OpenFileName.lpstrTitle = lpTitle;
	OpenFileName.lpstrFilter = lpFilter == 0 ? "All Files (*.*)\0*.*\0" : lpFilter;
	OpenFileName.nFilterIndex = 1;
	OpenFileName.lpstrDefExt = lpDefaultExtension;
	OpenFileName.lpstrFile = lpFileName;
	OpenFileName.nMaxFile = uiFileNameSize;
	OpenFileName.lpstrInitialDir = lpInitialDirectory;
	OpenFileName.Flags = OFN_PATHMUSTEXIST | (iType == FILE_DIALOG_OPEN ? OFN_FILEMUSTEXIST : OFN_OVERWRITEPROMPT);

	if((iType == FILE_DIALOG_OPEN && GetOpenFileName(&OpenFileName)) || (iType == FILE_DIALOG_SAVE && GetSaveFileName(&OpenFileName)))
	{
		return true;
	}

	return false;
}

void AddMenuItem(HMENU hMenu, unsigned int uiSubMenuIndex, unsigned int uiIndex, const char *lpText, unsigned int uiID, unsigned int uiState = 0)
{
	HMENU hSubMenu;
	MENUITEMINFO MenuItemInfo;

	hSubMenu = GetSubMenu(hMenu, uiSubMenuIndex);
	if(hSubMenu == NULL)
	{
		hSubMenu = CreatePopupMenu();

		memset(&MenuItemInfo, 0, sizeof(MenuItemInfo));
		MenuItemInfo.cbSize = sizeof(MenuItemInfo);
		MenuItemInfo.fMask = MIIM_SUBMENU;
		MenuItemInfo.hSubMenu = hSubMenu;

		SetMenuItemInfo(hMenu, uiSubMenuIndex, TRUE, &MenuItemInfo);
	}

	char lpFullText[256] = "&";
	strcat(lpFullText, lpText);

	memset(&MenuItemInfo, 0, sizeof(MenuItemInfo));
	MenuItemInfo.cbSize = sizeof(MenuItemInfo);
	MenuItemInfo.fMask = MIIM_ID | MIIM_STRING | MIIM_STATE;
	MenuItemInfo.fType = MFT_STRING;
	MenuItemInfo.fState = uiState;
	MenuItemInfo.dwTypeData = (LPSTR)lpFullText;
	MenuItemInfo.cch = (UINT)strlen(lpFullText);
	MenuItemInfo.wID = uiID;

	InsertMenuItem(hSubMenu, uiIndex, TRUE, &MenuItemInfo);
}

LRESULT CALLBACK MainProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char lpTemp[MAX_PATH];

	switch(message)
	{
	case WM_CREATE:
	{
		unsigned int i, uiIndex;

		CheckMenuRadioItem(GetMenu(hWnd), ID_CABLES_LINEAR, ID_CABLES_COMPLEXBEZIER, ID_CABLES_LINEAR + VAmp::Configuration.GetCableInterp(), MF_BYCOMMAND);

		for(i = 0; i < VAmp::Audio::AUDIO_DRIVER_COUNT; i++)
		{
			AddMenuItem(GetSubMenu(GetMenu(hWnd), 2), 0, i, VAmp::Audio::CAudioDriver::GetName((VAmp::Audio::EAudioDriver)i), ID_AUDIO_DRIVER_BASE + i);
		}

		CheckMenuRadioItem(GetMenu(hWnd), ID_AUDIO_DRIVER_BASE, ID_AUDIO_DRIVER_BASE + VAmp::Audio::AUDIO_DRIVER_COUNT - 1, ID_AUDIO_DRIVER_BASE + VAmp::Configuration.GetAudioDriver(), MF_BYCOMMAND);

		uiBufferDenominatorCount = 0;
		for(i = 1; i < BUFFER_DENOMINATOR_MAX; i++)
		{
			if(AUDIO_SAMPLES % i == 0)
			{
				lpBufferDenominator[uiBufferDenominatorCount++] = i;
			}
		}

		uiIndex = uiBufferDenominatorCount;
		for(i = 0; i < uiBufferDenominatorCount; i++)
		{
			char lpText[4];
			sprintf(lpText, "%u", lpBufferDenominator[i]);
			AddMenuItem(GetSubMenu(GetMenu(hWnd), 2), 2, uiBufferDenominatorCount, lpText, ID_AUDIO_BUFFER_DENOMINATOR_BASE + i);
			if(lpBufferDenominator[i] == VAmp::Configuration.GetBufferDenominator())
			{
				uiIndex = i;
			}
		}
		AddMenuItem(GetSubMenu(GetMenu(hWnd), 2), 2, uiBufferDenominatorCount, "Other", ID_AUDIO_BUFFER_DENOMINATOR_BASE + uiBufferDenominatorCount, MFS_DISABLED | MFS_GRAYED);
		CheckMenuRadioItem(GetMenu(hWnd), ID_AUDIO_BUFFER_DENOMINATOR_BASE, ID_AUDIO_BUFFER_DENOMINATOR_BASE + uiBufferDenominatorCount, ID_AUDIO_BUFFER_DENOMINATOR_BASE + uiIndex, MF_BYCOMMAND);

		uiIndex = uiBufferFPSCount;
		for(i = 0; i < uiBufferFPSCount; i++)
		{
			char lpText[4];
			sprintf(lpText, "%u", lpBufferFPS[i]);
			AddMenuItem(GetSubMenu(GetMenu(hWnd), 2), 3, i, lpText, ID_AUDIO_BUFFER_FPS_BASE + i);
			if(lpBufferFPS[i] == VAmp::Configuration.GetBufferFPS())
			{
				uiIndex = i;
			}
		}
		AddMenuItem(GetSubMenu(GetMenu(hWnd), 2), 3, uiBufferFPSCount, "Other", ID_AUDIO_BUFFER_FPS_BASE + uiBufferFPSCount, MFS_DISABLED | MFS_GRAYED);
		CheckMenuRadioItem(GetMenu(hWnd), ID_AUDIO_BUFFER_FPS_BASE, ID_AUDIO_BUFFER_FPS_BASE + uiBufferFPSCount, ID_AUDIO_BUFFER_FPS_BASE + uiIndex, MF_BYCOMMAND);

		for(i = 0; i < VAmp::Units::CATEGORY_COUNT; i++)
		{
			AddMenuItem(GetSubMenu(GetMenu(hWnd), 3), 0, 2 + i, VAmp::Units::CUnit::GetCategoryName((VAmp::Units::ECategory)i), ID_ADD_CATEGORY_BASE + i);
		}

		for(i = 0; i < VAmp::Units::UNIT_TYPE_COUNT; i++)
		{
			const VAmp::Units::CUnit::CUnitInfo *pTemplate = VAmp::Units::CUnit::GetUnitInfo((VAmp::Units::EUnitType)i);

			AddMenuItem(GetSubMenu(GetSubMenu(GetMenu(hWnd), 3), 0), 2 + pTemplate->GetCategory(), i, pTemplate->GetName(), ID_ADD_UNIT_BASE + i);
		}

		DrawMenuBar(hWnd);

		InitCommonControls();
		hStatusBarWindow = CreateWindowEx(0, STATUSCLASSNAME, NULL, WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP, 0, 0, 0, 0, hWnd, (HMENU)NULL, hVAmpInstance, NULL);

		int lpWidths[] = { 96, 192, -1 };
		SendMessage(hStatusBarWindow, SB_SETPARTS, sizeof(lpWidths) / sizeof(int), (LPARAM)lpWidths);
		break;
	}
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case ID_NEW_ESSENTIAL:
		case ID_NEW_RECOMMENDED:
		case ID_NEW_PLAYBACK:
		case ID_NEW_EVERYTHING:
			Engine.Lock();
			switch (LOWORD(wParam))
			{
			case ID_NEW_ESSENTIAL:
				Engine.New(VAmp::NEW_TEMPLATE_ESSENTIAL);
				break;
			case ID_NEW_RECOMMENDED:
				Engine.New(VAmp::NEW_TEMPLATE_RECOMMENDED);
				break;
			case ID_NEW_PLAYBACK:
				Engine.New(VAmp::NEW_TEMPLATE_PLAYBACK);
				break;
			case ID_NEW_EVERYTHING:
				Engine.New(VAmp::NEW_TEMPLATE_EVERYTHING);
				break;
			}
			Engine.Unlock();

			*lpFileName = '\0';
			SetMainWindowText(lpFileName);
			break;
		case ID_FILE_OPEN:
			if(ShowFileDialog(FILE_DIALOG_OPEN, "Open Pedalboard", "VAP Files (*.vap)\0*.vap\0", "vap", lpFileName, sizeof(lpFileName)))
			{
				Engine.Lock();
				if(!Engine.Open(lpFileName))
				{
					*lpFileName = '\0';
				}
				Engine.Unlock();

				SetMainWindowText(lpFileName);
			}
			break;
		case ID_FILE_SAVE:
			if(*lpFileName)
			{
				Engine.Lock();
				Engine.Save(lpFileName);
				Engine.Unlock();
				break;
			}
		case ID_FILE_SAVEAS:
			strcpy(lpTemp, lpFileName);
			if(ShowFileDialog(FILE_DIALOG_SAVE, "Save Pedalboard As", "VAP Files (*.vap)\0*.vap\0", "vap", lpFileName, sizeof(lpFileName)))
			{
				Engine.Lock();
				if(!Engine.Save(lpFileName))
				{
					strcpy(lpFileName, lpTemp);
				}
				Engine.Unlock();

				SetMainWindowText(lpFileName);
			}
			break;
		case ID_FILE_EXIT:
			DestroyWindow(hMainWindow);
			break;
		case ID_AUDIO_MUTE:
			if(pAudio->IsPlaying())
			{
				pAudio->Stop();
			}
			else
			{
				pAudio->Play(AUDIO_SAMPLES);
			}
			CheckMenuItem(GetMenu(hWnd), ID_AUDIO_MUTE, pAudio->IsPlaying() ? MF_UNCHECKED : MF_CHECKED);
			break;
		case ID_AUDIO_PLAYBACK_PROPERTIES:
		case ID_AUDIO_RECORDING_PROPERTIES:
		{
			char lpWindowsDirectory[MAX_PATH];
			if(GetWindowsDirectory(lpWindowsDirectory, MAX_PATH) != 0)
			{
				char *lpParameters = LOWORD(wParam) == ID_AUDIO_RECORDING_PROPERTIES ? "/r" : NULL;

				ShellExecute(hMainWindow, "open", "sndvol32.exe", lpParameters, lpWindowsDirectory, SW_SHOWNORMAL);
			}
			break;
		}
		case ID_HELP_ABOUT:
			DialogBox(hVAmpInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, AboutProc);
			break;
		default:
			if(LOWORD(wParam) >= ID_AUDIO_DRIVER_BASE && LOWORD(wParam) < ID_AUDIO_DRIVER_BASE + VAmp::Audio::AUDIO_DRIVER_COUNT)
			{
				if(VAmp::Configuration.GetAudioDriver() != (VAmp::Audio::EAudioDriver)(LOWORD(wParam) - ID_AUDIO_DRIVER_BASE))
				{
					VAmp::Configuration.SetAudioDriver((VAmp::Audio::EAudioDriver)(LOWORD(wParam) - ID_AUDIO_DRIVER_BASE));
					bool bIsPlaying = pAudio->IsPlaying();
					pAudio->Stop();
					delete pAudio;
					pAudio = VAmp::Audio::CAudioDriver::Create(VAmp::Configuration.GetAudioDriver(), hMainWindow, &Engine);
					if(bIsPlaying)
					{
						pAudio->Play(AUDIO_SAMPLES);
					}
					CheckMenuItem(GetMenu(hWnd), ID_AUDIO_MUTE, pAudio->IsPlaying() ? MF_UNCHECKED : MF_CHECKED);
					CheckMenuRadioItem(GetMenu(hWnd), ID_AUDIO_DRIVER_BASE, ID_AUDIO_DRIVER_BASE + VAmp::Audio::AUDIO_DRIVER_COUNT - 1, LOWORD(wParam), MF_BYCOMMAND);
				}
			}
			else if(LOWORD(wParam) >= ID_AUDIO_BUFFER_DENOMINATOR_BASE && LOWORD(wParam) < ID_AUDIO_BUFFER_DENOMINATOR_BASE + uiBufferDenominatorCount)
			{
				VAmp::Configuration.SetBufferDenominator(lpBufferDenominator[LOWORD(wParam) - ID_AUDIO_BUFFER_DENOMINATOR_BASE]);
				if(pAudio->IsPlaying())
				{
					pAudio->Stop();
					Sleep(1000 / VAmp::Configuration.GetBufferDenominator());
					pAudio->Play(AUDIO_SAMPLES);
				}
				CheckMenuRadioItem(GetMenu(hWnd), ID_AUDIO_BUFFER_DENOMINATOR_BASE, ID_AUDIO_BUFFER_DENOMINATOR_BASE + uiBufferDenominatorCount, LOWORD(wParam), MF_BYCOMMAND);
			}
			else if(LOWORD(wParam) >= ID_AUDIO_BUFFER_FPS_BASE && LOWORD(wParam) < ID_AUDIO_BUFFER_FPS_BASE + uiBufferFPSCount)
			{
				VAmp::Configuration.SetBufferFPS(lpBufferFPS[LOWORD(wParam) - ID_AUDIO_BUFFER_FPS_BASE]);
				CheckMenuRadioItem(GetMenu(hWnd), ID_AUDIO_BUFFER_FPS_BASE, ID_AUDIO_BUFFER_FPS_BASE + uiBufferFPSCount, LOWORD(wParam), MF_BYCOMMAND);
			}
			break;
		}
		break;
	case WM_ERASEBKGND:
		return 0;
	case WM_PAINT:
	{
		Engine.Lock();
		Engine.Render();
		Engine.Unlock();

		PAINTSTRUCT PaintStruct;
		BeginPaint(hWnd, &PaintStruct);
		EndPaint(hWnd, &PaintStruct); 
		return 0; 
	}
	case WM_MOVE:
		if(!IsIconic(hWnd) && !IsZoomed(hWnd))
		{
			RECT Rect;;
			if(GetWindowRect(hWnd, &Rect))
			{
				VAmp::Configuration.SetWindowPosition(VAmp::CVector(Rect.left, Rect.top));
			}
		}
		return 0;
	case WM_SIZE:
		Engine.Lock();
		Engine.Resize();
		Engine.Unlock();

		SendMessage(hStatusBarWindow, WM_SIZE, wParam, lParam);

		if(!IsIconic(hWnd))
		{
			if(IsZoomed(hWnd))
			{
				VAmp::Configuration.SetWindowMaximized(true);
			}
			else
			{
				RECT Rect;;
				if(GetWindowRect(hWnd, &Rect))
				{
					VAmp::Configuration.SetWindowSize(VAmp::CVector(Rect.right - Rect.left, Rect.bottom - Rect.top));
				}

				VAmp::Configuration.SetWindowMaximized(false);
			}
		}
		return 0;
	case WM_DESTROY:
		pAudio->Stop();

		Engine.Lock();
		Engine.Destroy();
		Engine.Unlock();

		PostQuitMessage(0);
		return 0;
	}

	if(Engine.HandleMessage(message, wParam, lParam))
	{
		return 0;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

#if _MSC_VER <= 1200
BOOL CALLBACK AboutProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
#else
INT_PTR CALLBACK AboutProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
#endif
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if(LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
