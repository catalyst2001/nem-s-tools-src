/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "virtuAMP.h"
#include "Engine.h"
#include "Log.h"
#include "ParallelFeedbackLoop.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CParallelFeedbackLoopInfo, CParallelFeedbackLoop, ParallelFeedbackLoopInfo);

CParallelFeedbackLoop::CParallelFeedbackLoop(CEngine &Engine) : CUnit(CParallelFeedbackLoop::ParallelFeedbackLoopInfo, Engine), pPower(0), pFeedback(0), pAdditive(0), pVoices(0), pTime(0), pSpace(0), pStomp(0)
{

}

CParallelFeedbackLoop::~CParallelFeedbackLoop()
{
	this->Unload();
}

bool CParallelFeedbackLoop::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/parallel feedback loop.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pFeedback = new CKnob(*this, "Feedback", 0.0f, 1.0f, 0.85f);
	this->pFeedback->SetPosition(CVector(9, 34));
	this->pFeedback->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pFeedback);

	this->pAdditive = new CToggle(*this, "Additive", true);
	this->pAdditive->SetPosition(CVector(34, 20));
	this->pAdditive->SetOnTexture(this->Engine.LoadTexture("units/toggle_small_on.png"));
	this->pAdditive->SetOffTexture(this->Engine.LoadTexture("units/toggle_small_off.png"));
	this->Controls.push_back(this->pAdditive);

	this->pVoices = new CKnob(*this, "Voices", 2.0f, float(PARALLEL_FEEDBACK_LOOP_BUFFERS), 4.0f, true);
	this->pVoices->SetPosition(CVector(43, 34));
	this->pVoices->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pVoices);

	this->pTime = new CKnob(*this, "Time", 0.0f, 0.25f, 0.125f);
	this->pTime->SetPosition(CVector(77, 34));
	this->pTime->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pTime);

	this->pSpace = new CKnob(*this, "Space", 0.0005f, 0.05f, 0.02525f);
	this->pSpace->SetPosition(CVector(111, 34));
	this->pSpace->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pSpace);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPersistent(false);
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	return true;
}

void CParallelFeedbackLoop::UnloadInternal()
{
	this->pPower = 0;
	this->pFeedback = 0;
	this->pAdditive = 0;
	this->pVoices = 0;
	this->pTime = 0;
	this->pSpace = 0;
	this->pStomp = 0;

	for(unsigned int i = 0; i < PARALLEL_FEEDBACK_LOOP_BUFFERS; i++)
	{
		this->lpBuffers[i].Clear();
	}
}

void CParallelFeedbackLoop::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CParallelFeedbackLoop::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	unsigned int i, j;

	for(i = 0; i < PARALLEL_FEEDBACK_LOOP_BUFFERS; i++)
	{
		this->lpBuffers[i].SetSamples((unsigned int)ceilf((float)uiSamplesPerSecond * (this->pTime->GetMax() + this->pSpace->GetMax())) + uiSamples);
	}

	if(!this->pStomp->GetPressed() || this->pFeedback->GetValue() == 0.0f)
	{
		for(i = 0; i < PARALLEL_FEEDBACK_LOOP_BUFFERS; i++)
		{
			this->lpBuffers[i].Advance(uiSamples, lpData);
		}
		return;
	}

	float fFeedback = this->pFeedback->GetValue();
	float fOneMinusFeedback = this->pAdditive->GetOn() ? 1.0f : 1.0f - fFeedback;
	unsigned int uiVoices = (unsigned int)this->pVoices->GetValue();
	float fTime = this->pTime->GetValue();
	float fSpace = this->pSpace->GetValue() / (float)uiVoices;

	float *lpTemp = new float[uiSamples];

	for(i = 0; i < uiVoices; i++)
	{
		unsigned int uiBufferOffset = this->lpBuffers[i]() - (unsigned int)ceilf((float)uiSamplesPerSecond * (fTime + (float)i * fSpace)) - uiSamples;

		for(j = 0; j < uiSamples; j++)
		{
			lpTemp[j] = fOneMinusFeedback * lpData[j] + this->lpBuffers[i][uiBufferOffset + j] * fFeedback;
		}
		this->lpBuffers[i].Advance(uiSamples, lpTemp);
	}

	delete []lpTemp;

	float fNormalize = 1.0f / (float)uiVoices;
	for(i = 0; i < uiSamples; i++)
	{
		float fTotal = 0.0f;
		for(j = 0; j < uiVoices; j++)
		{
			fTotal += this->lpBuffers[j][this->lpBuffers[j]() - uiSamples + i];
		}
		lpData[i] = fTotal * fNormalize;
	}
}
