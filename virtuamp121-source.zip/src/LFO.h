/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.

 *	Portions of this file are based on Audacity:
 *  http://audacity.sourceforge.net/
 */

#pragma once

#include "stdafx.h"

namespace VAmp
{
	namespace DSP
	{
		enum ELFO
		{
			LFO_TRIANGLE,
			LFO_SINE,
			LFO_SQUARE,
			LFO_SAW,
			LFO_MIX,
			LFO_COUNT
		};

		class CLFO
		{
		public:
			virtual ELFO GetType() = 0;
			virtual float GetValue(float fX) = 0;
		};

		class CTriangleLFO : public CLFO
		{
		private:
			float fPeriod;
			float fPeriodOverTwo;
			float fNormalize;

		public:
			CTriangleLFO(unsigned int uiSamplesPerSecond, float fFrequency);

			virtual ELFO GetType()
			{
				return LFO_TRIANGLE;
			}

			virtual float GetValue(float fX);
		};

		class CSineLFO : public CLFO
		{
		private:
			float fNormalize;

		public:
			CSineLFO(unsigned int uiSamplesPerSecond, float fFrequency);

			virtual ELFO GetType()
			{
				return LFO_SINE;
			}

			virtual float GetValue(float fX);
		};

		class CSquareLFO : public CLFO
		{
		private:
			float fNormalize;

		public:
			CSquareLFO(unsigned int uiSamplesPerSecond, float fFrequency);

			virtual ELFO GetType()
			{
				return LFO_SQUARE;
			}

			virtual float GetValue(float fX);
		};

		class CSawLFO : public CLFO
		{
		private:
			float fPeriod;
			float fNormalize;

		public:
			CSawLFO(unsigned int uiSamplesPerSecond, float fFrequency);

			virtual ELFO GetType()
			{
				return LFO_SAW;
			}

			virtual float GetValue(float fX);
		};

		class CMixLFO : public CLFO
		{
		private:
			CLFO &LFO0;
			CLFO &LFO1;

			float fWeight;
			float fOneMinusWeight;

		public:
			CMixLFO(CLFO &LFO0, CLFO &LFO1, float fWeight);

			virtual ELFO GetType()
			{
				return LFO_MIX;
			}

			virtual float GetValue(float fX);
		};
	}
}
