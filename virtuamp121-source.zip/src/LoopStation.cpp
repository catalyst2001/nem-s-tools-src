/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "LoopStation.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CLoopStationInfo, CLoopStation, LoopStationInfo);

CLoopStation::CLoopStation(CEngine &Engine) : CUnit(CLoopStation::LoopStationInfo, Engine), pBeatStart(0), pBeat(0), pPower(0), pRecord(0), pLevel(0), pTrackLevel(0), pTrack(0), pTime(0), pReset(0), pReverse(0), pErase(0), pPlayRecord(0), pStomp(0)
{

}

CLoopStation::~CLoopStation()
{
	this->Unload();
}

bool CLoopStation::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/loop station.png"));
	this->Controls.push_back(pUnit);

	this->pBeatStart = new CSprite(*this);
	this->pBeatStart->SetPosition(CVector(41, 8));
	this->pBeatStart->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->pBeatStart->SetVisible(false);
	this->Controls.push_back(this->pBeatStart);

	this->pBeat = new CSprite(*this);
	this->pBeat->SetPosition(CVector(41, 8));
	this->pBeat->SetTexture(this->Engine.LoadTexture("units/beat.png"));
	this->pBeat->SetVisible(false);
	this->Controls.push_back(this->pBeat);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pRecord = new CSprite(*this);
	this->pRecord->SetPosition(CVector(105, 8));
	this->pRecord->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->pRecord->SetVisible(false);
	this->Controls.push_back(this->pRecord);

	this->pLevel = new CKnob(*this, "Level", 0.0f, 2.0f, 1.0f);
	this->pLevel->SetPosition(CVector(9, 26));
	this->pLevel->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pLevel);

	this->pTrackLevel = new CKnob(*this, "Track Level", 0.0f, 2.0f, 1.0f);
	this->pTrackLevel->SetPersistent(false);
	this->pTrackLevel->SetPosition(CVector(43, 26));
	this->pTrackLevel->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pTrackLevel);

	this->pTrack = new CKnob(*this, "Track", 0.0f, (float)(LOOP_STATION_TRACKS - 1), 0.0f, true);
	this->pTrack->SetPersistent(false);
	this->pTrack->SetPosition(CVector(77, 26));
	this->pTrack->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pTrack);

	this->pTime = new CKnob(*this, "Time", 0.0f, 8.0f, 2.0f);
	this->pTime->SetPosition(CVector(111, 26));
	this->pTime->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pTime);

	this->pReset = new CButton(*this, "Reset", new CButton::CEventClass<CLoopStation>(this, &CLoopStation::OnReset));
	this->pReset->SetPersistent(false);
	this->pReset->SetPosition(CVector(9, 70));
	this->pReset->SetTexture(this->Engine.LoadTexture("units/reset.png"));
	this->pReset->SetUpTexture(this->Engine.LoadTexture("units/button_text_u.png"));
	this->pReset->SetDownTexture(this->Engine.LoadTexture("units/button_text_d.png"));
	this->Controls.push_back(this->pReset);

	this->pReverse = new CButton(*this, "Reverse", new CButton::CEventClass<CLoopStation>(this, &CLoopStation::OnReverse));
	this->pReverse->SetPersistent(false);
	this->pReverse->SetPosition(CVector(43, 70));
	this->pReverse->SetTexture(this->Engine.LoadTexture("units/reverse.png"));
	this->pReverse->SetUpTexture(this->Engine.LoadTexture("units/button_text_u.png"));
	this->pReverse->SetDownTexture(this->Engine.LoadTexture("units/button_text_d.png"));
	this->Controls.push_back(this->pReverse);

	this->pErase = new CButton(*this, "Erase", new CButton::CEventClass<CLoopStation>(this, &CLoopStation::OnErase));
	this->pErase->SetPersistent(false);
	this->pErase->SetPosition(CVector(77, 70));
	this->pErase->SetTexture(this->Engine.LoadTexture("units/erase.png"));
	this->pErase->SetUpTexture(this->Engine.LoadTexture("units/button_text_u.png"));
	this->pErase->SetDownTexture(this->Engine.LoadTexture("units/button_text_d.png"));
	this->Controls.push_back(this->pErase);

	this->pPlayRecord = new CButton(*this, "PlayRecord", new CButton::CEventClass<CLoopStation>(this, &CLoopStation::OnPlayRecord));
	this->pPlayRecord->SetPersistent(false);
	this->pPlayRecord->SetPosition(CVector(111, 70));
	this->pPlayRecord->SetTexture(this->Engine.LoadTexture("units/record.png"));
	this->pPlayRecord->SetUpTexture(this->Engine.LoadTexture("units/button_text_u.png"));
	this->pPlayRecord->SetDownTexture(this->Engine.LoadTexture("units/button_text_d.png"));
	this->Controls.push_back(this->pPlayRecord);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPersistent(false);
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->bLastRecording = false;
	this->uiIndex = 0;
	this->uiLastTrack = 0;

	return true;
}

void CLoopStation::UnloadInternal()
{
	this->pBeatStart = 0;
	this->pBeat = 0;
	this->pPower = 0;
	this->pRecord = 0;
	this->pLevel = 0;
	this->pTrackLevel = 0;
	this->pTrack = 0;
	this->pTime = 0;
	this->pReset = 0;
	this->pReverse = 0;
	this->pErase = 0;
	this->pPlayRecord = 0;
	this->pStomp = 0;

	for(unsigned int i = 0; i < LOOP_STATION_TRACKS; i++)
	{
		this->Tracks[i].Buffer.Clear();
	}
}

void CLoopStation::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());
	if(!this->pStomp->GetPressed())
	{
		this->pBeatStart->SetVisible(false);
		this->pBeat->SetVisible(false);
		this->pRecord->SetVisible(false);
	}

	this->CUnit::RenderInternal();
}

void CLoopStation::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	unsigned int uiTrack = (unsigned int)this->pTrack->GetValue();
	unsigned int uiTime = (unsigned int)((float)uiSamplesPerSecond * this->pTime->GetValue());

	if(this->bLastRecording && !this->pRecord->GetVisible())
	{
		if(uiTime > 0)
		{
			unsigned int uiSmoothSamples = uiSamplesPerSecond / 100;
			if(uiSmoothSamples > uiTime)
			{
				uiSmoothSamples = uiTime;
			}
			unsigned int j = this->uiIndex;
			unsigned int k = (this->uiIndex + 1) % uiTime;
			float fOneOverSmoothSamples = 1.0f / (float)uiSmoothSamples;
			for(unsigned int i = 0; i < uiSmoothSamples / 2; i++)
			{
				float fWeight = 0.5f + (float)i * fOneOverSmoothSamples;
				float fOneMinusWeight = 1.0f - fWeight;
				float fTemp = this->Tracks[uiTrack].Buffer[j] * fWeight + this->Tracks[uiTrack].Buffer[k] * fOneMinusWeight;
				this->Tracks[uiTrack].Buffer[k] = this->Tracks[uiTrack].Buffer[j] * fOneMinusWeight + this->Tracks[uiTrack].Buffer[k] * fWeight;
				this->Tracks[uiTrack].Buffer[j] = fTemp;
				j = j == 0 ? uiTime - 1 : --j;
				k++;
				k %= uiTime;
			}
		}
		this->bLastRecording = false;
	}

	if(uiTrack != this->uiLastTrack)
	{
		this->pRecord->SetVisible(false);
		this->pTrackLevel->SetValue(this->Tracks[uiTrack].fLevel);
		this->uiLastTrack = uiTrack;
	}
	else
	{
		this->Tracks[uiTrack].fLevel = this->pTrackLevel->GetValue();
	}

	if(!this->pStomp->GetPressed())
	{
		this->uiIndex = 0;
		return;
	}

	float fLevel = this->pLevel->GetValue();
	float fTrackLevel = this->pTrackLevel->GetValue();

	if(uiTime > 0)
	{
		this->uiIndex %= uiTime;
	}

	{
		unsigned int uiBins = uiTime / uiSamples;
		unsigned int uiBin = this->uiIndex / uiSamples;
		bool bBeatStartVisible = this->pBeatStart->GetVisible();
		bool bBeatVisible = this->pBeat->GetVisible();
		this->pBeatStart->SetVisible(uiBin == 0);
		if(!this->pBeatStart->GetVisible())
		{
			this->pBeat->SetVisible(uiBin == uiBins / 4 || uiBin == uiBins / 2 || uiBin == (uiBins * 3) / 4);
		}
		if(bBeatStartVisible != this->pBeatStart->GetVisible() || bBeatVisible != this->pBeat->GetVisible())
		{
			this->bRequiresRender = true;
		}
	}

	unsigned int i, j;
	for(i = 0; i < LOOP_STATION_TRACKS; i++)
	{
		if(this->pTime->GetValue() == 0.0f)
		{
			this->Tracks[i].bErased = true;
		}
		this->Tracks[i].Buffer.Resample(uiSamplesPerSecond * (unsigned int)ceilf(this->pTime->GetValue()), this->Tracks[i].bErased);
	}

	if(uiTime > 0)
	{
		if(this->pRecord->GetVisible())
		{
			j = this->uiIndex;
			for(i = 0; i < uiSamples; i++)
			{
				this->Tracks[uiTrack].Buffer[j] = lpData[i];

				j++;
				j %= uiTime;
			}

			this->Tracks[uiTrack].bErased = false;
			this->bLastRecording = true;
		}
	}

	// If not recording, and erased, adjust track level.
	// If not recording, and not erased, don't adjust track level and add one.
	// If recording, adjust track level and don't play recording track.

	unsigned int uiTracks = 1;
	float fTrackLevelSum = 1.0f;
	if(this->pRecord->GetVisible() || this->Tracks[uiTrack].bErased)
	{
		fTrackLevelSum = this->Tracks[uiTrack].fLevel;
	}
	for(i = 0; i < LOOP_STATION_TRACKS; i++)
	{
		if((!this->pRecord->GetVisible() || i != uiTrack) && !this->Tracks[i].bErased)
		{
			uiTracks++;
			fTrackLevelSum += this->Tracks[i].fLevel;
		}
	}

	float fNormalizedLevel = fLevel / (float)uiTracks;
	if(uiTime > 0)
	{
		for(i = 0; i < uiSamples; i++)
		{
			if(this->pRecord->GetVisible() || this->Tracks[uiTrack].bErased)
			{
				lpData[i] *= this->Tracks[uiTrack].fLevel;
			}
			for(j = 0; j < LOOP_STATION_TRACKS; j++)
			{
				if((!this->pRecord->GetVisible() || j != uiTrack) && !this->Tracks[j].bErased)
				{
					if(!this->Tracks[j].bReverse)
					{
						lpData[i] += this->Tracks[j].Buffer[this->uiIndex] * this->Tracks[j].fLevel;
					}
					else
					{
						lpData[i] += this->Tracks[j].Buffer[uiTime - this->uiIndex - 1] * this->Tracks[j].fLevel;
					}
				}
			}
			lpData[i] *= fNormalizedLevel;

			this->uiIndex++;
			this->uiIndex %= uiTime;
		}
	}
	else
	{
		this->uiIndex = 0;
	}

	fNormalizer *= fNormalizedLevel * fTrackLevelSum;
}

void CLoopStation::OnReset(CButton &Button)
{
	this->pTrackLevel->SetValue(1.0f);
	this->pTrack->SetValue(0.0f);
	this->pStomp->SetPressed(false);

	for(unsigned int i = 0; i < LOOP_STATION_TRACKS; i++)
	{
		this->Tracks[i].fLevel = 1.0f;
		this->Tracks[i].bReverse = false;
		this->Tracks[i].bErased = true;
		this->Tracks[i].Buffer.Erase();
	}
}

void CLoopStation::OnReverse(CButton &Button)
{
	unsigned int uiTrack = (unsigned int)this->pTrack->GetValue();

	this->Tracks[uiTrack].bReverse = !this->Tracks[uiTrack].bReverse;
}

void CLoopStation::OnErase(CButton &Button)
{
	unsigned int uiTrack = (unsigned int)this->pTrack->GetValue();

	this->Tracks[uiTrack].bErased = true;
	this->Tracks[uiTrack].Buffer.Erase();
}

void CLoopStation::OnPlayRecord(CButton &Button)
{
	if(!this->pStomp->GetPressed())
	{
		this->pStomp->SetPressed(true);
	}
	else
	{
		this->pRecord->SetVisible(!this->pRecord->GetVisible());
	}
}