/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.

 *	Portions of this file are based on Audacity:
 *  http://audacity.sourceforge.net/
 */

#include "stdafx.h"
#include "FFT.h"
#include "Log.h"

using namespace VAmp;

#define MAX_FAST_BITS 16

namespace VAmp
{
	namespace DSP
	{
		bool bFFTInitialized = false;
		int *lpFFTBitTable[MAX_FAST_BITS];
	}
}

bool DSP::IsPowerOfTwo(unsigned int uiNumber)
{
	return uiNumber > 1 && (uiNumber & (uiNumber - 1)) == 0;
}

unsigned int DSP::GetNextPowerOfTwo(unsigned int uiNumber)
{
	if(uiNumber <= 1)
	{
		return 2;
	}

	if(DSP::IsPowerOfTwo(uiNumber))
	{
		return uiNumber;
	}

	uiNumber--;
	for(unsigned int i = 1; i <= sizeof(unsigned int) * 4; i <<= 1)
	{
		uiNumber = uiNumber | (uiNumber >> i);
	}
	uiNumber++;

	return uiNumber;
}

unsigned int DSP::GetBitNumber(unsigned int uiNumber)
{
	for(unsigned int i = 0; i < sizeof(unsigned int) * 8; i++)
	{
		if(uiNumber & (1 << i))
		{
			return i;
		}
	}

	return 0;
}

static unsigned int ReverseBits(unsigned int uiIndex, unsigned int uiBits)
{
	unsigned int uiReverse = 0;
	for(unsigned int i = 0; i < uiBits; i++)
	{
		uiReverse = (uiReverse << 1) | (uiIndex & 1);
		uiIndex >>= 1;
	}
	return uiReverse;
}

static void InitializeFFT()
{
	if(DSP::bFFTInitialized)
	{
		return;
	}
	unsigned int uiLength = 2;
	for(unsigned int uiBits = 1; uiBits <= MAX_FAST_BITS; uiBits++)
	{
		DSP::lpFFTBitTable[uiBits - 1] = new int[uiLength];

		for(unsigned int i = 0; i < uiLength; i++)
		{
			DSP::lpFFTBitTable[uiBits - 1][i] = ReverseBits(i, uiBits);
		}

		uiLength <<= 1;
	}
	DSP::bFFTInitialized = true;
}

void DSP::ComputeFFT(unsigned int uiSamples, bool bInverseTransform, const float *lpRealIn, const float *lpImagIn, float *lpRealOut, float *lpImagOut)
{
	unsigned int i, j;

	if(!DSP::IsPowerOfTwo(uiSamples))
	{
		return;
	}

	InitializeFFT();

	float angle_numerator = VA_2PI;
	if(bInverseTransform)
	{
		angle_numerator = -angle_numerator;
	}

	unsigned int uiBits = DSP::GetBitNumber(uiSamples);

	for (i = 0; i < uiSamples; i++)
	{
		if(uiBits <= MAX_FAST_BITS)
		{
			j = DSP::lpFFTBitTable[uiBits - 1][i];
		}
		else
		{
			j = ReverseBits(i, uiBits);
		}

		lpRealOut[j] = lpRealIn[i];
		lpImagOut[j] = (lpImagIn == 0) ? 0.0f : lpImagIn[i];
	}

	unsigned int uiBlockEnd = 1;
	for(unsigned int uiBlockSize = 2; uiBlockSize <= uiSamples; uiBlockSize <<= 1)
	{
		float delta_angle = angle_numerator / (float)uiBlockSize;

		float sm2 = sinf(-2.0f * delta_angle);
		float sm1 = sinf(-delta_angle);
		float cm2 = cosf(-2.0f * delta_angle);
		float cm1 = cosf(-delta_angle);
		float w = 2.0f * cm1;
		float ar0, ar1, ar2, ai0, ai1, ai2;

		for(i = 0; i < uiSamples; i += uiBlockSize)
		{
			ar2 = cm2;
			ar1 = cm1;

			ai2 = sm2;
			ai1 = sm1;

			float tr, ti;
			unsigned int k, n;
			for(j = i, n = 0; n < uiBlockEnd; j++, n++)
			{
				ar0 = w * ar1 - ar2;
				ar2 = ar1;
				ar1 = ar0;

				ai0 = w * ai1 - ai2;
				ai2 = ai1;
				ai1 = ai0;

				k = j + uiBlockEnd;
				tr = ar0 * lpRealOut[k] - ai0 * lpImagOut[k];
				ti = ar0 * lpImagOut[k] + ai0 * lpRealOut[k];

				lpRealOut[k] = lpRealOut[j] - tr;
				lpImagOut[k] = lpImagOut[j] - ti;

				lpRealOut[j] += tr;
				lpImagOut[j] += ti;
			}
		}

		uiBlockEnd = uiBlockSize;
	}

	if(bInverseTransform)
	{
		// Normalize.
		float fOneOverSamples = 1.0f / (float)uiSamples;
		for(i = 0; i < uiSamples; i++)
		{
			lpRealOut[i] *= fOneOverSamples;
			lpImagOut[i] *= fOneOverSamples;
		}
	}
}

/*
*	This function was based on the code in Numerical Recipes in C.
*	In Num. Rec., the inner loop is based on a single 1-based array
*	of interleaved real and imaginary numbers.  Because we have two
*	separate zero-based arrays, our indices are quite different.
*	Here is the correspondence between Num. Rec. indices and our indices:
*
*	i1  <->  real[i]
*	i2  <->  imag[i]
*	i3  <->  real[n/2-i]
*	i4  <->  imag[n/2-i]
*/
void DSP::ComputeFFT(unsigned int uiSamples, const float *lpIn, float *lpRealOut, float *lpImagOut)
{
	unsigned int i, j;
	unsigned int uiHalfSamples = uiSamples / 2;
	unsigned int uiQuarterSamples = uiHalfSamples / 2;

	float *lpTempReal = new float[uiHalfSamples];
	float *lpTempImag = new float[uiHalfSamples];

	for(i = 0, j = 0; i < uiHalfSamples; i++)
	{
		lpTempReal[i] = lpIn[j++];
		lpTempImag[i] = lpIn[j++];
	}

	DSP::ComputeFFT(uiHalfSamples, false, lpTempReal, lpTempImag, lpRealOut, lpImagOut);

	float fTheta = VA_PI / (float)uiHalfSamples;

	float wtemp = sinf(0.5f * fTheta);
	float wpr = -2.0f * wtemp * wtemp;
	float wpi = sinf(fTheta);
	float wr = 1.0f + wpr;
	float wi = wpi;

	int i3;

	float h1r, h1i, h2r, h2i;

	for(i = 1; i < uiQuarterSamples; i++)
	{
		i3 = uiHalfSamples - i;

		h1r = 0.5f * (lpRealOut[i] + lpRealOut[i3]);
		h1i = 0.5f * (lpImagOut[i] - lpImagOut[i3]);
		h2r = 0.5f * (lpImagOut[i] + lpImagOut[i3]);
		h2i = -0.5f * (lpRealOut[i] - lpRealOut[i3]);

		lpRealOut[i] = h1r + wr * h2r - wi * h2i;
		lpImagOut[i] = h1i + wr * h2i + wi * h2r;
		lpRealOut[i3] = h1r - wr * h2r + wi * h2i;
		lpImagOut[i3] = -h1i + wr * h2i + wi * h2r;

		wr = (wtemp = wr) * wpr - wi * wpi + wr;
		wi = wi * wpr + wtemp * wpi + wi;
	}

	lpRealOut[0] = (h1r = lpRealOut[0]) + lpImagOut[0];
	lpImagOut[0] = h1r - lpImagOut[0];

	delete []lpTempReal;
	delete []lpTempImag;
}

/*
*	This function computes the same as FFT, above, but
*	adds the squares of the real and imaginary part of each
*	coefficient, extracting the power and throwing away the
*	phase.
*
*	For speed, it does not call FFT, but duplicates some
*	of its code.
*
*	Note: lpOut is half the length of lpIn and uiSamples must
*	be a power of two.
*/
void DSP::ComputeFFT(unsigned int uiSamples, const float *lpIn, float *lpOut)
{
	unsigned int i, j;
	unsigned int uiHalfSamples = uiSamples / 2;
	unsigned int uiQuarterSamples = uiHalfSamples / 2;

	float *lpTempReal = new float[uiHalfSamples];
	float *lpTempImag = new float[uiHalfSamples];
	float *lpRealOut = new float[uiHalfSamples];
	float *lpImagOut = new float[uiHalfSamples];

	for(i = 0, j = 0; i < uiHalfSamples; i++)
	{
		lpTempReal[i] = lpIn[j++];
		lpTempImag[i] = lpIn[j++];
	}

	DSP::ComputeFFT(uiHalfSamples, false, lpTempReal, lpTempImag, lpRealOut, lpImagOut);

	float fTheta = VA_PI / (float)uiHalfSamples;

	float wtemp = sinf(0.5f * fTheta);
	float wpr = -2.0f * wtemp * wtemp;
	float wpi = sinf(fTheta);
	float wr = 1.0f + wpr;
	float wi = wpi;

	int i3;

	float h1r, h1i, h2r, h2i, rt, it;

	for(i = 1; i < uiQuarterSamples; i++)
	{
		i3 = uiHalfSamples - i;

		h1r = 0.5f * (lpRealOut[i] + lpRealOut[i3]);
		h1i = 0.5f * (lpImagOut[i] - lpImagOut[i3]);
		h2r = 0.5f * (lpImagOut[i] + lpImagOut[i3]);
		h2i = -0.5f * (lpRealOut[i] - lpRealOut[i3]);

		rt = h1r + wr * h2r - wi * h2i;
		it = h1i + wr * h2i + wi * h2r;

		lpOut[i] = rt * rt + it * it;

		rt = h1r - wr * h2r + wi * h2i;
		it = -h1i + wr * h2i + wi * h2r;

		lpOut[i3] = rt * rt + it * it;

		wr = (wtemp = wr) * wpr - wi * wpi + wr;
		wi = wi * wpr + wtemp * wpi + wi;
	}

	rt = (h1r = lpRealOut[0]) + lpImagOut[0];
	it = h1r - lpImagOut[0];
	lpOut[0] = rt * rt + it * it;

	rt = lpRealOut[uiQuarterSamples];
	it = lpImagOut[uiQuarterSamples];
	lpOut[uiQuarterSamples] = rt * rt + it * it;

	delete []lpTempReal;
	delete []lpTempImag;
	delete []lpRealOut;
	delete []lpImagOut;
}

void DSP::ComputeWindow(EWindow eWindow, unsigned int uiSamples, float *lpSamples)
{
	if(uiSamples <= 1)
	{
		return;
	}

	switch(eWindow)
	{
		case WINDOW_TRIANGULAR:
		{
			uiSamples /= 2;
			float fOneOverSamples = 1.0f / (float)uiSamples;
			for(unsigned int i = 0; i < uiSamples; i++)
			{
				float fWeight = (float)(i + 1) * fOneOverSamples;
				lpSamples[i] *= fWeight;
				lpSamples[i + uiSamples] *= 1.0f - fWeight;
			}
			break;
		}
		case WINDOW_BARTLETT:
		{
			uiSamples /= 2;
			float fOneOverSamples = 1.0f / (float)(uiSamples - 1);
			for(unsigned int i = 0; i < uiSamples; i++)
			{
				float fWeight = (float)i * fOneOverSamples;
				lpSamples[i] *= fWeight;
				lpSamples[i + uiSamples] *= 1.0f - fWeight;
			}
			break;
		}
		case WINDOW_HAMMING:
		{
			float fTwoPiOverSamples = VA_2PI / (float)(uiSamples - 1);
			for(unsigned int i = 0; i < uiSamples; i++)
			{
				lpSamples[i] *= 0.53836f - 0.46164f * cosf((float)i * fTwoPiOverSamples);
			}
			break;
		}
		case WINDOW_HANNING:
		{
			float fTwoPiOverSamples = VA_2PI / (float)(uiSamples - 1);
			for(unsigned int i = 0; i < uiSamples; i++)
			{
				lpSamples[i] *= 0.50f - 0.5f * cosf((float)i * fTwoPiOverSamples);
			}
			break;
		}
		case WINDOW_COSINE:
		{
			float fTwoPiOverSamples = VA_PI / (float)(uiSamples - 1);
			for(unsigned int i = 0; i < uiSamples; i++)
			{
				lpSamples[i] *= sinf((float)i * fTwoPiOverSamples);
			}
			break;
		}
		case WINDOW_GAUSSIAN:
		{
			const float fAlpha = 0.4f;
			float fSamplesOverTwo = 0.5f * (float)(uiSamples - 1);
			float fOneOverAlphaTimesSamplesOverTwo = 1.0f / (fAlpha * fSamplesOverTwo);
			for(unsigned int i = 0; i < uiSamples; i++)
			{
				float fPower = ((float)i - fSamplesOverTwo) * fOneOverAlphaTimesSamplesOverTwo;
				lpSamples[i] *= expf(-0.5f * fPower * fPower);
			}
		}
		case WINDOW_LANCZOS:
		{
			float fTwoOverSamples = 2.0f / (float)(uiSamples - 1);
			for(unsigned int i = 0; i < uiSamples; i++)
			{
				float fX = VA_PI * ((float)i * fTwoOverSamples - 1.0f);
				lpSamples[i] *= sinf(fX) / fX;
			}
			break;
		}
		case WINDOW_BLACKMAN:
		{
			float fTwoPiOverSamples = VA_2PI / (float)(uiSamples - 1);
			float fFourPiOverSamples = 2.0f * fTwoPiOverSamples;
			for(unsigned int i = 0; i < uiSamples; i++)
			{
				float fI = (float)i;
				lpSamples[i] *= 0.42f - 0.5f * cosf(fI * fTwoPiOverSamples) + 0.08f * cosf(fI * fFourPiOverSamples);
			}
			break;
		}
	}
}

void DSP::ComputeWindow(EWindow eWindow, unsigned int uiSamples, const float *lpIn, float *lpOut)
{
	memcpy(lpOut, lpIn, sizeof(float) * uiSamples);
	DSP::ComputeWindow(eWindow, uiSamples, lpOut);
}
