/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "FFT.h"
#include "FFTSpectrum.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CFFTSpectrumInfo, CFFTSpectrum, FFTSpectrumInfo);

CFFTSpectrum::CFFTSpectrum(CEngine &Engine) : CUnit(CFFTSpectrum::FFTSpectrumInfo, Engine), pPower(0), pStomp(0), uiPeaks(0), lpPeaks(0), lpPeakVelocities(0), Buffer()
{

}

CFFTSpectrum::~CFFTSpectrum()
{
	this->Unload();
}

bool CFFTSpectrum::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/fft spectrum.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp", true);
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	return true;
}

void CFFTSpectrum::UnloadInternal()
{
	this->pPower = 0;
	this->pStomp = 0;

	this->uiPeaks = 0;
	delete []this->lpPeaks;
	this->lpPeaks = 0;
	delete []this->lpPeakVelocities;
	this->lpPeakVelocities = 0;

	this->Buffer.Clear();
}

#define DB_MAX 20.0f
#define DB_MIN -80.0f

void CFFTSpectrum::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();

	if(this->pStomp->GetPressed() && this->Buffer() != 0)
	{
		CVector Position = CVector(14, 30);
		CVector Size = CVector(124, 50);

		float *lpWindow = new float[this->Buffer()];
		DSP::ComputeWindow(DSP::WINDOW_GAUSSIAN, this->Buffer(), this->Buffer.GetBuffer(), lpWindow);

		float *lpSpectrum = new float[this->Buffer() / 2];
		DSP::ComputeFFT(this->Buffer(), lpWindow, lpSpectrum);
		delete []lpWindow;

		unsigned int uiBins = DSP::GetBitNumber(this->Buffer() / 2) - 1;
		float *lpLogSpectrum = new float[uiBins];
		unsigned int i, j, k, uiBinSize;
		for(i = 0, k = 1, uiBinSize = 2; i < uiBins; i++, uiBinSize <<= 1)
		{
			float fNormalize = 1.0f / (float)uiBinSize;
			lpLogSpectrum[i] = 0.0f;
			for(j = 0; j < uiBinSize; j++)
			{
				if(lpSpectrum[k] > 0.0f)
					lpLogSpectrum[i] += 10.0f * log10f(lpSpectrum[k++] / (float)this->Buffer()) * fNormalize;
				else
					lpLogSpectrum[i] += DB_MIN * fNormalize;
			}
		}
		delete []lpSpectrum;

		if(uiBins > this->uiPeaks)
		{
			float *lpPeaks = new float[uiBins];
			memcpy(lpPeaks, this->lpPeaks, sizeof(float) * this->uiPeaks);
			memset(lpPeaks + this->uiPeaks, 0, uiBins - this->uiPeaks);
			delete []this->lpPeaks;
			this->lpPeaks = lpPeaks;

			float *lpPeakVelocities = new float[uiBins];
			memcpy(lpPeakVelocities, this->lpPeakVelocities, sizeof(float) * this->uiPeaks);
			memset(lpPeakVelocities + this->uiPeaks, 0, uiBins - this->uiPeaks);
			delete []this->lpPeakVelocities;
			this->lpPeakVelocities = lpPeakVelocities;

			this->uiPeaks = uiBins;
		}

		int iOldX = Position.X;
		for(i = 0; i < uiBins; i++)
		{
			float fDB = lpLogSpectrum[i];
			if(fDB > DB_MAX)
				fDB = DB_MAX;
			else if(fDB < DB_MIN)
				fDB = DB_MIN;
			fDB = (fDB - DB_MIN) / (DB_MAX - DB_MIN);

			int iNewX = Position.X + (int)((float)(i + 1) / (float)uiBins * (float)Size.X);
			int iY = Position.Y + Size.Y - (int)(fDB * (float)Size.Y);

			glColor3ub(224, 255, 64);
			glBegin(GL_QUADS);
			glVertex2i(iOldX, Position.Y + Size.Y);
			glVertex2i(iOldX, iY);
			glVertex2i(iNewX, iY);
			glVertex2i(iNewX, Position.Y + Size.Y);
			glEnd();

			if(i > 0)
			{
				glColor3ub(128, 140, 64);
				glBegin(GL_LINES);
				glVertex2i(iOldX, Position.Y + Size.Y);
				glVertex2i(iOldX, iY);
				glEnd();
			}

			if(fDB > this->lpPeaks[i])
			{
				this->lpPeaks[i] = fDB;
				this->lpPeakVelocities[i] = 0.0f;
			}

			if(this->lpPeaks[i] > 0.0f)
			{
				iY = Position.Y + Size.Y - (int)(this->lpPeaks[i] * (float)Size.Y);

				glColor3ub(240, 240, 240);
				glBegin(GL_LINES);
				glVertex2i(iOldX, iY);
				glVertex2i(iNewX, iY);
				glEnd();
			}

			iOldX = iNewX;
		}

		glColor3ub(255, 255, 255);

		delete []lpLogSpectrum;
	}
}

void CFFTSpectrum::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	float fFade = 0.0125f * ((float)uiSamples / (float)uiSamplesPerSecond);
	for(unsigned int i = 0; i < this->uiPeaks; i++)
	{
		this->lpPeakVelocities[i] += fFade;
		this->lpPeaks[i] -= this->lpPeakVelocities[i];
		if(this->lpPeaks[i] < 0.0f)
			this->lpPeaks[i] = 0.0f;
	}

	//unsigned int uiBufferSamples = VAmp::GetNextPowerOfTwo(uiSamplesPerSecond / 20);
	this->Buffer.SetSamples(1 << 12);
	this->Buffer.Advance(uiSamples, lpData);
}
