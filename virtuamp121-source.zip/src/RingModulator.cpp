/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "LFO.h"
#include "RingModulator.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CRingModulatorInfo, CRingModulator, RingModulatorInfo);

CRingModulator::CRingModulator(CEngine &Engine) : CUnit(CRingModulator::RingModulatorInfo, Engine), pPower(0), pDepth(0), pShape(0), pFrequency(0), pStomp(0)
{

}

CRingModulator::~CRingModulator()
{
	this->Unload();
}

bool CRingModulator::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/ring modulator.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CKnob(*this, "Depth", 0.0f, 1.0f, 0.5f);
	this->pDepth->SetPosition(CVector(20, 28));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDepth);

	this->pShape = new CKnob(*this, "Shape", -1.0f, 1.0f, 0.0f);
	this->pShape->SetPosition(CVector(60, 42));
	this->pShape->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pShape);

	this->pFrequency = new CKnob(*this, "Frequency", 4.0f, 2048.0f, 512.0f);
	this->pFrequency->SetPosition(CVector(100, 28));
	this->pFrequency->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pFrequency);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->fPhase = 0.0f;

	return true;
}

void CRingModulator::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	this->pShape = 0;
	this->pFrequency = 0;
	this->pStomp = 0;
}

void CRingModulator::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CRingModulator::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed() || this->pDepth->GetValue() == 0.0f)
	{
		this->fPhase = 0.0f;
		return;
	}

	float fDepth = this->pDepth->GetValue();
	float fOneMinusDepth = 1.0f - fDepth;
	float fShape = this->pShape->GetValue();
	float fFrequency = this->pFrequency->GetValueExponential();

	DSP::CTriangleLFO TriangleLFO(uiSamplesPerSecond, fFrequency);
	DSP::CSineLFO SineLFO(uiSamplesPerSecond, fFrequency);
	DSP::CSquareLFO SquareLFO(uiSamplesPerSecond, fFrequency);
	DSP::CMixLFO MixLFO0(SineLFO, TriangleLFO, -fShape);
	DSP::CMixLFO MixLFO1(SineLFO, SquareLFO, fShape);

	DSP::CLFO *pLFO;
	if(fShape == 0.0f)
		pLFO = &SineLFO;
	else if(fShape == -1.0f)
		pLFO = &TriangleLFO;
	else if(fShape == 1.0f)
		pLFO = &SquareLFO;
	else if(fShape < 0.0f)
		pLFO = &MixLFO0;
	else
		pLFO = &MixLFO1;

	for(unsigned int i = 0; i < uiSamples; i++)
	{
		lpData[i] = fOneMinusDepth * lpData[i] + fDepth * lpData[i] * pLFO->GetValue(this->fPhase++);
	}

	this->fPhase = fmodf(this->fPhase, (float)uiSamplesPerSecond / fFrequency);
}
