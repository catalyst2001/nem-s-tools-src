/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.

 *	Portions of this file are based on Audacity:
 *  http://audacity.sourceforge.net/
 */

#include "stdafx.h"
#include "LFO.h"

using namespace VAmp::DSP;

CTriangleLFO::CTriangleLFO(unsigned int uiSamplesPerSecond, float fFrequency) : fPeriod((float)uiSamplesPerSecond / fFrequency), fPeriodOverTwo(0.5f * (float)uiSamplesPerSecond / fFrequency), fNormalize(4.0f / ((float)uiSamplesPerSecond / fFrequency))
{

}

float CTriangleLFO::GetValue(float fX)
{
	fX = fmodf(fX, this->fPeriod);
	if(fX < this->fPeriodOverTwo)
		return fX * this->fNormalize - 1.0f;
	else
		return (this->fPeriod - fX) * this->fNormalize - 1.0f;
}

CSineLFO::CSineLFO(unsigned int uiSamplesPerSecond, float fFrequency) : fNormalize(VA_2PI / ((float)uiSamplesPerSecond / fFrequency))
{

}

float CSineLFO::GetValue(float fX)
{
	return sinf(fX * this->fNormalize);
}

CSquareLFO::CSquareLFO(unsigned int uiSamplesPerSecond, float fFrequency) : fNormalize(VA_2PI / ((float)uiSamplesPerSecond / fFrequency))
{

}

float CSquareLFO::GetValue(float fX)
{
	fX = sinf(fX * this->fNormalize);
	if(fX < 0.0f)
		return -sqrtf(-fX);
	else
		return sqrtf(fX);
}

CSawLFO::CSawLFO(unsigned int uiSamplesPerSecond, float fFrequency) : fPeriod((float)uiSamplesPerSecond / fFrequency), fNormalize(2.0f / ((float)uiSamplesPerSecond / fFrequency))
{

}

float CSawLFO::GetValue(float fX)
{
	fX = fmodf(fX, this->fPeriod);
	return fX * this->fNormalize - 1.0f;
}

CMixLFO::CMixLFO(CLFO &LFO0, CLFO &LFO1, float fWeight) : LFO0(LFO0), LFO1(LFO1), fWeight(fWeight), fOneMinusWeight(1.0f - fWeight)
{

}

float CMixLFO::GetValue(float fX)
{
	return this->fOneMinusWeight * this->LFO0.GetValue(fX) + this->fWeight * this->LFO1.GetValue(fX);
}