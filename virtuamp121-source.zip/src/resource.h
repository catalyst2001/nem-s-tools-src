//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by virtuAMP.rc
//
#define IDC_MYICON                      2
#define IDD_VIRTUAMP_DIALOG             102
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_VIRTUAMP                    107
#define IDI_SMALL                       108
#define IDC_VIRTUAMP                    109
#define IDR_MAINFRAME                   128
#define ID_FILE_NEW                     32771
#define ID_FILE_OPEN                    32772
#define ID_FILE_SAVE                    32773
#define ID_FILE_SAVEAS                  32774
#define IDM_FILE_EXIT                   32775
#define ID_HELP_ABOUT                   32776
#define ID_FILE_EXIT                    32777
#define ID_EFFECTS_ADD                  32781
#define ID_EFFECTS_REMOVE               32782
#define ID_ADD_CABLE                    32796
#define ID_EFFECTS_CLEAR                32797
#define ID_EFFECTS_CLEAN                32798
#define ID_SOUND_MUTE                   32799
#define ID_VIEW_CABLES                  32804
#define ID_CABLES_LINEAR                32805
#define ID_CABLES_BEZIER                32806
#define ID_CABLES_COMPLEXBEZIER         32807
#define ID_EFFECTS_AUTOPOSITION         32808
#define ID_EFFECTS_CLEANCABLES          32809
#define ID_NEW_ESSENTIAL                32810
#define ID_NEW_RECOMMENDED              32811
#define ID_NEW_EVERYTHING               32812
#define ID_NEW_PLAYBACK                 32813
#define ID_SOUND_DRIVER                 32814
#define ID_SOUND_BUFFER                 32815
#define ID_SOUND_FPS                    32816
#define ID_SOUND_BUFFER_DENOMINATOR     32817
#define ID_SOUND_BUFFER_FPS             32818
#define ID_Menu                         32819
#define ID_AUDIO_DRIVER                 32820
#define ID_AUDIO_BUFFER_DENOMINATOR     32821
#define ID_AUDIO_BUFFER_FPS             32822
#define ID_AUDIO_MUTE                   32823
#define ID_BUFFERFPS_OTHER              32824
#define ID_AUDIO_BUFFERFPS              32825
#define ID_AUDIO_PLAYBACK_PROPERTIES    32826
#define ID_AUDIO_RECORDING_PROPERTIES   32827
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32828
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
