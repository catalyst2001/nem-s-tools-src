/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "Vector.h"

namespace VAmp
{
	class CRectangle
	{
	public:
		static const CRectangle Null;

	public:
		union
		{
			struct
			{
				int Top;
				int Right;
				int Bottom;
				int Left;
			};
			int Components[4];
		};

	public:
		inline CRectangle()
		{

		}

		inline CRectangle(const int iTop, const int iRight, const int iBottom, const int iLeft) : Top(iTop), Right(iRight), Bottom(iBottom), Left(iLeft)
		{

		}

		inline CRectangle(const int *lpComponents) : Top(lpComponents[0]), Right(lpComponents[1]), Bottom(lpComponents[2]), Left(lpComponents[3])
		{

		}

		inline CRectangle(const CRectangle &Rectangle) : Top(Rectangle.Top), Right(Rectangle.Right), Bottom(Rectangle.Bottom), Left(Rectangle.Left)
		{

		}

		inline int &operator[](int iIndex)
		{
			assert(iIndex >= 0 && iIndex < 1);

			return this->Components[iIndex];
		}

		inline int operator[](int iIndex) const
		{
			assert(iIndex >= 0 && iIndex < 1);

			return this->Components[iIndex];
		}

		inline bool operator==(const CRectangle &Rectangle) const
		{
			return this->Top == Rectangle.Top && this->Right == Rectangle.Right && this->Bottom == Rectangle.Bottom && this->Left == Rectangle.Left;
		}

		inline bool operator!=(const CRectangle &Rectangle) const
		{
			return this->Top != Rectangle.Top || this->Right != Rectangle.Right || this->Bottom != Rectangle.Bottom || this->Left != Rectangle.Left;
		}

		inline CRectangle operator+(const CVector &Vector) const
		{
			return CRectangle(this->Top + Vector.X, this->Right + Vector.Y, this->Bottom + Vector.X, this->Left + Vector.Y);
		}

		inline CRectangle &operator+=(const CVector &Vector)
		{
			this->Top += Vector.X;
			this->Right += Vector.Y;
			this->Bottom += Vector.X;
			this->Left += Vector.Y;

			return *this;
		}

		inline CRectangle operator-(const CVector &Vector) const
		{
			return CRectangle(this->Top - Vector.X, this->Right - Vector.Y, this->Bottom - Vector.X, this->Left - Vector.Y);
		}

		inline CRectangle &operator-=(const CVector &Vector)
		{
			this->Top -= Vector.X;
			this->Right -= Vector.Y;
			this->Bottom -= Vector.X;
			this->Left -= Vector.Y;

			return *this;
		}

		inline bool IsEmpty() const
		{
			return this->Top >= this->Bottom || this->Left >= this->Right;
		}

		inline bool Intersects(const CVector &Vector) const
		{
			return (Vector.X >= this->Left && Vector.X <= this->Right) && (Vector.Y >= this->Top && Vector.Y <= this->Bottom);
		}
	};
}
