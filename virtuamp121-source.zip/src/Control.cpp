/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Control.h"
#include "Engine.h"
#include "Unit.h"

using namespace VAmp;
using namespace VAmp::Units;

CControl::CControl(CUnit &Unit) : Unit(Unit), lpName(0), bPersistent(true), bVisible(true), Position(0, 0), Size(0, 0), Rectangle(0, 0, 0, 0), pTexture(0)
{

}

CControl::CControl(CUnit &Unit, const char *lpName) : Unit(Unit), bPersistent(true), bVisible(true), Position(0, 0), Size(0, 0), Rectangle(0, 0, 0, 0), pTexture(0)
{
	if(lpName != 0)
	{
		this->lpName = new char[strlen(lpName) + 1];
		strcpy(this->lpName, lpName);
	}
	else
	{
		this->lpName = 0;
	}
}


CControl::~CControl()
{
	delete []this->lpName;
}

void CControl::Render()
{
	if(this->bVisible)
	{
		glPushMatrix();
		glTranslatef((float)this->Position.X, (float)this->Position.Y, 0.0f);

		this->RenderInternal();

		glPopMatrix();
	}
}

void CControl::RenderInternal()
{
	if(this->pTexture != 0)
	{
		double fUMin = 0.0, fVMin = 0.0, fUMax = 1.0, fVMax = 1.0;
		if(!this->Rectangle.IsEmpty())
		{
			fUMin = (double)this->Rectangle.Left / (double)(this->pTexture->GetWidth() - 1);
			fVMin = (double)this->Rectangle.Top / (double)(this->pTexture->GetHeight() - 1);
			fUMax = (double)this->Rectangle.Right / (double)(this->pTexture->GetWidth() - 1);
			fVMax = (double)this->Rectangle.Bottom / (double)(this->pTexture->GetHeight() - 1);
		}

		this->pTexture->Bind();

		glBegin(GL_QUADS);
		glTexCoord2d(fUMin, fVMin);
		glVertex2i(0, 0);
		glTexCoord2d(fUMin, fVMax);
		glVertex2i(0, this->Size.Y);
		glTexCoord2d(fUMax, fVMax);
		glVertex2i(this->Size.X, this->Size.Y);
		glTexCoord2d(fUMax, fVMin);
		glVertex2i(this->Size.X, 0);
		glEnd();

		this->pTexture->Unbind();
	}
}

CButton::CButton(CUnit &Unit, const char *lpName, CEvent *pEvent, char *lpValue) : CControl(Unit, lpName), pEvent(pEvent), pUpTexture(0), pDownTexture(0), lpValue(0)
{
	this->SetValue(lpValue);
}

CButton::~CButton()
{
	delete this->pEvent;
	delete []this->lpValue;
}

EControlType CButton::GetType() const
{
	return CONTROL_TYPE_BUTTON;
}

void CButton::RenderInternal()
{
	bool bPressed = this->Unit.GetEngine().GetPressed(this);

	if(this->pUpTexture != 0 || this->pDownTexture != 0)
	{
		CTexture *pTemp = this->pTexture;

		this->pTexture = bPressed && this->pDownTexture != 0 ? this->pDownTexture : this->pUpTexture;
		this->CControl::RenderInternal();

		this->pTexture = pTemp;
	}

	if(this->pTexture != 0)
	{
		if(bPressed)
		{
			glTranslatef(1.0f, 1.0f, 0.0f);
		}
		this->CControl::RenderInternal();
	}
}

CKnob::CKnob(CUnit &Unit, const char *lpName, float fMin, float fMax, float fValue, bool bSwitch, float fMinRotation, float fMaxRotation) : CControl(Unit, lpName), fMin(fMin), fMax(fMax), fValue(fValue), bSwitch(bSwitch), fMinRotation(fMinRotation), fMaxRotation(fMaxRotation)
{

}

CKnob::~CKnob()
{

}

EControlType CKnob::GetType() const
{
	return CONTROL_TYPE_KNOB;
}

void CKnob::RenderInternal()
{
	float fTemp = (this->GetValue() - this->fMin) / (this->fMax - this->fMin);

	glTranslatef((float)this->Size.X * 0.5f, (float)this->Size.Y * 0.5f, 0.0f);
	glRotatef(this->fMinRotation + fTemp * (this->fMaxRotation - this->fMinRotation), 0.0f, 0.0f, 1.0f);
	glTranslatef((float)this->Size.X * -0.5f, (float)this->Size.Y * -0.5f, 0.0f);

	this->CControl::RenderInternal();
}

CSprite::CSprite(CUnit &Unit) : CControl(Unit)
{

}

CSprite::~CSprite()
{

}

EControlType CSprite::GetType() const
{
	return CONTROL_TYPE_SPRITE;
}

CStomp::CStomp(CUnit &Unit, const char *lpName, bool bPressed) : CControl(Unit, lpName), bPressed(bPressed)
{

}

CStomp::~CStomp()
{

}

EControlType CStomp::GetType() const
{
	return CONTROL_TYPE_STOMP;
}

CToggle::CToggle(CUnit &Unit, const char *lpName, bool bOn) : CControl(Unit, lpName), bOn(bOn), pOnTexture(0), pOffTexture(0)
{

}

CToggle::~CToggle()
{

}

EControlType CToggle::GetType() const
{
	return CONTROL_TYPE_TOGGLE;
}

void CToggle::RenderInternal()
{
	if(this->pOnTexture != 0 || this->pOffTexture != 0)
	{
		CTexture *pTemp = this->pTexture;

		this->pTexture = this->bOn && this->pOnTexture != 0 ? this->pOnTexture : this->pOffTexture;
		this->CControl::RenderInternal();

		this->pTexture = pTemp;
	}

	if(this->pTexture != 0)
	{
		this->CControl::RenderInternal();
	}
}

CVerticalSlider::CVerticalSlider(CUnit &Unit, const char *lpName, float fMin, float fMax, float fValue, float fMinOffset, float fMaxOffset) : CControl(Unit, lpName), fMin(fMin), fMax(fMax), fValue(fValue), fMinOffset(fMinOffset), fMaxOffset(fMaxOffset)
{

}

CVerticalSlider::~CVerticalSlider()
{

}

EControlType CVerticalSlider::GetType() const
{
	return CONTROL_TYPE_VERTICAL_SLIDER;
}

void CVerticalSlider::RenderInternal()
{
	float fTemp = (this->fValue - this->fMin) / (this->fMax - this->fMin);

	float fOffset = fMinOffset + fTemp * (fMaxOffset - fMinOffset);

	glTranslatef(0.0f, fOffset, 0.0f);

	this->CControl::RenderInternal();
}
