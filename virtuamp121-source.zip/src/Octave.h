/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "AudioBuffer.h"
#include "Unit.h"

#define OCTAVE_SLIDERS 7
#define OCTAVE_FREQUENCY_HISTORY 3

namespace VAmp
{
	namespace Units
	{
		class COctave : public CUnit
		{
			REGISTER_UNIT(COctaveInfo, COctave, OctaveInfo, UNIT_TYPE_OCTAVE, "Octave", CATEGORY_PITCH_SHIFT);

		private:
			CSprite *pPower;
			CVerticalSlider *pDepth;
			CVerticalSlider *lpOctaves[OCTAVE_SLIDERS];
			CStomp *pStomp;

			unsigned int uiNoteSample;
			float fNoteFrequency;
			float fNoteVolume;
			float fNoteFrequencyHistory[OCTAVE_FREQUENCY_HISTORY];
			enum ESchmittTriggerState
			{
				SCHMITT_TRIGGER_STATE_UNSET,
				SCHMITT_TRIGGER_STATE_UP,
				SCHMITT_TRIGGER_STATE_DOWN
			} eSchmittTriggerState;
			float lpX[OCTAVE_SLIDERS];

			DSP::CAudioBuffer Buffer;

		public:
			COctave(CEngine &Engine);
			virtual ~COctave();

		protected:
			virtual bool LoadInternal();
			virtual void UnloadInternal();

			virtual void RenderInternal();

			virtual void ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer);
		};
	}
}
