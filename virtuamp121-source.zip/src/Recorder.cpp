/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "virtuAMP.h"
#include "Engine.h"
#include "Log.h"
#include "Recorder.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CRecorderInfo, CRecorder, RecorderInfo);

CRecorder::CRecorder(CEngine &Engine) : CUnit(CRecorder::RecorderInfo, Engine), pPower(0), pVolume(0), pSave(0), pStomp(0), hWaveOut(NULL), uiBufferSamples(0), lpBuffer(0)
{

}

CRecorder::~CRecorder()
{
	this->Unload();
}

bool CRecorder::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/recorder.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pVolume = new CKnob(*this, "Volume", 0.0f, 2.0f, 1.0f);
	this->pVolume->SetPosition(CVector(60, 34));
	this->pVolume->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pVolume);

	this->pSave = new CButton(*this, "FileName", new CButton::CEventClass<CRecorder>(this, &CRecorder::OnSave));
	this->pSave->SetPosition(CVector(127, 70));
	this->pSave->SetTexture(this->Engine.LoadTexture("units/save.png"));
	this->pSave->SetUpTexture(this->Engine.LoadTexture("units/button_u.png"));
	this->pSave->SetDownTexture(this->Engine.LoadTexture("units/button_d.png"));
	this->Controls.push_back(this->pSave);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPersistent(false);
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->hWaveOut = NULL;

	return true;
}

void CRecorder::UnloadInternal()
{
	this->StopRecording();

	this->Engine.UnloadTexture(this->pSave->GetUpTexture());
	this->Engine.UnloadTexture(this->pSave->GetDownTexture());

	this->pPower = 0;
	this->pVolume = 0;
	this->pSave = 0;
	this->pStomp = 0;

	this->uiBufferSamples = 0;

	delete []this->lpBuffer;
	this->lpBuffer = 0;
}

void CRecorder::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CRecorder::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		this->StopRecording();
		return;
	}

	if(!this->IsRecording())
	{
		if(!this->StartRecording(uiSamplesPerSecond))
		{
			this->pStomp->SetPressed(false);
			return;
		}
	}

	if(this->uiBufferSamples != uiSamples)
	{
		this->uiBufferSamples = uiSamples;

		delete []this->lpBuffer;
		this->lpBuffer = new float[this->uiBufferSamples];
	}

	float fVolume = this->pVolume->GetValue();
	if(fVolume <= 1.0f)
	{
		// The first half of the dial normalizes the volume between 0 and 1 where 1 is the original signal strength.
		fVolume /= fNormalizer;
	}
	else if(fNormalizer <= 1.0f)
	{
		// The second half normalizes to 1 if the signal strength has been diminished.
		fVolume = 1.0f / fNormalizer;
	}
	else
	{
		// Otherwise, the second half normalizes between 1 and the amplified signal strength.
		fVolume = (2.0f - fVolume) * (fVolume / fNormalizer) + (fVolume - 1.0f);
	}

	for(unsigned int i = 0; i < uiSamples; i++)
	{
		this->lpBuffer[i] = lpData[i] * fVolume;

		if(this->lpBuffer[i] < -1.0f)
		{
			this->lpBuffer[i] = -1.0f;
		}
		if(this->lpBuffer[i] > 1.0f)
		{
			this->lpBuffer[i] = 1.0f;
		}
	}

	// Write the WAVE data.
	mmioWrite(this->hWaveOut, (char *)this->lpBuffer, uiSamples * sizeof(float));
}

void CRecorder::OnSave(CButton &Button)
{
	char lpFileName[MAX_PATH] = "";
	if(this->pSave->GetValue() != 0)
	{
		strcpy(lpFileName, this->pSave->GetValue());
	}

	if(ShowFileDialog(FILE_DIALOG_SAVE, "Save Recording As", "Wave Files (*.wav)\0*.wav\0", "wav", lpFileName, sizeof(lpFileName)))
	{
		this->StopRecording();
		this->pStomp->SetPressed(false);

		this->pSave->SetValue(lpFileName);
	}
}

bool CRecorder::IsRecording()
{
	return this->hWaveOut != NULL;
}

bool CRecorder::StartRecording(unsigned int uiSamplesPerSecond)
{
	if(this->IsRecording())
	{
		return true;
	}

	if(this->pSave->GetValue() == 0 || *this->pSave->GetValue() == '\0')
	{
		return false;
	}

	memset(&this->WaveInfo, 0, sizeof(MMCKINFO));
	memset(&this->WaveFormatInfo, 0, sizeof(MMCKINFO));
	memset(&this->WaveDataInfo, 0, sizeof(MMCKINFO));

	this->uiBufferSamples = 0;

	delete []this->lpBuffer;
	this->lpBuffer = 0;

	// Open the WAVE file.
	if((this->hWaveOut = mmioOpen(const_cast<char *>(this->pSave->GetValue()), 0, MMIO_CREATE | MMIO_WRITE | MMIO_EXCLUSIVE)) == NULL)
	{
		LogError("Error opening %s for writing.", this->pSave->GetValue());
		return false;
	}

	// Create WAVE chunk.
	this->WaveInfo.ckid = FOURCC_RIFF;
	this->WaveInfo.fccType = mmioFOURCC('W', 'A', 'V', 'E');
	this->WaveInfo.cksize = 0;

	if(mmioCreateChunk(this->hWaveOut, &this->WaveInfo, MMIO_CREATERIFF) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveOut, 0);
		this->hWaveOut= NULL;

		LogError("Error creating WAVE chunk for %s.", this->pSave->GetValue());
		return false;
	}

	// Create WAVE format chunk.
	this->WaveFormatInfo.ckid = mmioFOURCC('f', 'm', 't', ' ');
	this->WaveFormatInfo.cksize = sizeof(WAVEFORMATEX);

	if(mmioCreateChunk(this->hWaveOut, &this->WaveFormatInfo, 0) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveOut, 0);
		this->hWaveOut= NULL;

		LogError("Error creating WAVE format chunk for %s.", this->pSave->GetValue());
		return false;
	}

	// Setup the header.
	PCMWAVEFORMAT WaveFormat;
	WaveFormat.wf.wFormatTag = WAVE_FORMAT_IEEE_FLOAT;
	WaveFormat.wf.nChannels = 1;
	WaveFormat.wf.nSamplesPerSec = uiSamplesPerSecond;
	WaveFormat.wf.nAvgBytesPerSec = uiSamplesPerSecond * sizeof(float);
	WaveFormat.wf.nBlockAlign = sizeof(float);
	WaveFormat.wBitsPerSample = 8 * sizeof(float);

	// Write WAVE format.
	if(mmioWrite(this->hWaveOut, (HPSTR)&WaveFormat, sizeof(PCMWAVEFORMAT)) != sizeof(PCMWAVEFORMAT))
	{
		mmioClose(this->hWaveOut, 0);
		this->hWaveOut= NULL;

		LogError("Error writing WAVE format chunk for %s.", this->pSave->GetValue());
		return false;
	}

	// Ascend to the WAVE layer.
	if(mmioAscend(this->hWaveOut, &this->WaveFormatInfo, 0) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveOut, 0);
		this->hWaveOut= NULL;

		LogError("Error ascending from WAVE format chunk for %s.", this->pSave->GetValue());
		return false;
	}

	// Create WAVE data chunk.
	this->WaveDataInfo.ckid = mmioFOURCC('d', 'a', 't', 'a');

	if(mmioCreateChunk(this->hWaveOut, &this->WaveDataInfo, 0) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveOut, 0);
		this->hWaveOut= NULL;

		LogError("Error creating WAVE data chunk for %s.", this->pSave->GetValue());
		return false;
	}

	return true;
}

void CRecorder::StopRecording()
{
	if(!this->IsRecording())
	{
		return;
	}

	if(mmioAscend(this->hWaveOut, &this->WaveDataInfo, 0) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveOut, 0);
		this->hWaveOut= NULL;

		LogError("Error ascending from WAVE data chunk for %s.", this->pSave->GetValue());
		return;
	}

	if(mmioAscend(this->hWaveOut, &this->WaveInfo, 0) != MMSYSERR_NOERROR)
	{
		mmioClose(this->hWaveOut, 0);
		this->hWaveOut= NULL;

		LogError("Error ascending from WAVE chunk for %s.", this->pSave->GetValue());
		return;
	}

	mmioClose(this->hWaveOut, 0);
	this->hWaveOut= NULL;
}
