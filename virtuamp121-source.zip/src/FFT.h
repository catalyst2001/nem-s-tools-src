/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.

 *	Portions of this file are based on Audacity:
 *  http://audacity.sourceforge.net/
 */

#pragma once

#include "stdafx.h"

namespace VAmp
{
	namespace DSP
	{
		bool IsPowerOfTwo(unsigned int uiNumber);
		unsigned int GetNextPowerOfTwo(unsigned int uiNumber);
		unsigned int GetBitNumber(unsigned int uiNumber);

		void ComputeFFT(unsigned int uiSamples, bool bInverseTransform, const float *lpRealIn, const float *lpImagIn, float *lpRealOut, float *lpImagOut);
		void ComputeFFT(unsigned int uiSamples, const float *lpIn, float *lpRealOut, float *lpImagOut);
		void ComputeFFT(unsigned int uiSamples, const float *lpIn, float *lpOut);

		enum EWindow
		{
			WINDOW_RECTANGULAR, // None.
			WINDOW_TRIANGULAR,
			WINDOW_BARTLETT,
			WINDOW_HAMMING,
			WINDOW_HANNING,
			WINDOW_COSINE,
			WINDOW_GAUSSIAN,
			WINDOW_LANCZOS,
			WINDOW_BLACKMAN,
			WINDOW_COUNT
		};

		void ComputeWindow(EWindow eWindow, unsigned int uiSamples, float *lpSamples);
		void ComputeWindow(EWindow eWindow, unsigned int uiSamples, const float *lpIn, float *lpOut);
	}
}
