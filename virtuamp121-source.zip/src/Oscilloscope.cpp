/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Oscilloscope.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(COscilloscopeInfo, COscilloscope, OscilloscopeInfo);

COscilloscope::COscilloscope(CEngine &Engine) : CUnit(COscilloscope::OscilloscopeInfo, Engine), pPower(0), pStomp(0), Buffer()
{

}

COscilloscope::~COscilloscope()
{
	this->Unload();
}

bool COscilloscope::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/oscilloscope.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp", true);
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->uiBinSamples = 0;
	for(unsigned int i = 0; i < OSCILLOSCOPE_WIDTH; i++)
	{
		this->lpBins[i].fMin = 0.0f;
		this->lpBins[i].fMax = 0.0f;
	}

	return true;
}

void COscilloscope::UnloadInternal()
{
	this->pPower = 0;
	this->pStomp = 0;

	this->Buffer.Clear();
}

void COscilloscope::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();

	if(this->Buffer() != 0)
	{
		CVector Position = CVector(14, 30);
		CVector Size = CVector(OSCILLOSCOPE_WIDTH, 50);

		glBegin(GL_LINES);

		for(int i = 0; i < Size.X; i++)
		{
			if(this->lpBins[i].fMin < -1.0f)
				glColor3ub(255, 128, 128);
			else
				glColor3ub(128, 255, 128);
			glVertex2i(Position.X + i, Position.Y + Size.Y / 2 + (int)(this->lpBins[i].fMin * (float)(Size.Y / 4)));

			glColor3ub(64, 255, 64);
			glVertex2i(Position.X + i, Position.Y + Size.Y / 2);

			if(this->lpBins[i].fMax > 1.0f)
				glColor3ub(255, 128, 128);
			else
				glColor3ub(128, 255, 128);
			glVertex2i(Position.X + i, Position.Y + Size.Y / 2 + (int)(this->lpBins[i].fMax * (float)(Size.Y / 4)));

			glColor3ub(64, 255, 64);
			glVertex2i(Position.X + i, Position.Y + Size.Y / 2);
		}

		glEnd();
		glColor3ub(255, 255, 255);
	}
}

void COscilloscope::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(uiSamples > uiSamplesPerSecond)
	{
		lpData += uiSamples - uiSamplesPerSecond;
		uiSamples = uiSamplesPerSecond;
	}

	unsigned int uiPixelSamples = uiSamplesPerSecond / OSCILLOSCOPE_WIDTH;

	this->Buffer.SetSamples(uiPixelSamples + uiSamples);
	this->Buffer.Advance(uiSamples, lpData);

	this->uiBinSamples += uiSamples;
	unsigned int uiBins = this->uiBinSamples / uiPixelSamples;
	this->uiBinSamples %= uiPixelSamples;

	memmove(this->lpBins, this->lpBins + uiBins, sizeof(SBin) * (OSCILLOSCOPE_WIDTH - uiBins));

	if(this->pStomp->GetPressed())
	{
		for(unsigned int i = 0; i < uiBins; i++)
		{
			unsigned int uiBufferOffset = this->Buffer() - uiPixelSamples * (i + 1) - this->uiBinSamples;

			float fMin, fMax;
			fMin = fMax = this->Buffer[uiBufferOffset];
			for(unsigned int j = 1; j < uiPixelSamples; j++)
			{
				float fValue = this->Buffer[uiBufferOffset + j];
				if(fValue < fMin)
					fMin = fValue;
				if(fValue > fMax)
					fMax = fValue;
			}
			if(fMin > 0.0f)
				fMin = 0.0f;
			if(fMin < -2.0f)
				fMin = -2.0f;
			if(fMax < 0.0f)
				fMax = 0.0f;
			if(fMax > 2.0f)
				fMax = 2.0f;

			this->lpBins[OSCILLOSCOPE_WIDTH - uiBins + i].fMin = fMin;
			this->lpBins[OSCILLOSCOPE_WIDTH - uiBins + i].fMax = fMax;
		}
	}
	else
	{
		memset(this->lpBins + OSCILLOSCOPE_WIDTH - uiBins, 0, sizeof(SBin) * uiBins);
	}
}
