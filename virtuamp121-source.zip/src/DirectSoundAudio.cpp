/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#ifdef USE_DIRECTSOUND

#include "stdafx.h"
#include "Configuration.h"
#include "DirectSoundAudio.h"
#include "Engine.h"
#include "Log.h"

using namespace VAmp;
using namespace VAmp::Audio;

LONG WINAPI CaptureThreadStart(void *pDirectSoundAudio)
{
    ((CDirectSoundAudio *)pDirectSoundAudio)->CaptureLoop();

	return 1L;
}

CDirectSoundAudio::CDirectSoundAudio(HWND hWnd, CEngine *pEngine) : CAudioDriver(hWnd, pEngine), pDirectSound(NULL), pCaptureBuffer(NULL), pCaptureNotify(NULL), lpCapturePositions(NULL), lpCaptureHandles(NULL), hCaptureThread(NULL), pPlaybackBuffer(NULL)
{

}

CDirectSoundAudio::~CDirectSoundAudio()
{
	this->Stop();
}

EAudioDriver CDirectSoundAudio::GetType() const
{
	return AUDIO_DRIVER_DIRECTSOUND;
}

bool CDirectSoundAudio::IsPlaying()
{
	return this->pDirectSound != NULL;
}

bool CDirectSoundAudio::Play(unsigned int uiSamplesPerSecond)
{
	if(this->pDirectSound != NULL)
	{
		return true;
	}

	LogMessage("Starting DirectSound driver...");

	if(uiSamplesPerSecond % Configuration.GetBufferDenominator() != 0)
	{
		LogError("Sample rate %u Hz not divisible by buffer denominator %u.", uiSamplesPerSecond, Configuration.GetBufferDenominator());
		return false;
	}

	HRESULT Result;
	unsigned int i;

	if(FAILED(Result = CoInitialize(NULL)))
	{
		LogDirectSoundError(Result, "CoInitialize() failed.");
		return false;
	}

	if(FAILED(Result = CoCreateInstance(CLSID_DirectSoundFullDuplex, NULL, CLSCTX_INPROC_SERVER, IID_IDirectSoundFullDuplex, (void **)&this->pDirectSound)))
	{
		CoUninitialize();
		LogDirectSoundError(Result, "CoCreateInstance() failed.");
		return false;
	}

	memset(&this->WaveFormat, 0, sizeof(WAVEFORMATEX));
	this->WaveFormat.wFormatTag = WAVE_FORMAT_IEEE_FLOAT;
	this->WaveFormat.nChannels = 1;
	this->WaveFormat.nSamplesPerSec = uiSamplesPerSecond;
	this->WaveFormat.nAvgBytesPerSec = uiSamplesPerSecond * sizeof(float);
	this->WaveFormat.nBlockAlign = sizeof(float);
	this->WaveFormat.wBitsPerSample = 8 * sizeof(float);
	this->WaveFormat.cbSize = 0;

	memset(&this->CaptureBufferDescription, 0, sizeof(DSCBUFFERDESC));
	this->CaptureBufferDescription.dwSize = sizeof(DSCBUFFERDESC);
	//this->CaptureBufferDescription.dwFlags = DSCBCAPS_WAVEMAPPED;
	this->CaptureBufferDescription.dwBufferBytes = this->WaveFormat.nAvgBytesPerSec / Configuration.GetBufferDenominator() * Configuration.GetAudioBuffers();
	this->CaptureBufferDescription.lpwfxFormat = &this->WaveFormat;

	memset(&this->PlaybackBufferDescription, 0, sizeof(DSBUFFERDESC));
	this->PlaybackBufferDescription.dwSize = sizeof(DSBUFFERDESC);
	this->PlaybackBufferDescription.dwFlags = DSBCAPS_GLOBALFOCUS | DSBCAPS_CTRLPOSITIONNOTIFY | DSBCAPS_LOCSOFTWARE;
	this->PlaybackBufferDescription.dwBufferBytes = this->WaveFormat.nAvgBytesPerSec / Configuration.GetBufferDenominator() * Configuration.GetAudioBuffers();
	this->PlaybackBufferDescription.lpwfxFormat = &this->WaveFormat;

	if(FAILED(Result = pDirectSound->Initialize(&DSDEVID_DefaultCapture, &DSDEVID_DefaultPlayback, &this->CaptureBufferDescription, &this->PlaybackBufferDescription, this->hWnd, DSSCL_PRIORITY, &this->pCaptureBuffer, &this->pPlaybackBuffer)))
	{
		this->Stop();
		LogDirectSoundError(Result, "IDirectSoundFullDuplex.Initialize() failed.");
		return false;
	}

	if(FAILED(Result = this->pCaptureBuffer->QueryInterface(IID_IDirectSoundNotify8, (void **)&this->pCaptureNotify)))
	{
		this->Stop();
		LogDirectSoundError(Result, "IDirectSoundCaptureBuffer8.QueryInterface() failed.");
		return false;
	}

	this->uiCapturePositions = Configuration.GetAudioBuffers();
	this->uiCaptureBytes = this->WaveFormat.nAvgBytesPerSec / Configuration.GetBufferDenominator();

	this->lpCaptureHandles = new HANDLE[this->uiCapturePositions + 1];
	memset(this->lpCaptureHandles, 0, (this->uiCapturePositions + 1) * sizeof(HANDLE));

	for(i = 0; i < this->uiCapturePositions; i++)
	{
		if((this->lpCaptureHandles[i] = CreateEvent(NULL, FALSE, FALSE, NULL)) == NULL)
		{
			this->Stop();
			LogSystemError("CreateEvent() failed.");
			return false;
		}
	}

	this->lpCapturePositions = new DSBPOSITIONNOTIFY[this->uiCapturePositions];
	memset(this->lpCapturePositions, 0, this->uiCapturePositions * sizeof(DSBPOSITIONNOTIFY));

	for(i = 0; i < this->uiCapturePositions; i++)
	{
		this->lpCapturePositions[i].dwOffset = (i + 1) * this->uiCaptureBytes - 1;
		this->lpCapturePositions[i].hEventNotify = this->lpCaptureHandles[i];
	}

	if(FAILED(Result = this->pCaptureNotify->SetNotificationPositions(this->uiCapturePositions, this->lpCapturePositions)))
	{
		this->Stop();
		LogDirectSoundError(Result, "IDirectSoundNotify8.SetNotificationPositions(%u) failed.", this->uiCapturePositions);
		return false;
	}

	if((this->lpCaptureHandles[this->uiCapturePositions] = CreateEvent(NULL, TRUE, FALSE, NULL)) == NULL)
	{
		this->Stop();
		LogSystemError("CreateEvent() failed.");
		return false;
	}

	DWORD dwThreadID;
	if((this->hCaptureThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CaptureThreadStart, (void *)this, 0, &dwThreadID)) == NULL)
	{
		this->Stop();
		LogSystemError("CreateThread() failed.");
		return false;
	}

	if(FAILED(Result = this->pCaptureBuffer->Start(DSBPLAY_LOOPING)))
	{
		this->Stop();
		LogDirectSoundError(Result, "IDirectSoundCaptureBuffer8.Start() failed.");
		return false;
	}

	//if(FAILED(Result = this->pPlaybackBuffer->Play(0, 0, DSBPLAY_LOOPING)))
	//{
	//	this->Stop();
	//	LogDirectSoundError(Result, "IDirectSoundBuffer8.Play() failed.");
	//	return false;
	//}

	LogMessage("DirectSound driver started.");

	return true;
}

void CDirectSoundAudio::Stop()
{
	if(this->pDirectSound != NULL)
	{
		LogMessage("Stopping DirectSound driver...");

		unsigned int i;

		if(this->pCaptureBuffer != NULL)
		{
			this->pCaptureBuffer->Stop();

			if(this->lpCaptureHandles != NULL)
			{
				if(this->hCaptureThread != NULL)
				{
					SetEvent(this->lpCaptureHandles[this->uiCapturePositions]);
					WaitForSingleObject(this->hCaptureThread, INFINITE);
					CloseHandle(this->hCaptureThread);
					this->hCaptureThread = NULL;
				}
				CloseHandle(this->lpCaptureHandles[this->uiCapturePositions]);
			}

			if(this->pCaptureNotify != NULL)
			{
				this->pCaptureNotify->Release();
				this->pCaptureNotify = NULL;
			}

			if(this->lpCaptureHandles != NULL)
			{
				for(i = 0; i < this->uiCapturePositions; i++)
				{
					CloseHandle(this->lpCaptureHandles[i]);
				}
				delete []this->lpCaptureHandles;
				this->lpCaptureHandles = 0;
			}

			delete []this->lpCapturePositions;
			this->lpCapturePositions = NULL;

			this->pCaptureBuffer->Release();
			this->pCaptureBuffer = NULL;
		}

		if(this->pPlaybackBuffer != NULL)
		{
			this->pPlaybackBuffer->Stop();

			this->pPlaybackBuffer->Release();
			this->pPlaybackBuffer = NULL;
		}

		this->pDirectSound->Release();
		this->pDirectSound = NULL;

		CoUninitialize();

		LogMessage("DirectSound driver stopped.");
	}
}

void CDirectSoundAudio::CaptureLoop()
{
	unsigned int uiReceivedBuffers = 0;
	unsigned int uiReceivedSamples = 0;

	for(;;)
	{
		DWORD dwResult = WaitForMultipleObjects(this->uiCapturePositions + 1, this->lpCaptureHandles, FALSE, INFINITE);
		if(dwResult >= WAIT_OBJECT_0 && dwResult < WAIT_OBJECT_0 + this->uiCapturePositions)
		{
			DWORD dwBuffer = dwResult - WAIT_OBJECT_0;

			LPVOID lpCaptureData;
			DWORD dwCaptureLength;
			if(SUCCEEDED(this->pCaptureBuffer->Lock(dwBuffer * this->uiCaptureBytes, this->uiCaptureBytes, &lpCaptureData, &dwCaptureLength, NULL, NULL, 0)))
			{
				LPVOID lpPlaybackData;
				DWORD dwPlaybackLength;
				if(SUCCEEDED(this->pPlaybackBuffer->Lock(dwBuffer * this->uiCaptureBytes, this->uiCaptureBytes, &lpPlaybackData, &dwPlaybackLength, NULL, NULL, 0)))
				{
					if(dwPlaybackLength <= dwCaptureLength)
					{
						memcpy(lpPlaybackData, lpCaptureData, dwPlaybackLength);
					}
					else
					{
						memcpy(lpPlaybackData, lpCaptureData, dwCaptureLength);
						memset((LPBYTE)lpPlaybackData + dwCaptureLength, 0, dwPlaybackLength - dwCaptureLength);
					}

					unsigned int uiSamples = dwPlaybackLength / sizeof(float);

					uiReceivedBuffers++;
					uiReceivedSamples += uiSamples;

					if(this->pEngine != 0)
					{
						this->pEngine->Lock();
						this->pEngine->Process((float *)lpPlaybackData, this->WaveFormat.nSamplesPerSec, uiSamples);
						this->pEngine->Unlock();
					}

					this->pPlaybackBuffer->Unlock(lpPlaybackData, dwPlaybackLength, NULL, 0);
				}
				this->pCaptureBuffer->Unlock(lpCaptureData, dwCaptureLength, NULL, 0);
			}

			if(uiReceivedBuffers == 2)
			{
				this->pPlaybackBuffer->Play(0, 0, DSBPLAY_LOOPING);
			}

			if(this->pEngine->GetUnitRequiresRender() || uiReceivedSamples > this->WaveFormat.nSamplesPerSec / Configuration.GetBufferFPS())
			{
				if(this->pEngine != 0)
				{
					this->pEngine->Lock();
					this->pEngine->Render();
					this->pEngine->Unlock();
				}
				uiReceivedSamples %= this->WaveFormat.nSamplesPerSec / Configuration.GetBufferFPS();
			}
		}
		else
		{
			break;
		}
	}
}

#endif
