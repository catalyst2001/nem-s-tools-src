/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Configuration.h"
#include "Engine.h"
#include "Log.h"
#include "NullAudio.h"

using namespace VAmp;
using namespace VAmp::Audio;

CNullAudio::CNullAudio(HWND hWnd, CEngine *pEngine) : CAudioDriver(hWnd, pEngine), bPlaying(false)
{

}

CNullAudio::~CNullAudio()
{

}

EAudioDriver CNullAudio::GetType() const
{
	return AUDIO_DRIVER_NULL;
}

bool CNullAudio::IsPlaying()
{
	return this->bPlaying;
}

bool CNullAudio::Play(unsigned int uiSamplesPerSecond)
{
	if(this->bPlaying)
	{
		return true;
	}

	LogMessage("Starting Null driver...");

	this->bPlaying = true;

	LogMessage("Null driver started.");

	return true;
}

void CNullAudio::Stop()
{
	if(this->bPlaying)
	{
		LogMessage("Stopping Null driver...");

		this->bPlaying = false;

		LogMessage("Null driver stopped.");
	}
}
