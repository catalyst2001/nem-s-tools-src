/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Chaos.h"

using namespace VAmp;
using namespace VAmp::Units;

#ifdef _DEBUG

LINK_UNIT(CChaosInfo, CChaos, ChaosInfo);

CChaos::CChaos(CEngine &Engine) : CUnit(CChaos::ChaosInfo, Engine), pPower(0), pDepth(0), pShape(0), pChaos(0), pStomp(0)
{

}

CChaos::~CChaos()
{
	this->Unload();
}

bool CChaos::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/chaos.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CKnob(*this, "Depth", 0.0f, 1.0f, 0.5f);
	this->pDepth->SetPosition(CVector(20, 28));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDepth);

	this->pShape = new CKnob(*this, "Shape", 0.0f, 1.0f, 0.5f);
	this->pShape->SetPosition(CVector(60, 42));
	this->pShape->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pShape);

	this->pChaos = new CKnob(*this, "Chaos", 3.0f, 5.0f, 4.0f);
	//this->pChaos = new CKnob(*this, "Chaos", 0.0f, 1.0f, 0.5f);
	this->pChaos->SetPosition(CVector(100, 28));
	this->pChaos->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pChaos);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	return true;
}

void CChaos::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	this->pShape = 0;
	this->pChaos = 0;
	this->pStomp = 0;
}

void CChaos::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CChaos::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		return;
	}

	float fDepth = this->pDepth->GetValue();
	float fShape = this->pShape->GetValue() * fNormalizer;
	float fChaos = 1.0f - this->pChaos->GetValue();

	for(unsigned int i = 0; i < uiSamples; i++)
	{
		float fData = fChaos * lpData[i] * (1.0f - lpData[i]);
		fData = fChaos * fData * (1.0f - fData);
		//fData = fChaos * fData * (1.0f - fData);
		if(fData < -fShape)
		{
			fData = -powf(-fData, fShape);
		}
		else if(fData > fShape)
		{
			fData = powf(fData, fShape);
		}
		lpData[i] = (1.0f - fDepth) * lpData[i] + fDepth * fData;

		if(lpData[i] < -fNormalizer)
		{
			lpData[i] = -fNormalizer;
		}
		else if(lpData[i] > fNormalizer)
		{
			lpData[i] = fNormalizer;
		}
	}
}

#endif
