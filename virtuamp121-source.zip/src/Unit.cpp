/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Cable.h"
#include "Engine.h"
#include "Unit.h"

using namespace VAmp;
using namespace VAmp::Units;

CUnit::CUnit(const CUnit::CUnitInfo &Info, CEngine &Engine) : Info(Info), bLoaded(false), Engine(Engine), Position(0, 0), Size(0, 0), InputJack(-2, 112), OutputJack(151, 112), pInput(0), pOutput(0), iShortcut(0)
{

}

CUnit::~CUnit()
{
	assert(!this->bLoaded);
}

bool CUnit::Load()
{
	if(this->bLoaded)
	{
		return true;
	}

	this->bLoaded = this->LoadInternal();
	return this->bLoaded;
}

void CUnit::Unload()
{
	if(!this->bLoaded)
	{
		return;
	}

	this->UnloadInternal();

	for(CControlList::iterator i = this->Controls.begin(); i != this->Controls.end(); ++i)
	{
		this->Engine.UnloadTexture((*i)->GetTexture());
		delete *i;
	}
	this->Controls.clear();

	this->Variables.clear();

	this->bLoaded = false;
}

unsigned int CUnit::GetControlCount() const
{
	return (unsigned int)this->Controls.size();
}

CControl *CUnit::GetControl(unsigned int uiIndex) const
{
	unsigned int uiCurrentIndex = 0;
	for(CControlList::const_iterator i = this->Controls.begin(); i != this->Controls.end(); ++i)
	{
		if(uiCurrentIndex == uiIndex)
		{
			return *i;
		}
		uiCurrentIndex++;
	}

	return 0;
}

CControl *CUnit::GetControl(const char *lpName) const
{
	for(CControlList::const_iterator i = this->Controls.begin(); i != this->Controls.end(); ++i)
	{
		if((*i)->GetName()!= 0)
		{
			if(_stricmp((*i)->GetName(), lpName) == 0)
			{
				return *i;
			}
		}
	}

	return 0;
}

unsigned int CUnit::GetVariableCount() const
{
	return (unsigned int)this->Variables.size();
}

CVariable *CUnit::GetVariable(unsigned int uiIndex) const
{
	unsigned int uiCurrentIndex = 0;
	for(CVariableList::const_iterator i = this->Variables.begin(); i != this->Variables.end(); ++i)
	{
		if(uiCurrentIndex == uiIndex)
		{
			return *i;
		}
		uiCurrentIndex++;
	}

	return 0;
}

CVariable *CUnit::GetVariable(const char *lpName) const
{
	for(CVariableList::const_iterator i = this->Variables.begin(); i != this->Variables.end(); ++i)
	{
		if(_stricmp((*i)->GetName(), lpName) == 0)
		{
			return *i;
		}
	}

	return 0;
}

CControl *CUnit::GetControl(CVector MousePosition) const
{
	for(CControlList::const_iterator i = this->Controls.begin(); i != this->Controls.end(); ++i)
	{
		if((*i)->GetType() != CONTROL_TYPE_SPRITE)
		{
			CVector Position = this->Position + (*i)->GetPosition();
			CVector Size = (*i)->GetSize();

			if((*i)->GetType() == CONTROL_TYPE_VERTICAL_SLIDER)
			{
				const CVerticalSlider *pSlide = static_cast<const CVerticalSlider *>(*i);
				float fTemp = (pSlide->GetValue() - pSlide->GetMin()) / (pSlide->GetMax() - pSlide->GetMin());
				Position.Y += (unsigned int)(pSlide->GetMinOffset() + fTemp * (pSlide->GetMaxOffset() - pSlide->GetMinOffset()));
			}

			if(CVector::Intersects(Position, Position + Size, MousePosition))
			{
				return *i;
			}
		}
	}

	return 0;
}

void CUnit::Render()
{
	this->bRequiresRender = false;

	if(!this->bLoaded)
	{
		return;
	}

	glPushMatrix();
	glTranslatef((float)this->Position.X, (float)this->Position.Y, 0.0f);

	this->RenderInternal();

	glPopMatrix();
}

void CUnit::RenderInternal()
{
	for(CControlList::iterator i = this->Controls.begin(); i != this->Controls.end(); ++i)
	{
		(*i)->Render();
	}
}

void CUnit::Process(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->bLoaded || lpData == 0 || uiSamples == 0)
	{
		return;
	}

	this->ProcessInternal(lpData, uiSamplesPerSecond, uiSamples, fNormalizer);

	if(this->pOutput != 0 && this->pOutput->GetOutput() != 0)
	{
		this->pOutput->GetOutput()->Process(lpData, uiSamplesPerSecond, uiSamples, fNormalizer);
	}
}

#include "Units.h"

namespace VAmp
{
	namespace Units
	{
		static const CUnit::CUnitInfo *lpUnitInfo[] =
		{
			&CAutomaticWah::AutomaticWahInfo,
			&CBoost::BoostInfo,
#ifdef _DEBUG
			&CChaos::ChaosInfo,
#endif
			&CChorus::ChorusInfo,
			&CCompressor::CompressorInfo,
			&CDelay::DelayInfo,
			&CDistortion::DistortionInfo,
			&CEnvelopeFilter::EnvelopeFilterInfo,
			&CEqualizer::EqualizerInfo,
			&CFader::FaderInfo,
			&CFeedbackLoop::FeedbackLoopInfo,
			&CFFTSpectrum::FFTSpectrumInfo,
			&CFlanger::FlangerInfo,
			&CFuzz::FuzzInfo,
			&CLoopStation::LoopStationInfo,
			&CMetronome::MetronomeInfo,
			&CNoiseGate::NoiseGateInfo,
			&COctave::OctaveInfo,
			&COscilloscope::OscilloscopeInfo,
			&COverdrive::OverdriveInfo,
			&CParallelFeedbackLoop::ParallelFeedbackLoopInfo,
			&CPhaseShifter::PhaseShifterInfo,
			&CPlayer::PlayerInfo,
			&CPreamp::PreampInfo,
			&CRecorder::RecorderInfo,
			&CReverb::ReverbInfo,
			&CRingModulator::RingModulatorInfo,
			&CSpeakerCabinet::SpeakerCabinetInfo,
			&CTremolo::TremoloInfo,
			&CVibrato::VibratoInfo
		};

		static const char *lpCategories[] =
		{
			"Delay/Reverb",
			"Distortion/Overdrive",
			"Essential",
			"Filter",
			"Modulation",
			"Other",
			"Pitch Shift",
			"Playback"
		};
	}
}

const CUnit::CUnitInfo *CUnit::GetUnitInfo(EUnitType eUnitType)
{
	if(eUnitType >= 0 && eUnitType < UNIT_TYPE_COUNT)
	{
		return Units::lpUnitInfo[eUnitType];
	}

	return 0;
}

const CUnit::CUnitInfo *CUnit::GetUnitInfo(const char *lpName)
{
	for(int i = 0; i < UNIT_TYPE_COUNT; i++)
	{
		if(_stricmp(lpUnitInfo[i]->GetName(), lpName) == 0)
		{
			return Units::lpUnitInfo[i];
		}
	}

	return 0;
}

const char *CUnit::GetCategoryName(ECategory eCategory)
{
	if(eCategory >= 0 && eCategory < CATEGORY_COUNT)
	{
		return Units::lpCategories[eCategory];
	}

	return 0;
}