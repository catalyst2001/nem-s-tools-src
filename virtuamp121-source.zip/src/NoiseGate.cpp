/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "NoiseGate.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CNoiseGateInfo, CNoiseGate, NoiseGateInfo);

CNoiseGate::CNoiseGate(CEngine &Engine) : CUnit(CNoiseGate::NoiseGateInfo, Engine), pPower(0), pWorking(0), pThreshold(0), pDecay(0), pStomp(0), uiAttack(0), uiDecay(0), Buffer()
{

}

CNoiseGate::~CNoiseGate()
{
	this->Unload();
}

bool CNoiseGate::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/noise gate.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pWorking = new CSprite(*this);
	this->pWorking->SetVisible(false);
	this->pWorking->SetPosition(CVector(72, 34));
	this->pWorking->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pWorking);

	this->pThreshold = new CKnob(*this, "Threshold", -60.0f, 0.0f, -40.0f);
	this->pThreshold->SetPosition(CVector(36, 34));
	this->pThreshold->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pThreshold);

	this->pDecay = new CKnob(*this, "Decay", 0.0f, 2.0f, 1.0f);
	this->pDecay->SetPosition(CVector(84, 34));
	this->pDecay->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDecay);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp", true);
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->uiAttack = 0;
	this->uiDecay = 0;

	return true;
}

void CNoiseGate::UnloadInternal()
{
	this->pPower = 0;
	this->pWorking = 0;
	this->pThreshold = 0;
	this->pDecay = 0;
	this->pStomp = 0;

	this->uiAttack = 0;
	this->uiDecay = 0;

	this->Buffer.Clear();
}

void CNoiseGate::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CNoiseGate::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	this->Buffer.SetSamples(uiSamplesPerSecond / 10);
	this->Buffer.Advance(uiSamples, lpData);

	if(!this->pStomp->GetPressed())
	{
		this->pWorking->SetVisible(false);

		this->uiAttack = 0;
		this->uiDecay = 0;
		return;
	}

	float fMin = *this->Buffer.GetBuffer(), fMax = *this->Buffer.GetBuffer();
	for(unsigned int i = 1; i < this->Buffer(); i++)
	{
		if(this->Buffer[i] < fMin)
		{
			fMin = this->Buffer[i];
		}
		if(this->Buffer[i] > fMax)
		{
			fMax = this->Buffer[i];
		}
	}

	float fVolume = fMax - fMin;
	bool bReduce = fVolume < powf(10.0f, this->pThreshold->GetValue() / 20.0f) * fNormalizer;

	float fDecaySamples = this->pDecay->GetValue() * (float)uiSamplesPerSecond;
	unsigned int uiDecaySamples = (unsigned int)fDecaySamples;

	float fAttackSamples = 0.05f * (float)uiSamplesPerSecond;
	unsigned int uiAttackSamples = (unsigned int)fAttackSamples;

	if(bReduce)
	{
		if(this->uiDecay >= uiDecaySamples)
		{
			memset(lpData, 0, sizeof(float) * uiSamples);

			this->uiAttack = 0;
			this->uiDecay += uiSamples;
		}
		else
		{
			fDecaySamples = 1.0f / fDecaySamples;

			for(unsigned int i = 0; i < uiSamples; i++)
			{
				if(this->uiDecay < uiDecaySamples)
				{
					lpData[i] *= (float)(uiDecaySamples - this->uiDecay) * fDecaySamples;
				}

				this->uiDecay++;
			}

			if(this->uiDecay >= uiDecaySamples)
			{
				this->uiAttack = 0;
			}
			else
			{
				this->uiAttack = (unsigned int)(fAttackSamples * (float)(uiDecaySamples - this->uiDecay) * fDecaySamples);
			}
		}
	}
	else
	{
		if(this->uiAttack >= uiAttackSamples)
		{
			this->uiAttack += uiSamples;
			this->uiDecay = 0;
		}
		else
		{
			fAttackSamples = 1.0f / fAttackSamples;

			for(unsigned int i = 0; i < uiSamples; i++)
			{
				if(this->uiAttack < uiAttackSamples)
				{
					lpData[i] *= (float)this->uiAttack * fAttackSamples;
				}

				this->uiAttack++;
			}

			if(this->uiAttack >= uiAttackSamples)
			{
				this->uiDecay = 0;
			}
			else
			{
				this->uiDecay = (unsigned int)(fDecaySamples * (float)this->uiAttack * fAttackSamples);
			}
		}
	}

	this->pWorking->SetVisible(bReduce);
}
