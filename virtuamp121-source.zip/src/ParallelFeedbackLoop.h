/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	Not a standard effect, but I like the flanger effect created by the
 *	decay of slightly offset comb filters...
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "AudioBuffer.h"
#include "Unit.h"

#define PARALLEL_FEEDBACK_LOOP_BUFFERS 10

namespace VAmp
{
	namespace Units
	{
		class CParallelFeedbackLoop : public CUnit
		{
			REGISTER_UNIT(CParallelFeedbackLoopInfo, CParallelFeedbackLoop, ParallelFeedbackLoopInfo, UNIT_TYPE_PARALLEL_FEEDBACK_LOOP, "Parallel Feedback Loop", CATEGORY_DELAY);

		private:
			CSprite *pPower;
			CKnob *pFeedback;
			CToggle *pAdditive;
			CKnob *pVoices;
			CKnob *pTime;
			CKnob *pSpace;			
			CStomp *pStomp;

			DSP::CAudioBuffer lpBuffers[PARALLEL_FEEDBACK_LOOP_BUFFERS];

		public:
			CParallelFeedbackLoop(CEngine &Engine);
			virtual ~CParallelFeedbackLoop();

		protected:
			virtual bool LoadInternal();
			virtual void UnloadInternal();

			virtual void RenderInternal();

			virtual void ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer);
		};
	}
}
