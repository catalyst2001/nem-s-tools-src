/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#pragma once

#include "stdafx.h"
#include "Cable.h"
#include "Font.h"
#include "Texture.h"
#include "Unit.h"

namespace VAmp
{
	enum ENewTemplate
	{
		NEW_TEMPLATE_NONE = 0,
#ifdef _DEBUG
		NEW_TEMPLATE_TESTING,
#endif
		NEW_TEMPLATE_ESSENTIAL,
		NEW_TEMPLATE_RECOMMENDED,
		NEW_TEMPLATE_PLAYBACK,
		NEW_TEMPLATE_EVERYTHING
	};

	class CEngine
	{
	private:
		HWND hWnd;
		HDC hDC;
		HGLRC hGLRC;

		bool bInitialized;
		unsigned int uiCurrent;

		float fAspectRatio;
		unsigned int uiWidth;
		unsigned int uiHeight;

		bool bCacheTextureMode;
		typedef std::list<CTexture *> CTextureList;
		CTextureList Textures;

		typedef std::list<CFont *> CFontList;
		CFontList Fonts;

		typedef std::list<Units::CUnit *> CUnitList;
		CUnitList Units;

		typedef std::list<Units::CCable *> CCableList;
		CCableList Cables;

		bool bLeftMouseDownCableHead;
		Units::CCable *pLeftMouseDownCable;
		Units::CUnit *pLeftMouseDownUnit;
		Units::CControl *pLeftMouseDownControl;
		CVector LastMousePosition;

		Units::CUnit *pSelectedUnit;
		bool bUseLoadPosition;
		CVector LoadPosition;

		Units::CUnit *pPreamp;
		Units::CUnit *pSpeakerCabinet;

		CRITICAL_SECTION CriticalSection;

	public:
		CEngine();
		~CEngine();

		inline unsigned int GetWidth() const
		{
			return this->uiWidth;
		}

		inline unsigned int GetHeight() const
		{
			return this->uiHeight;
		}

		inline bool GetCacheTextureMode() const
		{
			return this->bCacheTextureMode;
		}

		inline void SetCacheTextureMode(bool bCacheTextureMode)
		{
			this->bCacheTextureMode = bCacheTextureMode;
		}

		inline bool GetPressed(const Units::CControl *pControl) const
		{
			return pControl == this->pLeftMouseDownControl;
		}

		void Lock();
		void Unlock();

		bool IsInitialized();
		bool Initialize(HWND hWnd);
		void Destroy();

		void Resize();
		void Render();

		bool MakeCurrent();
		void MakeNotCurrent();

		bool HandleMessage(UINT message, WPARAM wParam, LPARAM lParam);

		CTexture *LoadTexture(const char *lpFileName);
		void UnloadTexture(CTexture *pTexture);
		void UnloadTextureCache();

		CFont *LoadFont(const char *lpFileName);
		void UnloadFont(CFont *pFont);

		Units::CCable *LoadCable();
		Units::CCable *LoadCable(Units::CUnit *pInput, Units::CUnit *pOutput);
		void UnloadCable(Units::CCable *pCable);

		bool GetUnitRequiresRender() const;
		Units::CUnit *LoadUnit(Units::EUnitType eUnitType);
		void UnloadUnit(Units::CUnit *pUnit);

		void New(ENewTemplate eNewTemplate = NEW_TEMPLATE_RECOMMENDED);
		bool Save(const char *lpFileName);
		bool Open(const char *lpFileName);
		void Clear();

		void Process(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples);

	private:
		Units::CCable *GetCable(CVector MousePosition, bool &bHead) const;

		int GetUnitIndex(Units::CUnit *pUnit);
		Units::CUnit *GetUnit(int iIndex) const;
		Units::CUnit *GetUnit(CVector MousePosition) const;

		void SetSelectedUnit(Units::CUnit *pSelectedUnit);

		void AutoPositionUnit(Units::CUnit &Unit);
	};
}
