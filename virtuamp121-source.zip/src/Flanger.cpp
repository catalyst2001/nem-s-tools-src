/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Flanger.h"
#include "LFO.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CFlangerInfo, CFlanger, FlangerInfo);

CFlanger::CFlanger(CEngine &Engine) : CUnit(CFlanger::FlangerInfo, Engine), pPower(0), pDepth(0), pFeedback(0), pWidth(0), pSpeed(0), pMatrix(0), pStomp(0), Buffer()
{

}

CFlanger::~CFlanger()
{
	this->Unload();
}

bool CFlanger::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/flanger.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pDepth = new CKnob(*this, "Depth", 0.0f, 0.5f, 0.5f);
	this->pDepth->SetPosition(CVector(9, 34));
	this->pDepth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDepth);

	this->pFeedback = new CKnob(*this, "Feedback", 0.0f, 0.85f, 0.6375f);
	this->pFeedback->SetPosition(CVector(43, 34));
	this->pFeedback->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pFeedback);

	this->pWidth = new CKnob(*this, "Width", 0.0005f, 0.005f, 0.00275f);
	this->pWidth->SetPosition(CVector(77, 34));
	this->pWidth->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pWidth);

	this->pSpeed = new CKnob(*this, "Speed", 0.05f, 1.05f, 0.1375f);
	this->pSpeed->SetPosition(CVector(111, 34));
	this->pSpeed->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pSpeed);

	this->pMatrix = new CToggle(*this, "Matrix", false);
	this->pMatrix->SetPosition(CVector(102, 20));
	this->pMatrix->SetOnTexture(this->Engine.LoadTexture("units/toggle_small_on.png"));
	this->pMatrix->SetOffTexture(this->Engine.LoadTexture("units/toggle_small_off.png"));
	this->Controls.push_back(this->pMatrix);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	this->fPhase = 0.0f;

	return true;
}

void CFlanger::UnloadInternal()
{
	this->pPower = 0;
	this->pDepth = 0;
	this->pFeedback = 0;
	this->pWidth = 0;
	this->pSpeed = 0;
	this->pMatrix = 0;
	this->pStomp = 0;

	this->Buffer.Clear();
}

void CFlanger::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

#define FLANGER_DELAY 0.001f

void CFlanger::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	float fSamplesPerSecond = (float)uiSamplesPerSecond;

	this->Buffer.SetSamples((unsigned int)ceilf(fSamplesPerSecond * (FLANGER_DELAY + this->pWidth->GetMax())) + uiSamples + 1);
	this->Buffer.Advance(uiSamples, lpData);

	if(!this->pStomp->GetPressed() || this->pDepth->GetValue() == 0.0f)
	{
		this->fPhase = 0.0f;
		return;
	}

	float fDepth = this->pDepth->GetValue();
	float fOneMinusDepth = 1.0f - fDepth;
	float fFeedback = this->pFeedback->GetValue();
	float fOneMinusFeedback = 1.0f - fFeedback;
	float fWidth = this->pWidth->GetValueInverse();
	bool bMatrix = this->pMatrix->GetOn();
	float fFrequency = this->pSpeed->GetValue();
	unsigned int uiDelay = (unsigned int)ceilf(fSamplesPerSecond * FLANGER_DELAY);

	DSP::CTriangleLFO LFO(uiSamplesPerSecond, fFrequency);

	unsigned int uiBufferOffset = this->Buffer() - uiDelay - uiSamples;
	float fOffset;
	if(bMatrix)
	{
		fOffset = (fFrequency - this->pSpeed->GetMin()) / (this->pSpeed->GetMax() - this->pSpeed->GetMin()) * fWidth * fSamplesPerSecond;
	}
	else
	{
		fWidth *= 0.5f;
	}
	for(unsigned int i = 0; i < uiSamples; i++)
	{
		if(!bMatrix)
		{
			fOffset = (LFO.GetValue(this->fPhase++) + 1.0f) * fWidth * fSamplesPerSecond;
		}
		float fIndex = floorf(fOffset);
		float fOneMinusWeight = fOffset - fIndex;
		unsigned int uiIndex = uiBufferOffset - (unsigned int)fIndex + i;
		float fSample = (1.0f - fOneMinusWeight) * this->Buffer[uiIndex] + fOneMinusWeight * this->Buffer[uiIndex - 1];

		lpData[i] = fOneMinusDepth * lpData[i] + fDepth * fSample;
		uiIndex = this->Buffer() - uiSamples + i;
		this->Buffer[uiIndex] = this->Buffer[uiIndex] + fFeedback * fSample;
	}

	this->fPhase = fmodf(this->fPhase, fSamplesPerSecond / fFrequency);
}
