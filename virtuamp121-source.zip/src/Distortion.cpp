/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "Engine.h"
#include "Distortion.h"

using namespace VAmp;
using namespace VAmp::Units;

LINK_UNIT(CDistortionInfo, CDistortion, DistortionInfo);

CDistortion::CDistortion(CEngine &Engine) : CUnit(CDistortion::DistortionInfo, Engine), pPower(0), pLevel(0), pTone(0), pDistortion(0), pStomp(0)
{

}

CDistortion::~CDistortion()
{
	this->Unload();
}

bool CDistortion::LoadInternal()
{
	this->Size = CVector(152, 248);

	CSprite *pUnit = new CSprite(*this);
	pUnit->SetSize(CVector(152, 248));
	pUnit->SetRectangle(CRectangle(4, 204, 252, 52));
	pUnit->SetTexture(this->Engine.LoadTexture("units/distortion.png"));
	this->Controls.push_back(pUnit);

	this->pPower = new CSprite(*this);
	this->pPower->SetPosition(CVector(72, 8));
	this->pPower->SetTexture(this->Engine.LoadTexture("units/power.png"));
	this->Controls.push_back(this->pPower);

	this->pLevel = new CKnob(*this, "Level", 0.0f, 2.0f, 1.0f);
	this->pLevel->SetPosition(CVector(20, 28));
	this->pLevel->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pLevel);

	this->pTone = new CKnob(*this, "Tone", 0.25f, 1.0f, 0.625f);
	this->pTone->SetPosition(CVector(60, 42));
	this->pTone->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pTone);

	this->pDistortion = new CKnob(*this, "Distortion", 0.0f, 40.0f, 20.0f);
	this->pDistortion->SetPosition(CVector(100, 28));
	this->pDistortion->SetTexture(this->Engine.LoadTexture("units/knob.png"));
	this->Controls.push_back(this->pDistortion);

	CSprite *pInput = new CSprite(*this);
	pInput->SetPosition(CVector(-2, 100));
	pInput->SetTexture(this->Engine.LoadTexture("units/input.png"));
	this->Controls.push_back(pInput);

	CSprite *pOutput = new CSprite(*this);
	pOutput->SetPosition(CVector(88, 100));
	pOutput->SetTexture(this->Engine.LoadTexture("units/output.png"));
	this->Controls.push_back(pOutput);

	this->pStomp = new CStomp(*this, "Stomp");
	this->pStomp->SetPosition(CVector(6, 156));
	this->pStomp->SetSize(CVector(140, 86));
	this->Controls.push_back(this->pStomp);

	return true;
}

void CDistortion::UnloadInternal()
{
	this->pPower = 0;
	this->pLevel = 0;
	this->pTone = 0;
	this->pDistortion = 0;
	this->pStomp = 0;
}

void CDistortion::RenderInternal()
{
	this->pPower->SetVisible(this->pStomp->GetPressed());

	this->CUnit::RenderInternal();
}

void CDistortion::ProcessInternal(float *lpData, unsigned int uiSamplesPerSecond, unsigned int uiSamples, float &fNormalizer)
{
	if(!this->pStomp->GetPressed())
	{
		return;
	}

	float fLevel = this->pLevel->GetValue();
	float fTone = this->pTone->GetValueInverse();
	float fDistrotion = powf(10.0f, this->pDistortion->GetValue() / 20.0f);

	for(unsigned int i = 0; i < uiSamples; i++)
	{
		lpData[i] *= fDistrotion;

		if(lpData[i] < -1.0f)
		{
			lpData[i] = -1.0f;
		}
		else if(lpData[i] > 1.0f)
		{
			lpData[i] = 1.0f;
		}
		else if(lpData[i] < 0.0f)
		{
			lpData[i] = -powf(-lpData[i], fTone);
		}
		else
		{
			lpData[i] = powf(lpData[i], fTone);
		}

		lpData[i] *= fLevel;
	}

	fNormalizer = fLevel;
}
