/*
 *	virtuAMP - Virtual guitar amplifier.
 *	Copyright (C) 2007-2008  Ryan Gregg
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	You may contact the author at ryansgregg@hotmail.com or visit
 *	http://nemesis.thewavelength.net/ for more information.
 */

#include "stdafx.h"
#include "AudioBuffer.h"

using namespace VAmp::DSP;

CAudioBuffer::CAudioBuffer() : uiBufferSamples(0), lpBuffer(0)
{

}

CAudioBuffer::~CAudioBuffer()
{
	delete []this->lpBuffer;
}

void CAudioBuffer::SetSamples(unsigned int uiBufferSamples)
{
	if(uiBufferSamples < this->uiBufferSamples)
	{
		float *lpBuffer = new float[uiBufferSamples];
		memcpy(lpBuffer, this->lpBuffer + (this->uiBufferSamples - uiBufferSamples), sizeof(float) * uiBufferSamples);
		delete []this->lpBuffer;

		this->uiBufferSamples = uiBufferSamples;
		this->lpBuffer = lpBuffer;
	}
	else if(uiBufferSamples > this->uiBufferSamples)
	{
		float *lpBuffer = new float[uiBufferSamples];
		memcpy(lpBuffer, this->lpBuffer, sizeof(float) * this->uiBufferSamples);
		memset(lpBuffer + this->uiBufferSamples, 0, sizeof(float) * (uiBufferSamples - this->uiBufferSamples));
		delete []this->lpBuffer;

		this->uiBufferSamples = uiBufferSamples;
		this->lpBuffer = lpBuffer;
	}
}

void CAudioBuffer::Resample(unsigned int uiBufferSamples, bool bErase)
{
	if(this->uiBufferSamples == uiBufferSamples)
	{
		return;
	}

	if(uiBufferSamples == 0)
	{
		this->Clear();
	}
	else if(this->uiBufferSamples == 0)
	{
		this->uiBufferSamples = uiBufferSamples;
		this->lpBuffer = new float[uiBufferSamples];

		this->Erase();
	}
	else if(bErase)
	{
		delete []this->lpBuffer;

		this->uiBufferSamples = uiBufferSamples;
		this->lpBuffer = new float[uiBufferSamples];

		this->Erase();
	}
	else
	{
		float *lpBuffer = new float[uiBufferSamples];
		double fRatio = (double)this->uiBufferSamples / (double)uiBufferSamples;
		for(unsigned int i = 0; i < uiBufferSamples; i++)
		{
			// Cubic interpolation.
			double fIndexInt = (double)i * fRatio;
			double fIndex = floor(fIndexInt);
			unsigned int uiIndex = (unsigned int)fIndex;
			float fInt = (float)(fIndexInt - fIndex);
			float fInt2 = fInt * fInt;

			if(uiIndex >= this->uiBufferSamples)
			{
				uiIndex = this->uiBufferSamples - 1;
			}

			float fS1 = this->lpBuffer[uiIndex];
			float fS0 = uiIndex > 0 ? this->lpBuffer[uiIndex - 1] : fS1;
			float fS2 = uiIndex < this->uiBufferSamples - 1 ? this->lpBuffer[uiIndex + 1] : fS1;
			float fS3 = uiIndex < this->uiBufferSamples - 2 ? this->lpBuffer[uiIndex + 2] : fS2;

			float fA0 = fS3 - fS2 - fS0 + fS1;
			float fA1 = fS0 - fS1 - fA0;
			float fA2 = fS2 - fS0;

			lpBuffer[i] = fA0 * fInt * fInt2 + fA1 * fInt2 + fA2 * fInt + fS1;
		}
		delete []this->lpBuffer;

		this->uiBufferSamples = uiBufferSamples;
		this->lpBuffer = lpBuffer;
	}
}

void CAudioBuffer::Advance(unsigned int uiSamples, const float *lpSamples)
{
	if(uiSamples < this->uiBufferSamples)
	{
		memmove(this->lpBuffer, this->lpBuffer + uiSamples, sizeof(float) * (this->uiBufferSamples - uiSamples));
		memcpy(this->lpBuffer + this->uiBufferSamples - uiSamples, lpSamples, sizeof(float) * uiSamples);
	}
	else
	{
		memcpy(this->lpBuffer, lpSamples + uiSamples - this->uiBufferSamples, sizeof(float) * this->uiBufferSamples);
	}
}

void CAudioBuffer::Erase()
{
	memset(this->lpBuffer, 0, sizeof(float) * this->uiBufferSamples);
}

void CAudioBuffer::Clear()
{
	this->uiBufferSamples = 0;

	delete []this->lpBuffer;
	this->lpBuffer = 0;
}
