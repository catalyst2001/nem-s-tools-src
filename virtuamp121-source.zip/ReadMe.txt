=========================
=========================
 virtuAmp By: Ryan Gregg
=========================
=========================

===========================
Program/Author Information:
===========================

Title      : virtuAMP
Author     : Ryan Gregg
Build      : 1.2.1
Date       : May 25th 2007
Email      : ryansgregg@hotmail.com
Website    : http://nemesis.thewavelength.net/
Written In : C/C++

============
Requirments:
============

System Requirements:

  * 2.0 Ghz Pentium 4 Class CPU or equivalent.
  * 256 MB RAM
  * 3D Video Adaptor
  * Audio Adaptor
  * Supported Operating Systems:
    o Windows Vista
    o Microsoft Windows� Server 2003
    o Windows XP Professional
    o Windows XP Home Edition
    o Windows 2000
    o Windows Millennium Edition
    o Windows 98
    o Microsoft Windows NT� 4.0 Service Pack 6a

System Recommendations:

  * 3.0 Ghz Pentium 4 Class CPU or equivalent.
  * 512 MB RAM
  * 3D Video Adaptor with latest drivers (GeForce, ATI, Matrox etc.)
  * High Quality Audio Adaptor

====
FAQ:
====

  Q. How do I connect my guitar to my computer?

  A. There are two cheap solutions to this question:

     1) Obtain a 1/4" (6.35 mm) mono to 1/8" (3.5 mm) mono
        adapter.  Such adapters are available at most good
        audio/video stores.  A stereo adapter should also do
        the job.  You should then be able to connect a standard
        1/4" guitar cable into the 1/8" line-in or microphone
        input on your computer.  Play as usual using either
        headphones or speakers.
        

     2) Obtain a microphone and a set of headphones, connect
        your microphone to your computer's microphone input and
        your headphones to your computer's headphone output.
        Play into your microphone.


  Q. Why do my speakers pop when I play my guitar through
     virtuAMP?

  A. Your computer isn't able to process audio buffers fast
     enough before receiving the next audio buffer.  This is
     usually caused by a slow CPU or cheap sound card.  You
     can mitigate the effect by trying any combination of the
     following three settings:

     1) Audio Driver: Try switching between the Windows Multimedia
        and DirectSound audio drivers.  The DirectSound audio
        driver should provide better priority for audio processing,
        but requires Windows XP and up.

     2) Audio Buffer Denominator: Try increasing the delay between
        audio buffer capture and playback by decreasing the audio
        buffer denominator setting one step at a time.  Allow a
        few seconds to determine effectiveness.

     3) Audio Buffer FPS: Try decreasing the display frame rate by
        decreasing the audio buffer FPS setting.  This will
        provide more CPU time for audio processing.

     Note: All settings may be adjusted from the Audio menu and
     take effect immediately.


  Q. How do I connect foot pedals to virtuAMP?

  A. virtuAMP does not support foot pedals, but you can use
     your keyboard to toggle effects on and off.  To do so:

     1) Select an effect.
     2) While holding the shift key, press the button you wish
        to use to toggle the effect (you can assign the same key
        to multiple effects).
     3) The name of the key you selected should appear in the
        status bar at the bottom of your screen.
     4) Repeat 1-3 for each effect you with to add a shortcut to.

     To remove a shortcut:

     1) Select an effect.
     2) While holding the shift key, press delete.
     3) Repeat 1-2 for each effect you with to remove a shortcut
        from.


  Q. Why can't the Player/Recorder effect play my .wav file?

  A. virtuAMP only supports 8 or 16 bit PCM, and 32 bit or 64
     bit IEEE floating point .wav files samples at 44100 Hz.

     You may use Audacity to convert your .wav files to an
     accepted format:

     http://audacity.sourceforge.net/

     You may also encounter problems if the .wav file is opened
     in another program, or by virtuAMP for recording.  Check
     the log.txt file in your installation folder for detailed
     error messages.


  Q. How do I improve my sound quality?

  A. virtuAMP is not meant to be a replacement for real guitar
     amplifiers or professional studio equipment. Having said
     that, there are many factors that will affect the quality of
     sound virtuAMP can produce.  Your audio card and speakers are
     probably the most important factors (most computers come with
     a cheap on-board sound card), and a slow CPU can lead to
     audible popping as audio buffers aren't processed before they
     are needed.  Upgrading any of these things may lead to a
     better overall sound.

==================
Program Changelog:
==================

  v1.2.1
  - Added Metronome effect.
  - Added Matrix option to Flanger.

  v1.2.0
  - Added Automatic Wah effect.
  - Added Boost effect.
  - Added Chorus effect.
  - Added Envelope Filter effect.
  - Added FFT Spectrum.
  - Added Fader effect.
  - Added Loop Station effect.
  - Added Octave effect.
  - Added Parallel Feedback Loop effect.
  - Added Ring Modulator effect.
  - Added Vibrato effect.
  - Added Reverse and Long option to Delay.
  - Added Additive mode to Feedback Loop.
  - Added Center DC option to Preamp.
  - Rewrote Equalizer effect.
  - Rewrote Flanger effect.
  - Rewrote Reverb effect.

  v1.1.0
  - Added Feedback Loop effect.
  - Added Flanger effect.
  - Added audio options to main menu.
  - Added full duplex DirectSound driver.
  - Improved Windows Multimedia driver.
  - Fixed Windows Vista audio.
  - Fixed Windows Vista graphics.

  v1.0.0
  - Original build.

===========================
GNU General Public License:
===========================

virtuAMP is licensed under the GNU General Public License,
for the complete licence terms, see the GPL.txt file included
in the distribution.
